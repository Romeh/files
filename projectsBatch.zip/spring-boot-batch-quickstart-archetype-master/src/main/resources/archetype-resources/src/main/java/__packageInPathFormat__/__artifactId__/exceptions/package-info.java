/**
 * Spring Security Configuration
 */
package ${package}.${artifactId}.exceptions;
