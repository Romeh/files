/**
 * Service Layer Beans
 */
package ${package}.${artifactId}.web;
