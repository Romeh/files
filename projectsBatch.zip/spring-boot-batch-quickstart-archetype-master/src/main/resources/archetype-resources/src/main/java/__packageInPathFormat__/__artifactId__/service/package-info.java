/**
 * Service Layer Beans
 */
package ${package}.${artifactId}.service;