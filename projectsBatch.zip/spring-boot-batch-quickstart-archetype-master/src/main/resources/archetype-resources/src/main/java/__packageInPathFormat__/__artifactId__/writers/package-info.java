package ${package}.${artifactId}.writers;
