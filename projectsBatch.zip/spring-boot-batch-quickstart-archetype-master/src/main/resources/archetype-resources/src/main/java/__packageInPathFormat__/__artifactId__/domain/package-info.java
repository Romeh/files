/**
 * JPA Domain Objects
 */
package ${package}.${artifactId}.domain;