/**
 * Spring Framework jobs
 */
package ${package}.${artifactId}.job;
