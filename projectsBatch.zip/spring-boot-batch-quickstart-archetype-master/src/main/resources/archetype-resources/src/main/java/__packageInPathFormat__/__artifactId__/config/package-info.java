/**
 * Spring Framework Configuration Files
 */
package ${package}.${artifactId}.config;