package com.batch.core.web;


import lombok.*;
import java.util.Map;
/**
 * Created by id961900 on 21/09/2017.
 */
@NoArgsConstructor
@AllArgsConstructor
@Setter
@Getter
@ToString
@EqualsAndHashCode
@Builder
public class JobParamsRequest {
    private Map<String,String> jobParamters;

}


