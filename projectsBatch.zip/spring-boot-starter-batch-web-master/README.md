BICS Enterprise-ready / production-ready batch applications powered by Spring Boot
=============================
<br />
![mainAppDesign](src/docs/asciidoc/BatchWeb.png)
<br />
The project spring-boot-starter-batch-web is a Spring Boot starter for Spring Batch taking care of everything except writing the jobs.

See the User manual in how to use it is :
 http://bicsgit.bc/psd-java/spring-boot-starter-batch-web/blob/master/src/docs/asciidoc/index.adoc
<br />
<br />
Features include:

* Starting up a web application and automatically deploying batch jobs to it (JavaConfig, XML or JSR-352).
* Log file separation, one log file for each job execution.
* An operations http endpoint for starting and stopping jobs, for retrieving the BatchStatus and the log file.
* A monitoring http endpoint for retrieving detailed information on a job execution, for knowing all deployed jobs and all running job executions.

<br />
<br />
You can use BICS maven archetype to generate the batch application project code template for you at :
http://bicsgit.bc/psd-java/spring-boot-batch-quickstart
