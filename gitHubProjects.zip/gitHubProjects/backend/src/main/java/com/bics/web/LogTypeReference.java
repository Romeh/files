package com.bics.web;


import com.bics.elastic.search.response.QueryResponse;
import com.bics.logs.LogEntry;
import com.fasterxml.jackson.core.type.TypeReference;

/**
 * TypeReference ref = new TypeReference<ResponseHits<Employee>>() {};
 */
public class LogTypeReference extends TypeReference<QueryResponse<LogEntry>> {
}
