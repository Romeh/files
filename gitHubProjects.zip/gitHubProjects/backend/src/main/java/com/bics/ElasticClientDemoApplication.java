package com.bics;

import com.bics.elastic.RestClientConfig;
import com.bics.elastic.index.IndexService;
import com.bics.web.LogService;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Import;

@SpringBootApplication
@Import(RestClientConfig.class)
public class ElasticClientDemoApplication {

    public static void main(String[] args) {
        ConfigurableApplicationContext context = SpringApplication.run(ElasticClientDemoApplication.class, args);

        LogService logService = context.getBean(LogService.class);
        IndexService indexService = context.getBean(IndexService.class);

        if (!indexService.indexExist(LogService.INDEX)) {
            System.out.println("index exist");
        }
    }


}
