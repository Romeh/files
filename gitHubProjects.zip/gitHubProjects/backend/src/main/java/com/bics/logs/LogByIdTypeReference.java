package com.bics.logs;


import com.bics.elastic.document.response.GetByIdResponse;
import com.fasterxml.jackson.core.type.TypeReference;

/**
 * Created by romih on 18/08/2016.
 */
public class LogByIdTypeReference extends TypeReference<GetByIdResponse<LogEntry>> {
}
