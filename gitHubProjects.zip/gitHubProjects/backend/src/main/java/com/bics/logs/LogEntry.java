package com.bics.logs;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;



/**
 * Created by id961900 on 19/07/2017.
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class LogEntry {

    private String appName;
    private String level;
    private String mailTo;
    private Message message;
    private String source;
    private String timestamp;
    private String type;
    private String id;
}
