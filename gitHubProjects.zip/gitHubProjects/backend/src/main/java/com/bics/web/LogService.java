package com.bics.web;


import com.bics.elastic.document.DeleteRequest;
import com.bics.elastic.document.DocumentService;
import com.bics.elastic.document.IndexRequest;
import com.bics.elastic.document.QueryByIdRequest;
import com.bics.elastic.index.IndexService;
import com.bics.elastic.search.SearchByTemplateRequest;
import com.bics.elastic.search.SearchService;
import com.bics.logs.LogByIdTypeReference;
import com.bics.logs.LogEntry;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.FileCopyUtils;
import org.springframework.util.ResourceUtils;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by romih on 16/07/16.
 */
@Service
public class LogService {
    private static final Logger logger = LoggerFactory.getLogger(LogService.class);

    public static final String INDEX = "bics_iot";
    private static final String TYPE = "doc";

    private final DocumentService documentService;
    private final IndexService indexService;
    private final SearchService searchService;

    @Autowired
    public LogService(DocumentService documentService, IndexService indexService, SearchService searchService) {
        this.documentService = documentService;
        this.indexService = indexService;
        this.searchService = searchService;
    }

    public String storeLog(LogEntry logEntry) {

        IndexRequest request = new IndexRequest();
        request.setIndex(INDEX);
        request.setType(TYPE);
        request .setEntity(logEntry);

        if (logEntry.getId() != null) {
            request.setId(logEntry.getId());
        }

        return documentService.index(request);
    }

    public List<LogEntry> queryForLogs(String name) {
        Map<String, Object> params = new HashMap<>();
        params.put("name", name);
        params.put("operator", "or");

        SearchByTemplateRequest request = SearchByTemplateRequest .create()
                .setAddId(true)
                .setTypeReference(new LogTypeReference())
                .setIndexName(INDEX)
                .setModelParams(params)
                .setTemplateName("find_log.twig");

        return searchService.queryByTemplate(request);
    }

    public List<LogEntry> queryForLogsBySeverityAndServiceName(String searchString) {
        Map<String, Object> params = new HashMap<>();
        params.put("searchText", searchString);
        params.put("operator", "and");

        SearchByTemplateRequest request = SearchByTemplateRequest .create()
                .setAddId(true)
                .setTypeReference(new LogTypeReference())
                .setIndexName(INDEX)
                .setModelParams(params)
                .setTemplateName("find_log_by_app_msg.twig");

        return searchService.queryByTemplate(request);
    }

    public LogEntry loadLogEntryById(String id) {
        QueryByIdRequest request=new QueryByIdRequest();

        request.setAddId(true);
        request.setIndex(INDEX);
        request.setType(TYPE);
        request.setId(id);
        request.setTypeReference(new LogByIdTypeReference());

        return documentService.queryById(request);
    }

    public void removeLogById(String id) {
        DeleteRequest deleteRequest=new DeleteRequest();
        deleteRequest.setId(id);
        deleteRequest.setType(TYPE);
        deleteRequest.setIndex(INDEX);
        documentService.remove(deleteRequest);

    }

    public void createIndex() {
        try {
            File file = ResourceUtils.getFile("classpath:elastic/luminis-mapping.json");
            FileReader fileReader = new FileReader(file);
            String body = FileCopyUtils.copyToString(fileReader);
            fileReader.close();
            indexService.createIndex(INDEX, body);
        } catch (IOException e) {
            logger.warn("Could not read mapping file for creating index", e);
        }
    }
}
