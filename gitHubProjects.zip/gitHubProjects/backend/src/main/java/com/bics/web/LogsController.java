package com.bics.web;

import com.bics.logs.LogEntry;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

import static org.springframework.web.bind.annotation.RequestMethod.DELETE;
import static org.springframework.web.bind.annotation.RequestMethod.GET;
import static org.springframework.web.bind.annotation.RequestMethod.POST;

@CrossOrigin(origins = "http://localhost:8000", maxAge = 3600)
@RestController
@RequestMapping("/api/logs")
public class LogsController {
    private final LogService service;

    @Autowired
    public LogsController(LogService service) {
        this.service = service;
    }

    @RequestMapping(method = GET)
    public List<LogEntry> logs(@RequestParam(defaultValue = "") String name) {
        return service.queryForLogs(name);
    }

    @RequestMapping(method = GET, value = "/_search")
    public List<LogEntry> searchLogs(@RequestParam String term) {
        return service.queryForLogsBySeverityAndServiceName(term);
    }

    @RequestMapping(method = GET, value = "/{id}")
    public LogEntry logById(@PathVariable String id) {
        return service.loadLogEntryById(id);
    }

    @RequestMapping(method = POST)
    public LogEntry storeLog(@RequestBody LogEntry employee) {
        String id = service.storeLog(employee);
        employee.setId(id);
        return employee;
    }

    @RequestMapping(method = DELETE, value = "/{id}")
    public void removeEmployee(@PathVariable String id) {
        service.removeLogById(id);
    }
}
