package com.bics.logs;

import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.util.List;

/**
 * Created by id961900 on 19/07/2017.
 */
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Message {
    private List<Errors> errors;
    private String reqId;
    private String serviceName;
    private String severity;
}
