package com.bics.demo.log;

import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Created by id961900 on 13/07/2017.
 */
public class LogReporter implements Reporter<LogEvent> {
    private static final Logger LOGGER_INCIDENT = LoggerFactory.getLogger("incidents");
    @Override
    public void log(LogEvent log) {
        LOGGER_INCIDENT.error(toJson(log));
    }

    private static String toJson(Object object) {
        return new Gson().toJson(object);
    }
}
