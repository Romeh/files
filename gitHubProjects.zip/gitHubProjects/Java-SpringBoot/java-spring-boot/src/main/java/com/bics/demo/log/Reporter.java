package com.bics.demo.log;

/**
 * Created by id961900 on 13/07/2017.
 */
public interface Reporter <T> {

    void log(T log);
}
