package com.bics.demo.log;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.ToString;

import java.util.List;

/**
 * Created by id961900 on 13/07/2017.
 */

@Builder
@EqualsAndHashCode
@ToString
public class LogEvent {

    List<Error> errors;
    String serviceName;
    String severity;
    String className;
    String reqId;
    String logCode;


}
