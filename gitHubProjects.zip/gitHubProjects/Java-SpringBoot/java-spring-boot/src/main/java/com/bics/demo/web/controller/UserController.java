package com.bics.demo.web.controller;

import com.bics.demo.log.Error;
import com.bics.demo.log.LogEvent;
import com.bics.demo.log.LogReporter;
import com.bics.demo.service.UserService;
import com.bics.demo.service.converter.UserResourceConverter;
import com.bics.demo.web.request.UserResourceRequest;
import com.bics.demo.web.response.ResourceIdResponse;
import com.bics.demo.web.response.SuccessResponse;
import com.bics.demo.web.response.UserResourceResponse;
import com.google.gson.Gson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Arrays;
import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

/**
 * @author romih
 */

@RestController
@RequestMapping("/users") public class UserController {

	private static final Logger LOGGER = LoggerFactory.getLogger(UserController.class);
	private static final LogReporter LOGGER_INCIDENT = new LogReporter();

	@Autowired
	private UserService userService;

	@Autowired
	private UserResourceConverter converter;


	@RequestMapping(value = "/{userId}", method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public String getUser( @PathVariable final Long userId) {
		LOGGER.debug("Trying to retrieve User by ID: " + userId);
		return toJson(this.converter.convert(this.userService.getUser(userId)));
	}


	@RequestMapping(method = RequestMethod.GET, produces = "application/json")
	@ResponseBody
	public String getAllUsers() {
		LOGGER.debug("Trying to retrieve all users");
		final Set<UserResourceResponse> collect = StreamSupport.stream(this.userService.getAllUsers().spliterator(),false)
				.map(user -> this.converter.convert(user)).collect(Collectors.toSet());
		// incident example
		if(collect.isEmpty()){
			LOGGER_INCIDENT.log(LogEvent.builder().logCode("IOT_001")
					.errors(Arrays.asList(Error.builder().errorCode("1000E").errorMsg("Error users not found and emty").build(),Error.builder().errorCode("5000E").errorMsg("Second Error users not found and emty").build())).reqId(UUID.randomUUID().toString())
					.serviceName("DemoService").severity("CRITICAL").build());
		}
		return toJson(collect);
	}


	@RequestMapping(method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public String createUser(@Valid @RequestBody UserResourceRequest request) {
		LOGGER.debug("Trying to create a user: " + request.toString());
		Long userId = this.userService.createUser(this.converter.convert(request));
		return toJson(new ResourceIdResponse(userId));
	}


	@RequestMapping(value = "/{userId}", method = RequestMethod.PUT, produces = "application/json")
	@ResponseBody
	public String updateUser( @PathVariable final Long userId,
									 @Valid @RequestBody UserResourceRequest request) {
		LOGGER.debug("Trying to update a user: " + request.toString());
		this.userService.updateUser(this.converter.convert(request, userId));
		return toJson(new SuccessResponse());
	}


	@RequestMapping(value = "/{userId}", method = RequestMethod.DELETE, produces = "application/json")
	@ResponseBody
	public String deleteUser( @PathVariable final Long userId) {
		LOGGER.debug("Trying to delete a user: " + userId);
		this.userService.deleteUser(userId);
		return toJson(new SuccessResponse());
	}

	private static String toJson(Object object) {
		return new Gson().toJson(object);
	}

	/**
	 * Sets request service.
	 *
	 * @param userService the request service
	 */
	void setUserService(final UserService userService) {
		this.userService = userService;
	}

	/**
	 * Sets converter.
	 *
	 * @param converter the converter
	 */
	void setConverter(final UserResourceConverter converter) {
		this.converter = converter;
	}
}
