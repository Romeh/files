package com.bics.demo.log;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.ToString;

/**
 * Created by id961900 on 18/07/2017.
 */
@Builder
@EqualsAndHashCode
@ToString
public class Error {
    String errorCode;
    String errorMsg;

}
