package com.bics.demo.web.response;

import com.bics.demo.domain.User;
import lombok.AllArgsConstructor;
import lombok.Getter;

import java.io.Serializable;

/**
 * Represents response body when {@link User} resource has to be returned
 * Necessary for proper Swagger documentation.
 *
 * @author romih
 */
@AllArgsConstructor
@Getter
public class UserResourceResponse implements Serializable {

	private static final long serialVersionUID = -8761235292937715094L;
	private Long id;
	private String firstName;
	private String lastName;
	private String country;
}
