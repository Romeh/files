package com.bics.demo.web.request;


import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.hibernate.validator.constraints.NotBlank;

import java.io.Serializable;

/**
 * Represents request body for Create User operation.
 * Necessary for proper Swagger documentation.
 *
 * @author romih
 */
@Getter
@Setter
@ToString
public class UserResourceRequest implements Serializable {

	private static final long serialVersionUID = 2657944775357946081L;

	@NotBlank
	private String firstName;

	@NotBlank
	private String lastName;

	@NotBlank
	private String country;

}
