package com.bics.alertmanager.entities;

/**
 * Created by id961900 on 09/08/2017.
 */
public enum CacheNames {
    AlertsConfig,
    Alerts
}
