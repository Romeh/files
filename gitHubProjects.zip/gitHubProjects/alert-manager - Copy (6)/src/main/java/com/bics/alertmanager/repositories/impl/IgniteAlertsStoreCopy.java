package com.bics.alertmanager.repositories.impl;

import com.bics.alertmanager.entities.AlertConfigEntry;
import com.bics.alertmanager.entities.AlertEntry;
import com.bics.alertmanager.entities.AlertHolder;
import com.bics.alertmanager.entities.CacheNames;
import com.bics.alertmanager.exception.ResourceNotFoundException;
import com.bics.alertmanager.repositories.AlertsConfigStore;
import com.bics.alertmanager.repositories.AlertsStore;
import com.bics.alertmanager.services.MailService;
import org.apache.http.entity.ByteArrayEntity;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.query.SqlQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;
import java.util.stream.StreamSupport;

@Component
public class IgniteAlertsStoreCopy {
   /* private static final Logger logger = LoggerFactory.getLogger(IgniteAlertsStoreCopy.class);

    @Autowired
    private Ignite ignite;

    @Autowired
    private MailService mailService;

    @Autowired
    private AlertsConfigStore alertsConfigStore;

    @Override
    public List<AlertEntry> getAlertForServiceId(String serviceId) {
        return Optional.ofNullable(getAlertsCache().get(serviceId))
                .orElseThrow(() -> new ResourceNotFoundException(String.format("Alert for %s not found", serviceId)));

    }

    @Override
    public void updateAlertEntry(String serviceId, String serviceCode, AlertEntry alertEntry) {
        final IgniteCache<String, List<AlertEntry>> alertsCache = getAlertsCache();
        // update the alert entry via cache invoke for atomicity
        alertsCache.invoke(serviceId, (mutableEntry, objects) -> {
            if (mutableEntry.exists() && mutableEntry.getValue() != null) {
                logger.debug("updating alert entry into the cache store invoke: {},{}",serviceId,serviceCode);
                final List<AlertEntry> alertEntries = mutableEntry.getValue();
                alertEntries.removeIf(alertEntry1 -> alertEntry1.getErrorCode().equals(serviceCode));
                alertEntries.add(alertEntry);
                mutableEntry.setValue(alertEntries);
            }else{
                throw new ResourceNotFoundException(String.format("Alert for %s with %s not found", serviceId,serviceCode));
            }
            // by api design nothing needed here
            return null;
        });
    }

    @Override
    public List<AlertHolder> getAllAlerts() {
        return StreamSupport.stream(getAlertsCache().spliterator(), false).map(stringListEntry -> AlertHolder.builder().
                alerts(stringListEntry.getValue()).
                serviceCode(stringListEntry.getKey()).build()).collect(Collectors.toList());

    }

    @Override
    public void deleteAlertEntry(String serviceId, String serviceCode) {
        final IgniteCache<String, List<AlertEntry>> alertsCache = getAlertsCache();
        // delete the alert if exist via invoke to make it atomic operation
        alertsCache.invoke(serviceId, (mutableEntry, objects) -> {
            if (mutableEntry.exists() && mutableEntry.getValue() != null) {
                logger.debug("deleting alert entry into the cache store invoke: {},{}",serviceId,serviceCode);
                final List<AlertEntry> alertEntries = mutableEntry.getValue();
                alertEntries.removeIf(alertEntry1 -> alertEntry1.getErrorCode().equals(serviceCode));
                mutableEntry.setValue(alertEntries);
            }else{
                throw new ResourceNotFoundException(String.format("Alert for %s with %s not found {},{}", serviceId,serviceCode));
            }
            // by api design nothing needed here
            return null;
        });

    }

    @Override
    public void createAlertEntry(AlertEntry alertEntry) {

        alertEntry.setTimestamp(System.currentTimeMillis());
        // get the alert config if any
        final Optional<AlertConfigEntry> configForServiceIdCodeIdCount =
                alertsConfigStore.getConfigForServiceIdCodeIdCount(alertEntry.getServiceId(), alertEntry.getErrorCode());
        // get the max count of alerts before sending mail
        final int maxCount = configForServiceIdCodeIdCount.isPresent()?
                configForServiceIdCodeIdCount.get().getMaxCount():1;
        final String mailtemplate=configForServiceIdCodeIdCount.isPresent()?
                configForServiceIdCodeIdCount.get().getMailTemplate():"ticket.html";
        // define the expiry of the entry in the cache
        final IgniteCache<String, List<AlertEntry>> alertsCache =  getAlertsCache();

        // execute the create via invoke for atomicity and check if max count of alerts is reached to send the mail or not
       final boolean isMaxCountExceeded = alertsCache.invoke(alertEntry.getServiceId(), (mutableEntry, objects) -> {

            if (mutableEntry.exists() && mutableEntry.getValue() != null) {
                logger.debug("creating alert entries into existing alerts list {}",mutableEntry.toString());
                final List<AlertEntry> alertEntries = mutableEntry.getValue();
                alertEntries.add(alertEntry);
                mutableEntry.setValue(alertEntries);
                if (alertEntries.size() >= maxCount) {
                    return true;
                }
                return false;
            } else {
                logger.debug("creating brand new alert entries into new alerts list {}",alertEntry.toString());
                List<AlertEntry> firstTimeToAdd = new ArrayList<>();
                firstTimeToAdd.add(alertEntry);
                mutableEntry.setValue(firstTimeToAdd);
                return false;
            }
        });

        // send the mail notification
        if (isMaxCountExceeded) {
            logger.debug("max alerts count is reached for : {}, start sending mail alert {}",alertEntry.toString());
            sendMail(alertEntry,configForServiceIdCodeIdCount.isPresent()?configForServiceIdCodeIdCount.get().getEmails(): Collections.EMPTY_LIST,mailtemplate);

        }

    }

    @Async
    protected void sendMail(AlertEntry alertEntry,List<String> emails, String mailTemplate){
        // send the mail then delete the entry
        final boolean doneSending = mailService.sendAlert(alertEntry, emails,mailTemplate);
        if(doneSending){
              deleteAlertEntry(alertEntry.getServiceId(),alertEntry.getErrorCode());
        }

    }

    // get alerts cache store
    protected IgniteCache<String, List<AlertEntry>> getAlertsCache() {

        return ignite.cache(CacheNames.Alerts.name());
    }

*/

}
