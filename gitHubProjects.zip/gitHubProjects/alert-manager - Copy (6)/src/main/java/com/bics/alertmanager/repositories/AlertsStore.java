package com.bics.alertmanager.repositories;

import com.bics.alertmanager.entities.AlertEntry;
import com.bics.alertmanager.entities.AlertHolder;

import java.util.List;

/**
 * Created by id961900 on 08/08/2017.
 */
public interface AlertsStore {
    List<AlertEntry> getAlertForServiceId(String serviceId);

    void updateAlertEntry(String serviceId, String errorCode, AlertEntry alertEntry);

    List<AlertEntry>  getAllAlerts();

    void deleteAlertEntry(String alertId);

    void createAlertEntry(AlertEntry alertEntry);


}
