package com.bics.alertmanager.services;

import com.bics.alertmanager.entities.AlertEntry;
import com.bics.common.mail.MailException;
import com.bics.mailproxy.client.ProxyMailer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
//import org.springframework.retry.annotation.CircuitBreaker;
//import org.springframework.retry.annotation.Recover;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import java.util.List;
import java.util.Locale;

/**
 * Created by id961900 on 17/08/2017.
 */
@Service
public class MailService {
    private static final Logger logger = LoggerFactory.getLogger(MailService.class);

    @Value("${mail.service.undeliverable}")
    private String undeliverable;

    @Value("${mail.from.bpo.mailbox}")
    private String mailFromBpo;

    @Value("${mail.default.receiver}")
    private String defaultReceiver;

    @Autowired
    private TemplateEngine templateEngine;

    @Autowired
    private ProxyMailer mailer;


    public boolean sendAlert(AlertEntry alertEntry,List<String> emails,String mailTemplate){
        logger.debug("Sending alert  e-mail to '{}'", emails.toString());
        Locale locale = Locale.getDefault();
        Context context = new Context(locale);
        context.setVariable("alert", alertEntry);
        String content = templateEngine.process(mailTemplate, context);
        return sendEmail(mailFromBpo, emails, "New Application ticket has been created", content);
    }

  //  @CircuitBreaker(maxAttempts = 2, openTimeout = 5000l, resetTimeout = 10000l,exclude = MailException.class)
    public boolean sendEmail(String from, List<String> to, String subject, String content) {
        logger.debug("Sending to {}",to.toString());
        try {
            mailer.send(toInternetAddresses(to),toInternetAddress(from),subject,content);
            logger.debug("Sent to {}",to.toString());
            return true;
        } catch (MailException mailException) {
            logger.warn("Error sending email", mailException);
            logger.warn("From: " + from);
            logger.warn("To: " + to);
            logger.warn("Subject: " + subject);
            logger.warn("Content: " + content);
            return false;
        }
    }



    private InternetAddress[] toInternetAddresses(List<String> addresses) {
        if (addresses == null) {
            return null;
        }
        InternetAddress[] internetAddresses = new InternetAddress[addresses.size()];
        for (int i = 0; i < addresses.size(); i++) {
            internetAddresses[i] = toInternetAddress(addresses.get(i));
        }
        return internetAddresses;
    }

    private InternetAddress toInternetAddress(String address) {
        if (address == null) {
            return null;
        }
        InternetAddress internetAddress = null;
        try {
            internetAddress = new InternetAddress(address);
        } catch (AddressException ex) {
            logger.error("Cannot convert to InternetAddress", ex);
            try {
                internetAddress = new InternetAddress(undeliverable);
            } catch (AddressException exx) {
                logger.error("Cannot convert to InternetAddress", ex);
            }
        }
        return internetAddress;
    }

    /**
     * The recover method needs to have same return type and parameters.
     *
     * @return
     */
   // @Recover
    private boolean fallbackForCall() {
        logger.error("Fallback for mail service call invoked, mail service is NOT reachable");
        return false;
    }
}
