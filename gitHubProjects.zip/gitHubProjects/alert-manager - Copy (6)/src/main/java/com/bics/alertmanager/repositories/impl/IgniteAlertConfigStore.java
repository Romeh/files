package com.bics.alertmanager.repositories.impl;

import com.bics.alertmanager.entities.AlertConfigEntry;
import com.bics.alertmanager.entities.CacheNames;
import com.bics.alertmanager.exception.ResourceNotFoundException;
import com.bics.alertmanager.repositories.AlertsConfigStore;
import org.apache.ignite.Ignite;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.cache.Cache;
import java.util.Optional;

/**
 * Created by id961900 on 18/08/2017.
 */
@Component
public class IgniteAlertConfigStore implements AlertsConfigStore {

    private static final Logger logger = LoggerFactory.getLogger(IgniteAlertConfigStore.class);

    @Autowired
    private Ignite ignite;

    @Override
    public AlertConfigEntry getConfigForServiceIdCodeId(String serviceId, String codeId) {
        return Optional.ofNullable(getAlertsConfigCache().get(serviceId + "_" + codeId))
                .orElseThrow(() -> new ResourceNotFoundException(String.format("Alert config for %s with %s not found", serviceId,codeId)));
    }

    @Override
    public void update(String serviceId, String codeId, AlertConfigEntry alertConfigEntry) {
        getAlertsConfigCache().put(serviceId + "_" + codeId, alertConfigEntry);
    }

    @Override
    public Optional<AlertConfigEntry> getConfigForServiceIdCodeIdCount(String serviceId, String codeId) {
        return Optional.ofNullable(getAlertsConfigCache().get(serviceId + "_" + codeId));

    }


    public Cache<String, AlertConfigEntry> getAlertsConfigCache() {
        return ignite.getOrCreateCache(CacheNames.AlertsConfig.name());
    }
}
