package com.bics.alertmanager;

import com.bics.alertmanager.entities.AlertsConfiguration;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.annotation.EnableScheduling;
//import org.springframework.retry.annotation.EnableRetry;


@SpringBootApplication
@EnableAsync
@EnableScheduling
//@EnableRetry
public class AlertManagerApplication {


    public static void main(String[] args) {

        final ConfigurableApplicationContext run = SpringApplication.run(AlertManagerApplication.class, args);
        AlertsConfiguration cfg = run.getBean(AlertsConfiguration.class);
        cfg.getAlertConfigurations().forEach(alertConfigEntity -> System.out.println(alertConfigEntity.getEmails()));


    }



}
