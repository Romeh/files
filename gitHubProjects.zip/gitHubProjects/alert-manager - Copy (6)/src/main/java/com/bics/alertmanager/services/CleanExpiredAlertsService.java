package com.bics.alertmanager.services;

import com.bics.alertmanager.entities.AlertEntry;
import com.bics.alertmanager.entities.CacheNames;
import com.bics.alertmanager.repositories.impl.IgniteAlertConfigStore;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.query.FieldsQueryCursor;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.cache.query.SqlQuery;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.actuate.health.Health;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.StreamSupport;

/**
 * Created by id961900 on 22/08/2017.
 */
@Service
public class CleanExpiredAlertsService {
    private static final Logger logger = LoggerFactory.getLogger(CleanExpiredAlertsService.class);


    @Autowired
    Ignite ignite;

    @Scheduled(initialDelayString = "${initialDelay}", fixedDelayString = "${fixedDelay}")
    public void cleanExpiredRecords(){
        logger.debug("Starting the clean up job to clear the expired records");
        long towMinutesRange = System.currentTimeMillis()-900000;
        final IgniteCache<String, List<AlertEntry>> alertsCache = getAlertsCache();
        final String sql = "delete from AlertEntry where timestamp <= ?";
        SqlFieldsQuery query = new SqlFieldsQuery(sql);
        query.setArgs(towMinutesRange);
        final FieldsQueryCursor<List<?>> cleanUpResult = alertsCache.query(query);
        logger.debug("Finished cleaning out {} records",cleanUpResult.getAll().size());
    }

    // get alerts cache store
    protected IgniteCache<String, List<AlertEntry>> getAlertsCache() {

        return ignite.cache(CacheNames.Alerts.name());
    }
}
