package io.vertx.example.ignite.core.query.exceptions;

/**
 * Created by ftr on 10/03/2017.
 */
public class ScalarValueNotFoundException extends RuntimeException{
    public ScalarValueNotFoundException(String message) {
        super(message);
    }
}
