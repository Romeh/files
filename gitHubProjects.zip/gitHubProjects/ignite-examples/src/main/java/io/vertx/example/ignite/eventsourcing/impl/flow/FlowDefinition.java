package io.vertx.example.ignite.eventsourcing.impl.flow;

import io.vertx.example.ignite.eventsourcing.Command;
import io.vertx.example.ignite.eventsourcing.Event;
import io.vertx.example.ignite.eventsourcing.impl.eventstore.EventStream;
import lombok.*;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;

/**
 * Created by id961900 on 15/05/2017.
 */
@Getter
@ToString
@EqualsAndHashCode
public class FlowDefinition {
  private Map<Class<? extends Event>,BiConsumer< Event,EventStream>> eventHandlers=new HashMap<>();
  private Map<Class<? extends Command>,BiFunction<Command,EventStream, Event>> commandHandlers=new HashMap<>();
}
