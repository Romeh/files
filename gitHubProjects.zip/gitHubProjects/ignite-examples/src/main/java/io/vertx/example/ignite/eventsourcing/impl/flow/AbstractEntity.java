package io.vertx.example.ignite.eventsourcing.impl.flow;

/**
 * Created by id961900 on 15/05/2017.
 */
public abstract class AbstractEntity implements EventSourcedEntity {
  public AbstractEntity (){
      this.flow();
  }

}
