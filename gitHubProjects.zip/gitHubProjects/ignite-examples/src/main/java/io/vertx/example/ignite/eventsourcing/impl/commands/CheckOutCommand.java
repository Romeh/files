package io.vertx.example.ignite.eventsourcing.impl.commands;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonTypeName;
import io.vertx.example.ignite.eventsourcing.Command;
import lombok.*;

import java.util.Map;

/**
 * Created by id961900 on 09/05/2017.
 */
@AllArgsConstructor
@NoArgsConstructor
@EqualsAndHashCode
@ToString
@JsonTypeName("CheckOutCommand")
public class CheckOutCommand implements Command {

  @Getter
  @Setter
  private Map<String,String> data;
  @Getter
  @Setter
  String eventTag;

}
