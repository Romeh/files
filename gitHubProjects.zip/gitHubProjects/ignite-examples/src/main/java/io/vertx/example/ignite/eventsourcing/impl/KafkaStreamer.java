package io.vertx.example.ignite.eventsourcing.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import io.netty.handler.flow.FlowControlHandler;
import io.vertx.example.ignite.eventsourcing.Command;
import io.vertx.example.ignite.eventsourcing.Event;
import io.vertx.example.ignite.eventsourcing.impl.commands.CheckOutCommand;
import io.vertx.example.ignite.eventsourcing.impl.events.Created;
import io.vertx.example.ignite.eventsourcing.impl.eventstore.EventStream;
import io.vertx.example.ignite.eventsourcing.impl.example.OrderAggregate;
import io.vertx.example.ignite.eventsourcing.impl.flow.FlowContext;
import io.vertx.example.ignite.eventsourcing.impl.kafka.*;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.apache.kafka.common.serialization.StringSerializer;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KStreamBuilder;
import org.apache.kafka.streams.processor.StateStoreSupplier;
import org.apache.kafka.streams.processor.TopologyBuilder;
import org.apache.kafka.streams.state.Stores;

import java.time.LocalDateTime;
import java.util.Properties;

/**
 * Created by id961900 on 09/05/2017.
 */
public class KafkaStreamer {


  private static final String COMMANDS = "commands";
  private static final String EVENTS = "events";
  private KafkaStreams kafkaStreams;


  public void startStreams() {

    FlowLookup.getInstance().putFlowHandler("", OrderAggregate.class);
    StreamsConfig streamsConfig = new StreamsConfig(getProperties());
    StringDeserializer stringDeserializer = new StringDeserializer();
    StringSerializer stringSerializer = new StringSerializer();
    JsonDeserializer<Command> commandJsonDeserializer = new JsonDeserializer<>(Command.class);
    JsonSerializer<Event> eventJsonSerializer = new JsonSerializer<>();
    KStreamBuilder builder = new KStreamBuilder();


    builder.addSource("CommandsSource",stringDeserializer, commandJsonDeserializer,COMMANDS);
    builder.addProcessor("CommandsProcessor",CommandsProcessor::new,"CommandsSource");
    builder.addProcessor("eventsProcessor",EventsProcessor::new,"CommandsProcessor");
    builder.addSink("eventsTopicStore",EVENTS,stringSerializer,eventJsonSerializer,"eventsProcessor");


    StateStoreSupplier orderState = Stores
      .create("StateStore")
      .withStringKeys()
      .withValues(getEventsSerds())
      .inMemory()
      .build();

    builder.addStateStore(orderState);

    kafkaStreams = new KafkaStreams(builder, streamsConfig);
    kafkaStreams.cleanUp(); // -- only because we are using in-memory
    kafkaStreams.start();

    Runtime.getRuntime().addShutdownHook(new Thread(() -> kafkaStreams.close()));

  }

  private static Properties getProperties() {
    Properties props = new Properties();
    props.put(StreamsConfig.APPLICATION_ID_CONFIG, "TestApp");
    props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
    props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
    props.put(StreamsConfig.STATE_DIR_CONFIG, "C:\\Dev\\kafka-streams");

    return props;
  }


  private Serde<Command> getCommandSerds() {
    JsonSerializer<Command> envelopeJsonSerializer = new JsonSerializer<>();
    JsonDeserializer<Command> envelopeJsonDeserializer = new JsonDeserializer<>(Command.class);
    return Serdes.serdeFrom(envelopeJsonSerializer, envelopeJsonDeserializer);
  }


  private Serde<EventStream> getEventsSerfs() {
    JsonSerializer<EventStream> envelopeJsonSerializer = new JsonSerializer<>();
    JsonDeserializer<EventStream> envelopeJsonDeserializer = new JsonDeserializer<>(EventStream.class);
    return Serdes.serdeFrom(envelopeJsonSerializer, envelopeJsonDeserializer);
  }

  private Serde<Event> getEventsSerds() {
    JsonSerializer<Event> envelopeJsonSerializer = new JsonSerializer<>();
    JsonDeserializer<Event> envelopeJsonDeserializer = new JsonDeserializer<>(Event.class);
    return Serdes.serdeFrom(envelopeJsonSerializer, envelopeJsonDeserializer);
  }

  public static void main(String... args) {
    new KafkaStreamer().startStreams();
    final ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
    final KafkaCommandsPublisher kafkaCommandsPublisher = new KafkaCommandsPublisher("localhost:9092", objectMapper);
    final CheckOutCommand checkOutCommand = new CheckOutCommand();
    kafkaCommandsPublisher.publish(COMMANDS, checkOutCommand, "order1");

  }


}
