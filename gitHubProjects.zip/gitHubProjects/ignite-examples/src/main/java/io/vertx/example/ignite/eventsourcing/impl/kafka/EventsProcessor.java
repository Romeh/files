package io.vertx.example.ignite.eventsourcing.impl.kafka;

import io.vertx.example.ignite.eventsourcing.Event;
import io.vertx.example.ignite.eventsourcing.impl.FlowLookup;
import io.vertx.example.ignite.eventsourcing.impl.events.Failed;
import io.vertx.example.ignite.eventsourcing.impl.eventstore.EventStream;
import io.vertx.example.ignite.eventsourcing.impl.flow.EventSourcedEntity;
import io.vertx.example.ignite.eventsourcing.impl.flow.FlowContext;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.streams.processor.AbstractProcessor;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.kafka.streams.state.KeyValueStore;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Map;

/**
 * Created by id961900 on 12/05/2017.
 */
public class EventsProcessor extends AbstractProcessor<String, Event> {
  private final static String FLOW_ID = "FlowId";

  private KeyValueStore<String, EventStream> stateStore;

  @Override
  public void init(ProcessorContext processorContext) {
    super.init(processorContext);
    this.stateStore = (KeyValueStore<String, EventStream>) processorContext.getStateStore("StateStore");

  }

  @Override
  public void process(String aggregateId, Event event) {
    System.out.println("events processor start : " + event.toString() + " order id" + aggregateId);
    final String flowName = event.getOrderContext().getContextData().get(FLOW_ID);
    final Map<String, String> contextData = Collections.EMPTY_MAP;
    final EventStream eventStream = stateStore.get(aggregateId);
    if (StringUtils.isNotBlank(flowName)) {
      final EventSourcedEntity flowHandler = FlowLookup.getInstance().getFlowHandler(flowName);
      if (flowHandler == null) {
        System.out.println("events processor flowHandler is null : " + event.toString() + " order id" + aggregateId);
        contextData.put("errorCode", "001");
        contextData.put("errorMsg", "No Flow handler defined for that flow" + flowName);
        if (eventStream != null) {
          stateStore.put(aggregateId, eventStream.appendEvent(buildFailedEvent(contextData, aggregateId,event.getEventTag())));
        } else {
          stateStore.put(aggregateId, new EventStream().appendEvent(buildFailedEvent(contextData, aggregateId,event.getEventTag())));
        }
        context().commit();
      } else {
        if (eventStream != null) {
          System.out.println("events processor adding event : " + event.toString() + " order id" + aggregateId);
          System.out.println("eventsProcessor : " + eventStream.toString());
          stateStore.put(aggregateId, eventStream.appendEvent(event));
          flowHandler.onEvent(event, eventStream);
          context().commit();
        } else {
          System.out.println("events processor first event : " + event.toString() + " order id" + aggregateId);
          stateStore.put(aggregateId, new EventStream().appendEvent(event));
          flowHandler.onEvent(event, eventStream);
          context().commit();
        }
      }
    } else {
      System.out.println("events processor flowName is null in context data : " + event.toString() + " order id" + aggregateId);
      contextData.put("errorCode", "002");
      contextData.put("errorMsg", "No Fow Id is defined into the event" + event.toString() + " for aggregate id" + aggregateId);
      if (eventStream != null) {
        stateStore.put(aggregateId, eventStream.appendEvent(buildFailedEvent(contextData, aggregateId,event.getEventTag())));
      } else {
        stateStore.put(aggregateId, new EventStream().appendEvent(buildFailedEvent(contextData, aggregateId,event.getEventTag())));
      }
      context().commit();
    }

  }

  @Override
  public void punctuate(long l) {

  }

  @Override
  public void close() {
  }

  private Failed buildFailedEvent(Map<String, String> contextData, String aggregateId, String eventTag) {
    return Failed.builder().time(LocalDateTime.now()).eventTag(eventTag)
      .orderContext(FlowContext.builder()
        .orderId(aggregateId)
        .contextData(contextData).build()).build();
  }


      /*System.out.println("events processor start : "+event.toString()+" order id"+s);
    final EventStream eventStream = stateStore.get(s);
    if(eventStream !=null){
      System.out.println("events processor found : "+ eventStream.toString()+" order id"+s);
        stateStore.put(s, eventStream.appendEvent(event));
      }else{
       System.out.println("events processor new : "+" order id"+s);
        stateStore.put(s,new EventStream().appendEvent(event));
      }
      context().commit();

    System.out.println("events processor start : "+event.toString()+" order id"+s);*/
}
