package io.vertx.example.ignite.eventsourcing.impl;

import io.vertx.example.ignite.eventsourcing.impl.flow.EventSourcedEntity;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by id961900 on 09/05/2017.
 */
public class FlowLookup {
  private final Map<String, Class<? extends EventSourcedEntity>> map = new HashMap<>();
  private final static FlowLookup instance = new FlowLookup();

  public static FlowLookup getInstance() {
    return instance;
  }

  private FlowLookup() {
  }

  public EventSourcedEntity getFlowHandler(String key) {
    return newInstance(map.get(key));
  }

  public void putFlowHandler(String key, Class<? extends EventSourcedEntity> flow) {
    map.put(key, flow);
  }

  private EventSourcedEntity newInstance(Class<? extends EventSourcedEntity> flow) {
    try {
      return (EventSourcedEntity) Class.forName(flow.getName()).newInstance();
    } catch (IllegalAccessException | InstantiationException | ClassNotFoundException e) {
      return null;
    }
  }


}
