package io.vertx.example.ignite.eventsourcing.impl.flow;

import java.util.function.Consumer;

/**
 * Created by id961900 on 15/05/2017.
 */
public class FlowDefinitionDSL {
  private final FlowDefinition flowDefinition=new FlowDefinition();

  public static FlowDefinition Flow(Consumer<FlowDefinitionDSL> FlowDefinitionConsumer) {
    FlowDefinitionDSL flowDSLBuilder = new FlowDefinitionDSL();
    FlowDefinitionConsumer.accept(flowDSLBuilder);
    return flowDSLBuilder.flowDefinition;

  }

  public FlowDefinitionDSL onCommand(final Consumer<CommandStep.CommandStepBuilder> commandStep) {
    CommandStep.CommandStepBuilder step=CommandStep.builder();
    commandStep.accept(step);
    CommandStep definedStep=step.build();
    this.flowDefinition.getCommandHandlers().put(definedStep.getWhen(), definedStep.getDoAction());
    return this;
  }



  public FlowDefinitionDSL onEvent(final Consumer<EventStep.EventStepBuilder> eventStep) {
    EventStep.EventStepBuilder step=EventStep.builder();
    eventStep.accept(step);
    EventStep definedStep=step.build();
    this.flowDefinition.getEventHandlers().put(definedStep.getWhen(), definedStep.getDoAction());
    return this;
  }


}
