package io.vertx.example.ignite.eventsourcing.impl.kafka;

import io.vertx.example.ignite.eventsourcing.Command;
import io.vertx.example.ignite.eventsourcing.Event;
import io.vertx.example.ignite.eventsourcing.impl.FlowLookup;
import io.vertx.example.ignite.eventsourcing.impl.events.Failed;
import io.vertx.example.ignite.eventsourcing.impl.flow.EventSourcedEntity;
import io.vertx.example.ignite.eventsourcing.impl.flow.FlowContext;
import io.vertx.example.ignite.eventsourcing.impl.eventstore.EventStream;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.streams.processor.AbstractProcessor;
import org.apache.kafka.streams.processor.ProcessorContext;
import org.apache.kafka.streams.state.KeyValueStore;

import java.time.LocalDateTime;
import java.util.Collections;
import java.util.Map;

/**
 * Created by id961900 on 12/05/2017.
 */
public class CommandsProcessor extends AbstractProcessor<String, Command> {

  private final static String FLOW_ID = "FlowId";

  private KeyValueStore<String, EventStream> stateStore;

  @Override
  public void init(ProcessorContext processorContext) {
    super.init(processorContext);
    this.stateStore = (KeyValueStore<String, EventStream>) processorContext.getStateStore("StateStore");
  }

  @Override
  public void process(String aggregateId, Command command) {

    final String flowName = command.getData().get(FLOW_ID);
    final Map<String, String> contextData = Collections.EMPTY_MAP;
    if (StringUtils.isNotBlank(flowName)) {
      final EventStream eventStream = stateStore.get(aggregateId);
      final EventSourcedEntity flowHandler = FlowLookup.getInstance().getFlowHandler(flowName);
      if (flowHandler == null) {
        contextData.put("errorCode", "001");
        contextData.put("errorMsg", "No Flow handler defined for that flow" + flowName);
        context().forward(aggregateId, buildFailedEvent(contextData, aggregateId,command.getEventTag()));
        context().commit();
      } else {
        if (eventStream != null) {
          System.out.println("CommandsProcessor : " + eventStream.toString());
          final Event event = flowHandler.onCommand(command, eventStream);
          context().forward(aggregateId, event);
          context().commit();
        } else {
          final Event firstEvent = flowHandler.onCommand(command, eventStream);
         // stateStore.put(aggregateId, new EventStream().appendEvent(firstEvent));
          context().forward(aggregateId, firstEvent);
          context().commit();
        }
      }
    } else {

      contextData.put("errorCode", "002");
      contextData.put("errorMsg", "No Fow Id is defined into the command" + command.toString() + " for aggregate id" + aggregateId);
      context().forward(aggregateId, buildFailedEvent(contextData, aggregateId,command.getEventTag()));
      context().commit();
    }

  }

  @Override
  public void punctuate(long l) {

  }

  @Override
  public void close() {

  }


  private Failed buildFailedEvent(Map<String, String> contextData, String aggregateId,String eventTag) {
    return Failed.builder().time(LocalDateTime.now())
      .orderContext(FlowContext.builder()
        .orderId(aggregateId)
        .contextData(contextData).build()).build();
  }

}
