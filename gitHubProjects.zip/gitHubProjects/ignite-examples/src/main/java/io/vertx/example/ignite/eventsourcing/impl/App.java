package io.vertx.example.ignite.eventsourcing.impl;

import io.vertx.core.Vertx;
import io.vertx.core.VertxOptions;
import io.vertx.example.ignite.eventsourcing.ConsumerApp;

/**
 * Created by id961900 on 09/05/2017.
 */
public class App {

  public static void main(String[] args) {
    Vertx.clusteredVertx(new VertxOptions().setClustered(true), ar -> {
      if (ar.failed()) {
        System.err.println("Cannot create vert.x instance : " + ar.cause());
      } else {
        Vertx vertx = ar.result();

        vertx.deployVerticle(ConsumerApp.class.getName());
      }
    });
  }

}
