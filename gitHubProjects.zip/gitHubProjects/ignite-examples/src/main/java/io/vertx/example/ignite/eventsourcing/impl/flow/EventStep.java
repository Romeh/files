package io.vertx.example.ignite.eventsourcing.impl.flow;

import io.vertx.example.ignite.eventsourcing.Event;
import io.vertx.example.ignite.eventsourcing.impl.eventstore.EventStream;
import lombok.*;

import java.util.function.BiConsumer;
import java.util.function.BiFunction;

/**
 * Created by id961900 on 15/05/2017.
 */

@Getter
@ToString
@Setter
@EqualsAndHashCode
@Builder
public class EventStep {
  private Class<? extends Event> when;
  private BiConsumer<Event,EventStream> doAction;
}
