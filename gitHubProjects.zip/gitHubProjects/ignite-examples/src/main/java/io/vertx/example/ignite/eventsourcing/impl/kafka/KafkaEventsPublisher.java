package io.vertx.example.ignite.eventsourcing.impl.kafka;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.vertx.example.ignite.eventsourcing.Command;
import io.vertx.example.ignite.eventsourcing.Event;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class KafkaEventsPublisher {
    private static Logger LOG = LoggerFactory.getLogger(KafkaEventsPublisher.class);
    private final KafkaProducer producer;
    private final ObjectMapper objectMapper;

    public KafkaEventsPublisher(String zookeeper, ObjectMapper objectMapper) {
        Properties props = new Properties();
        props.put("bootstrap.servers", zookeeper);
        props.put("key.serializer", StringSerializer.class);
        props.put("value.serializer", StringSerializer.class);

        this.producer = new KafkaProducer<>(props);
        this.objectMapper = objectMapper;
    }


    public  void publish(String streamName, Event event, String id) {
        LOG.debug("Publishing event ["+event.getClass().getSimpleName()+"] for [" + streamName + "]");

        String topic = streamName;
        String value = serializeEnvelope(event);

        // -- the key of the record is an aggregate Id to ensure the order of the events for the same aggregate
        ProducerRecord<String, String> record = new ProducerRecord<>(topic, id, value);
        producer.send(record);
    }

    private String serializeEnvelope(Event envelope) {
        String json;
        try {
            json = objectMapper.writeValueAsString(envelope);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return json;
    }
}
