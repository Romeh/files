package io.vertx.example.ignite.eventsourcing.impl.kafka;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.vertx.example.ignite.eventsourcing.Command;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Properties;

public class KafkaCommandsPublisher {
    private static Logger LOG = LoggerFactory.getLogger(KafkaCommandsPublisher.class);
    private final KafkaProducer producer;
    private final ObjectMapper objectMapper;

    public KafkaCommandsPublisher(String zookeeper, ObjectMapper objectMapper) {
        Properties props = new Properties();
        props.put("bootstrap.servers", zookeeper);
        props.put("key.serializer", StringSerializer.class);
        props.put("value.serializer", StringSerializer.class);

        this.producer = new KafkaProducer<>(props);
        this.objectMapper = objectMapper;
    }


    public  void publish(String streamName, Command cmd, String id) {
        LOG.debug("Publishing event ["+cmd.getClass().getSimpleName()+"] for [" + streamName + "]");

        String topic = streamName;
        String value = serializeEnvelope(cmd);

        // -- the key of the record is an aggregate Id to ensure the order of the events for the same aggregate
        ProducerRecord<String, String> record = new ProducerRecord<>(topic, id, value);
        producer.send(record);
    }

    private String serializeEnvelope(Command envelope) {
        String json;
        try {
            json = objectMapper.writeValueAsString(envelope);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return json;
    }
}
