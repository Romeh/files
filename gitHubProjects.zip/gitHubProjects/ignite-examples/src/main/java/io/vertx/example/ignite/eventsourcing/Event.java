package io.vertx.example.ignite.eventsourcing;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import io.vertx.example.ignite.eventsourcing.impl.flow.FlowContext;
import io.vertx.example.ignite.eventsourcing.impl.events.*;

import java.io.Serializable;
import java.time.LocalDateTime;

/**
 * Created by id961900 on 09/05/2017.
 */
@JsonTypeInfo(
  use = JsonTypeInfo.Id.NAME,
  include = JsonTypeInfo.As.PROPERTY)
@JsonSubTypes({
  @JsonSubTypes.Type(value = Created.class, name = "Created"),
  @JsonSubTypes.Type(value = Failed.class, name = "Failed"),
  @JsonSubTypes.Type(value = Rejected.class, name = "Rejected"),
  @JsonSubTypes.Type(value = InventoryDeducted.class, name = "InventoryDeducted"),
  @JsonSubTypes.Type(value = Executed.class, name = "Executed"),
  @JsonSubTypes.Type(value = Cancelled.class, name = "Cancelled"),
  @JsonSubTypes.Type(value = Closed.class, name = "Closed")
})
public interface Event extends Serializable {
  FlowContext getOrderContext();

  void setOrderContext(FlowContext orderContext);

  void setEventTag(String eventTag);

  String getEventTag();

  void setTime(LocalDateTime time);

  LocalDateTime getTime();

}
