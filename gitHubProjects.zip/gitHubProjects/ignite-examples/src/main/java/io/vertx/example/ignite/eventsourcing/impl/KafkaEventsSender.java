package io.vertx.example.ignite.eventsourcing.impl;

import io.vertx.example.ignite.eventsourcing.Event;
import io.vertx.example.ignite.eventsourcing.EventPublisher;

/**
 * Created by id961900 on 09/05/2017.
 */
public class KafkaEventsSender implements EventPublisher {
  @Override
  public  void publish(String streamName, Event event) {

  }
}
