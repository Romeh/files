package io.vertx.example.ignite.eventsourcing.impl.eventstore;


import com.fasterxml.jackson.annotation.JsonIgnore;
import io.vertx.example.ignite.eventsourcing.Event;
import lombok.ToString;

import java.io.Serializable;
import java.util.ArrayDeque;
import java.util.Deque;
import java.util.stream.Stream;

@ToString
public class EventStream implements Serializable {

  private final ArrayDeque<Event> events;

  public EventStream() {
    events = new ArrayDeque<>();
  }

  public EventStream(final ArrayDeque<Event> events) {
    this.events = events;
  }


  @JsonIgnore
  public Stream<Event> getStreamOfEvents() {
    return events.stream();

  }

  public ArrayDeque<Event> getEvents() {
    return events;
  }

  @JsonIgnore
  public EventStream append(final Deque<Event> newEvents) {
    ArrayDeque<Event> tmpEvents = new ArrayDeque<>(this.events);
    tmpEvents.addAll(newEvents);
    return new EventStream(tmpEvents);
  }

  @JsonIgnore
  public EventStream appendEvent(final Event newEvent) {
    ArrayDeque<Event> tmpEvents = new ArrayDeque<>(this.events);
    tmpEvents.add(newEvent);
    return new EventStream(tmpEvents);
  }

  @JsonIgnore
  public Event getLastEvent() {
    return events.getLast();
  }

}
