package io.vertx.example.ignite.eventsourcing.impl.example;

import io.vertx.example.ignite.eventsourcing.Command;
import io.vertx.example.ignite.eventsourcing.Event;
import io.vertx.example.ignite.eventsourcing.impl.commands.CreateOrderCommand;
import io.vertx.example.ignite.eventsourcing.impl.events.*;
import io.vertx.example.ignite.eventsourcing.impl.eventstore.EventStream;
import io.vertx.example.ignite.eventsourcing.impl.flow.AggregateType;
import io.vertx.example.ignite.eventsourcing.impl.flow.EventSourcedEntity;
import io.vertx.example.ignite.eventsourcing.impl.flow.FlowContext;
import io.vertx.example.ignite.eventsourcing.impl.flow.FlowDefinition;

import java.time.LocalDateTime;
import java.util.function.BiConsumer;
import java.util.function.BiFunction;

import static io.vertx.example.ignite.eventsourcing.impl.flow.FlowDefinitionDSL.Flow;

/**
 * Created by id961900 on 15/05/2017.
 */
public class OrderAggregate implements EventSourcedEntity {
  private static FlowDefinition orderFlow;
  private final static String FLOW_TAG = "ORDER";

  public OrderAggregate() {
    flow();
  }

  @Override
  public void flow() {

    orderFlow = Flow(orderFlow -> orderFlow
      .onCommand(createOrder -> createOrder.when(CreateOrderCommand.class).doAction(handleCreateCommand))
      .onEvent(orderCreated -> orderCreated.when(Created.class).doAction(handleCreatedEvent))
      .onEvent(validated -> validated.when(Validated.class).doAction(handleValidated))
      .onEvent(executed -> executed.when(Executed.class).doAction(handleExecuted))
      .onEvent(failed -> failed.when(Failed.class).doAction(handleFailed))
      .onEvent(rejected -> rejected.when(Rejected.class).doAction(handleRejected))
    );
  }

  @Override
  public Event onCommand(Command command, EventStream eventStream) {
    return orderFlow.getCommandHandlers().
      getOrDefault(command.getClass(), (command1, eventStream1) -> new Failed()).apply(command, eventStream);
  }

  @Override
  public void onEvent(Event event, EventStream eventStream) {
    orderFlow.getEventHandlers().getOrDefault(event.getClass(), (event1, eventStream1) -> System.out.println("No event handler"))
      .accept(event, eventStream);
  }


  private BiFunction<Command, EventStream, Event> handleCreateCommand = (createOrderCommand, eventStream) ->
    Created.builder().time(LocalDateTime.now())
      .eventTag(FLOW_TAG)
      .orderContext(FlowContext.builder()
        .contextData(createOrderCommand.getData()).build())
      .build();
  ;

  private BiConsumer<Event, EventStream> handleCreatedEvent = (event, eventStream) ->
    Validated.builder().time(LocalDateTime.now())
      .eventTag(FLOW_TAG).orderContext(event.getOrderContext()).build();

  private BiConsumer<Event, EventStream> handleValidated = (event, eventStream) ->
    Executed.builder().time(LocalDateTime.now())
      .eventTag(FLOW_TAG).orderContext(event.getOrderContext()).build();

  private BiConsumer<Event, EventStream> handleExecuted = (event, eventStream) -> System.out.println("executed order!");

  private BiConsumer<Event, EventStream> handleFailed = (event, eventStream) -> System.out.println("Failed order!");

  private BiConsumer<Event, EventStream> handleRejected = (event, eventStream) -> System.out.println("rejected order!");


}
