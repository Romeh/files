package io.vertx.example.ignite.eventsourcing;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import io.vertx.example.ignite.eventsourcing.impl.commands.CheckOutCommand;
import io.vertx.example.ignite.eventsourcing.impl.events.Created;
import io.vertx.example.ignite.eventsourcing.impl.eventstore.EventStream;
import io.vertx.example.ignite.eventsourcing.impl.flow.FlowContext;
import io.vertx.example.ignite.eventsourcing.impl.kafka.EventsProcessor;
import io.vertx.example.ignite.eventsourcing.impl.kafka.JsonDeserializer;
import io.vertx.example.ignite.eventsourcing.impl.kafka.JsonSerializer;
import io.vertx.example.ignite.eventsourcing.impl.kafka.KafkaCommandsPublisher;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.Serde;
import org.apache.kafka.common.serialization.Serdes;
import org.apache.kafka.streams.KafkaStreams;
import org.apache.kafka.streams.KeyValue;
import org.apache.kafka.streams.StreamsConfig;
import org.apache.kafka.streams.kstream.KStream;
import org.apache.kafka.streams.kstream.KStreamBuilder;
import org.apache.kafka.streams.processor.StateStoreSupplier;
import org.apache.kafka.streams.state.Stores;

import java.time.LocalDateTime;
import java.util.Properties;

/**
 * Created by id961900 on 09/05/2017.
 */
public class KafkaStreamerCopy {


  private static final String COMMANDS = "commands";
  private static final String EVENTS = "events";
  private final EventsProcessor eventsProcessor = new EventsProcessor();
  private KafkaStreams kafkaStreams;


  public void startStreams() {

    StreamsConfig streamsConfig = new StreamsConfig(getProperties());

    Serde<Command> commandSerde = getCommandSerds();

    Serde<EventStream> eventSerde = getEventsSerfs();

    Serde<Event> eventsSerds = getEventsSerds();

    KStreamBuilder builder = new KStreamBuilder();

    final KStream<String, Command> commands = builder.stream(Serdes.String(), commandSerde, COMMANDS);

    final KStream<String, Event> eventKStream = commands.map((s, command) -> {
      Event event = new Created();
      event.setOrderContext(FlowContext.builder().
        orderId(s).time(LocalDateTime.now()).build());
      return new KeyValue<>(s, event);
    }).through(Serdes.String(), eventsSerds, EVENTS);

    StateStoreSupplier orderState = Stores
      .create("StateStore")
      .withStringKeys()
      .withValues(eventSerde)
      .inMemory()
      .build();


    builder.addStateStore(orderState);
    eventKStream.process(EventsProcessor::new, orderState.name());

    kafkaStreams = new KafkaStreams(builder, streamsConfig);
    kafkaStreams.cleanUp(); // -- only because we are using in-memory
    kafkaStreams.start();

    Runtime.getRuntime().addShutdownHook(new Thread(() -> kafkaStreams.close()));

  }

  private static Properties getProperties() {
    Properties props = new Properties();
    props.put(StreamsConfig.APPLICATION_ID_CONFIG, "TestApp");
    props.put(StreamsConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092");
    props.put(ConsumerConfig.AUTO_OFFSET_RESET_CONFIG, "earliest");
    props.put(StreamsConfig.STATE_DIR_CONFIG, "C:\\Dev\\kafka-streams");

    return props;
  }


  private Serde<Command> getCommandSerds() {
    JsonSerializer<Command> envelopeJsonSerializer = new JsonSerializer<>();
    JsonDeserializer<Command> envelopeJsonDeserializer = new JsonDeserializer<>(Command.class);
    return Serdes.serdeFrom(envelopeJsonSerializer, envelopeJsonDeserializer);
  }


  private Serde<EventStream> getEventsSerfs() {
    JsonSerializer<EventStream> envelopeJsonSerializer = new JsonSerializer<>();
    JsonDeserializer<EventStream> envelopeJsonDeserializer = new JsonDeserializer<>(EventStream.class);
    return Serdes.serdeFrom(envelopeJsonSerializer, envelopeJsonDeserializer);
  }

  private Serde<Event> getEventsSerds() {
    JsonSerializer<Event> envelopeJsonSerializer = new JsonSerializer<>();
    JsonDeserializer<Event> envelopeJsonDeserializer = new JsonDeserializer<>(Event.class);
    return Serdes.serdeFrom(envelopeJsonSerializer, envelopeJsonDeserializer);
  }

  public static void main(String... args) {
    new KafkaStreamerCopy().startStreams();
    final ObjectMapper objectMapper = new ObjectMapper();
    objectMapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
    final KafkaCommandsPublisher kafkaCommandsPublisher = new KafkaCommandsPublisher("localhost:9092", objectMapper);
    final CheckOutCommand checkOutCommand = new CheckOutCommand();
    kafkaCommandsPublisher.publish(COMMANDS, checkOutCommand, "order1");
    //kafkaCommandsPublisher.publish(COMMANDS,checkOutCommand,"order1");
    //  kafkaCommandsPublisher.publish(COMMANDS,checkOutCommand,"order2");
    // kafkaCommandsPublisher.publish(COMMANDS,checkOutCommand,"order3");
  }


}
