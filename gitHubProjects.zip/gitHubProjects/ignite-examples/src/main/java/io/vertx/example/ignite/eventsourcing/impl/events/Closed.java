package io.vertx.example.ignite.eventsourcing.impl.events;

import com.fasterxml.jackson.annotation.JsonTypeName;
import com.fasterxml.jackson.databind.annotation.JsonDeserialize;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import com.fasterxml.jackson.datatype.jsr310.deser.LocalDateTimeDeserializer;
import com.fasterxml.jackson.datatype.jsr310.ser.LocalDateTimeSerializer;
import io.vertx.example.ignite.eventsourcing.Event;
import io.vertx.example.ignite.eventsourcing.impl.flow.FlowContext;
import lombok.*;

import java.time.LocalDateTime;

/**
 * Created by id961900 on 09/05/2017.
 */

@EqualsAndHashCode
@ToString
@JsonTypeName("Closed")
@AllArgsConstructor
@NoArgsConstructor
@Builder
public class Closed implements Event {

  @Getter
  @Setter
  FlowContext orderContext;

  @JsonDeserialize(using = LocalDateTimeDeserializer.class)
  @JsonSerialize(using = LocalDateTimeSerializer.class)
  @Getter
  @Setter
  private LocalDateTime time;

  @Getter
  @Setter
  String eventTag;


}
