package io.vertx.example.ignite.commons.requests;

/**
 * Created by ftr on 15/03/2017.
 */
public interface HasKey {

    byte[] getKey();
}
