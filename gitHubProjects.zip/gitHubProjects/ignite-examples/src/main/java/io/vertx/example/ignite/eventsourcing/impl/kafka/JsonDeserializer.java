package io.vertx.example.ignite.eventsourcing.impl.kafka;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.SerializationFeature;
import com.fasterxml.jackson.datatype.jdk8.Jdk8Module;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;
import org.apache.kafka.common.serialization.Deserializer;

import java.io.IOException;
import java.util.Map;

/**
 * Created by veniamin on 18/02/2017.
 */
public class JsonDeserializer<T> implements Deserializer<T> {
    private final ObjectMapper mapper;
    private final Class<T> clazz;

    public JsonDeserializer(Class<T> eventEnvelopeClass) {
        this.mapper = new ObjectMapper();
        this.mapper.disable(SerializationFeature.FAIL_ON_EMPTY_BEANS);
        this.mapper.findAndRegisterModules();
        this.mapper.registerModule(new JavaTimeModule());

        this.clazz = eventEnvelopeClass;
    }

    @Override
    public void configure(Map<String, ?> configs, boolean isKey) {

    }

    @Override
    public T deserialize(String topic, byte[] data) {
        try {
            return mapper.readValue(data, clazz);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public void close() {

    }
}
