package io.vertx.example.ignite.eventsourcing.impl.flow;

import jdk.nashorn.internal.ir.annotations.Immutable;
import lombok.Value;

/**
 * Created by id961900 on 16/05/2017.
 */

@Value
@Immutable
public class AggregateType {

  private String aggregateFlowName;
  private double flowVersion;

}
