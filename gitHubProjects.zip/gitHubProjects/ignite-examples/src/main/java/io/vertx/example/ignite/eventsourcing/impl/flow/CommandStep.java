package io.vertx.example.ignite.eventsourcing.impl.flow;

import io.vertx.example.ignite.eventsourcing.Command;
import io.vertx.example.ignite.eventsourcing.Event;
import io.vertx.example.ignite.eventsourcing.impl.eventstore.EventStream;
import lombok.*;

import java.util.function.BiFunction;

/**
 * Created by id961900 on 15/05/2017.
 */

@Getter
@Setter
@ToString
@EqualsAndHashCode
@Builder
public class CommandStep {
  private Class<? extends Command> when;
  private BiFunction<Command,EventStream, Event> doAction;
}
