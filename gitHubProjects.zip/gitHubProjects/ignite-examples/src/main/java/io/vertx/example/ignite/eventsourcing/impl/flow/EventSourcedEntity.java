package io.vertx.example.ignite.eventsourcing.impl.flow;

import io.vertx.example.ignite.eventsourcing.Command;
import io.vertx.example.ignite.eventsourcing.Event;
import io.vertx.example.ignite.eventsourcing.impl.eventstore.EventStream;

/**
 * Created by id961900 on 15/05/2017.
 */
public interface EventSourcedEntity<C extends Command, E extends Event> {

   void flow();

   Event onCommand(C command,EventStream eventStream);

   void onEvent(E event,EventStream eventStream);
}
