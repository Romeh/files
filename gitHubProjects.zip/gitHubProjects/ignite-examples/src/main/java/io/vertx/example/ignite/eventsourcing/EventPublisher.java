package io.vertx.example.ignite.eventsourcing;

public interface EventPublisher {
    <T extends Event> void publish(String streamName, T event);
}
