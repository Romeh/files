package io.vertx.example.ignite.eventsourcing;

import io.vertx.core.AsyncResult;
import io.vertx.core.Handler;

import java.util.stream.Stream;

public interface EventStore {
    void saveEvents(String streamName, String aggregateId, Iterable<? extends Event> events, int expectedVersion);
    void getEventsForAggregate(String aggregateId,Handler<AsyncResult<Stream<? extends Event>>> handler);
     void getEventsForAggregateIterable(String aggregateId, Handler<AsyncResult<Iterable<? extends Event>>> handler);
}
