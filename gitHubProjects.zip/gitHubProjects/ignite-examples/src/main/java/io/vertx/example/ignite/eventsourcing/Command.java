package io.vertx.example.ignite.eventsourcing;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import io.vertx.example.ignite.eventsourcing.impl.commands.CheckOutCommand;
import io.vertx.example.ignite.eventsourcing.impl.commands.CreateOrderCommand;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.io.Serializable;
import java.util.Map;

/**
 * Created by id961900 on 09/05/2017.
 */
@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, include = JsonTypeInfo.As.PROPERTY)
@JsonSubTypes({
  @JsonSubTypes.Type(value = CreateOrderCommand.class, name = "CreateOrderCommand"),
  @JsonSubTypes.Type(value = CheckOutCommand.class, name = "CheckOutCommand")
})
public interface Command extends Serializable {
  Map<String, String> getData();

  void setData(Map<String, String> data);

  void setEventTag(String eventTag);

  String getEventTag();


}
