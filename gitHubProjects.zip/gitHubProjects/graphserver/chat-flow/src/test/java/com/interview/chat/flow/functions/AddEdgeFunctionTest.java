package com.interview.chat.flow.functions;

import com.interview.chat.enums.Defaults;
import com.interview.chat.graph.GraphService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.*;

/**
 * unit test for add edge fucntion
 */
@RunWith(MockitoJUnitRunner.class)
public class AddEdgeFunctionTest {
    @Mock
    private GraphService<String,Integer> graphService;

    @InjectMocks
    AddEdgeFunction addEdgeFunction;

    @Before
    public void setUp() throws Exception {
        when(graphService.addEdge(anyString(), anyString(), anyInt())).thenReturn(true);
    }

    @Test
    public void testAddEdgeCases(){
        // test negative case

        assertEquals(addEdgeFunction.apply("add edge node1 node3 -1","ClientID").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());


    }
    @Test
    public void testCase2(){
        when(graphService.addEdge(anyString(), anyString(), anyInt())).thenReturn(false);
        // test correct case
        assertEquals(addEdgeFunction.apply("add edge node1 node2 50","ClientID").getResponse(), Defaults.EDGE_ADDED_FAILED.getMsg());
    }

    @Test
    public void testCase3(){
        // test empty string
        assertEquals(addEdgeFunction.apply("","ClientID").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
    }

    @Test
    public void testCase4(){
// test wrong input
        assertEquals(addEdgeFunction.apply("addedge ode1 node2","ClientID").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
    }

    @Test
    public void testCase5(){
        // test not accepted format
        assertEquals(addEdgeFunction.apply("add edge $$%£","ClientID").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
    }

    @Test
    public void testCase6(){
        // test correct case
        assertEquals(addEdgeFunction.apply("add edge node1 node2 50","ClientID").getResponse(), Defaults.EDGE_ADDED.getMsg());
    }




}