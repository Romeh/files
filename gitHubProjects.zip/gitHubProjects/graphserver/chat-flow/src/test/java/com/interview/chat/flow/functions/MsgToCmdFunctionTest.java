package com.interview.chat.flow.functions;

import com.interview.chat.flow.commands.*;
import org.junit.Test;

import java.util.Optional;

import static org.junit.Assert.assertEquals;

/**
 * Msg to command converter test
 */
public class MsgToCmdFunctionTest {
    @Test
    public void testMatchDifferentCases(){
        MsgToCmdFunction msgToCmdFunction=new MsgToCmdFunction();

        assertEquals(msgToCmdFunction.msgToCommand("hi, i'm mike").get(), WelcomeCmd.class);
        assertEquals(msgToCmdFunction.msgToCommand("bye mate!").get(), ByeCmd.class);
        assertEquals(msgToCmdFunction.msgToCommand("add node node1").get(), AddNodeCmd.class);
        assertEquals(msgToCmdFunction.msgToCommand("add edge node1 node2 10").get(), AddEdgeCmd.class);
        assertEquals(msgToCmdFunction.msgToCommand("remove node node1").get(), RemoveNodeCmd.class);
        assertEquals(msgToCmdFunction.msgToCommand("remove edge node1 node2").get(), RemoveEdgeCmd.class);
        assertEquals(msgToCmdFunction.msgToCommand("shortest path node1 node2").get(), ShortestPathCmd.class);
        assertEquals(msgToCmdFunction.msgToCommand("SHORTEST path node1 node2").get(), ShortestPathCmd.class);
        assertEquals(msgToCmdFunction.msgToCommand("SHORTEST PATH node1 node2").get(), ShortestPathCmd.class);
        assertEquals(msgToCmdFunction.msgToCommand(""), Optional.empty());
        assertEquals(msgToCmdFunction.msgToCommand("adasdadadasd"), Optional.empty());
        assertEquals(msgToCmdFunction.msgToCommand(null), Optional.empty());


    }

}