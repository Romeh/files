package com.interview.chat.flow.functions;

import com.interview.chat.enums.Defaults;
import com.interview.chat.graph.GraphService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * remove node test
 */
@RunWith(MockitoJUnitRunner.class)
public class RemoveNodeFunctionTest {
    @Mock
    private GraphService<String,Integer> graphService;
    @InjectMocks
    RemoveNodeFunction removeNodeFunction;
    @Before
    public void setUp() throws Exception {
         when(graphService.removeNode(anyString())).thenReturn(true);
    }
    @Test
    public void addNodeCases(){
        // test empty string
        assertEquals(removeNodeFunction.apply("","ClientId").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
        // test wrong input
        assertEquals(removeNodeFunction.apply("addedge ode1 node2","ClientId").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
        // test not accepted format
        assertEquals(removeNodeFunction.apply("remove node $$%£","ClientId").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
        // test bad case
        assertEquals(removeNodeFunction.apply("remove node node1 node2","ClientId").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
        // test correct case
        assertEquals(removeNodeFunction.apply("remove node node1","ClientId").getResponse(), Defaults.NODE_REMOVED.getMsg());

        // test correct case
        when(graphService.removeNode(anyString())).thenReturn(false);
        assertEquals(removeNodeFunction.apply("remove node node1","ClientId").getResponse(), Defaults.NODE_REMOVED_FAILED.getMsg());

    }

}