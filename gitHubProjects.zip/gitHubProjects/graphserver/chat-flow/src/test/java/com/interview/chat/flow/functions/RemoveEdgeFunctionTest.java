package com.interview.chat.flow.functions;

import com.interview.chat.enums.Defaults;
import com.interview.chat.graph.GraphService;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.ArgumentMatchers;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;


/**
 * remove edge test
 */
@RunWith(MockitoJUnitRunner.class)
public class RemoveEdgeFunctionTest {
    @Mock
    private GraphService<String,Integer> graphService;
    @InjectMocks
    RemoveEdgeFunction removeEdgeFunction;

    @Before
    public void setUp() throws Exception {
        Mockito.when(graphService.removeEdge(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(true);
    }

    @Test
    public void testRemoveEdge(){
        // test empty string
        Assert.assertEquals(removeEdgeFunction.apply("","ClientId").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
        // test wrong input
        Assert.assertEquals(removeEdgeFunction.apply("removeedge ode1 node2","ClientId").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
        // test not accepted format
        Assert.assertEquals(removeEdgeFunction.apply("remove edge $$%£  $$%£","ClientId").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
        // test correct case
        Assert.assertEquals(removeEdgeFunction.apply("remove edge node1 node2","ClientId").getResponse(), Defaults.EDGE_REMOVED.getMsg());
        Mockito.when(graphService.removeEdge(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(false);
        // test correct case
        Assert.assertEquals(removeEdgeFunction.apply("remove edge node1 node2","ClientId").getResponse(), Defaults.EDGE_REMOVED_FAILED.getMsg());
        //node does not exist
        Mockito.when(graphService.removeEdge(ArgumentMatchers.anyString(), ArgumentMatchers.anyString())).thenReturn(false);
        Assert.assertEquals(removeEdgeFunction.apply("remove edge node1 node2","ClientId").getResponse(), Defaults.EDGE_REMOVED_FAILED.getMsg());
    }

}