package com.interview.chat.flow.functions;

import com.interview.chat.enums.Defaults;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * default function test
 */

public class DefaultFunctionTest {
  @Test
  public void testDefault(){
        DefaultFunction function=new DefaultFunction();
        assertEquals(function.apply("","testClient").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
  }

}