package com.interview.chat.flow.functions;

import com.interview.chat.cache.ClientCache;
import com.interview.chat.data.FlowContext;
import com.interview.chat.enums.Defaults;
import org.junit.Test;

import static org.junit.Assert.assertEquals;

/**
 * welcome function test
 */
public class WelcomeFunctionTest {

    @Test
    public void testHiCases() {
        FlowContext flowContext=FlowContext.builder().clientId("test").build();
        ClientCache.getInstance().put(flowContext.getClientId(), flowContext);
        WelcomeFunction welcomeFunction=new WelcomeFunction();
        assertEquals(welcomeFunction.apply("hi, i'm <name>","test").getResponse(),Defaults.I_DO_NOT_KNOW.getMsg());
        assertEquals(welcomeFunction.apply("hi, i'm Mike","test").getResponse(),"HI Mike\r\n");
        assertEquals(welcomeFunction.apply("hi, i'm Mike_125","test").getResponse(),"HI Mike_125\r\n");
        assertEquals(welcomeFunction.apply("hi, i'm MikeJohn%%%%%$£","test").getResponse(),Defaults.I_DO_NOT_KNOW.getMsg());
        assertEquals(welcomeFunction.apply("hi, i'm","test").getResponse(),Defaults.I_DO_NOT_KNOW.getMsg());
        assertEquals(welcomeFunction.apply("","test").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
        assertEquals(welcomeFunction.apply("hi, i'm mike boss","test").getResponse(),Defaults.I_DO_NOT_KNOW.getMsg());


    }

}