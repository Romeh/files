package com.interview.chat.flow.functions;

import com.interview.chat.enums.Defaults;
import com.interview.chat.graph.GraphService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * add node test
 */
@RunWith(MockitoJUnitRunner.class)
public class AddNodeFunctionTest {
    @Mock
    private GraphService<String,Integer> graphService;
    @InjectMocks
    AddNodeFunction addEdgeFunction;

    @Before
    public void setUp() throws Exception {

        when(graphService.addNode(anyString())).thenReturn(true);

    }

    @Test
    public void addNodeCases(){
        // test empty string
        assertEquals(addEdgeFunction.apply("","clientID").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
        // test wrong input
        assertEquals(addEdgeFunction.apply("addedge ode1 node2","clientID").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
        // test not accepted format
        assertEquals(addEdgeFunction.apply("add node $$%£","clientID").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
        // test correct case
        assertEquals(addEdgeFunction.apply("add node node1 node2 50","clientID").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());
        // test negative case
        assertEquals(addEdgeFunction.apply("add node node1","clientID").getResponse(), Defaults.NODE_ADDED.getMsg());

       // when(graphService.addNode(anyString())).thenReturn(false);
        // test correct case
        when(graphService.addNode(anyString())).thenReturn(false);
        assertEquals(addEdgeFunction.apply("add node node1","clientID").getResponse(), Defaults.NODE_ADDED_FAILED.getMsg());
    }

}