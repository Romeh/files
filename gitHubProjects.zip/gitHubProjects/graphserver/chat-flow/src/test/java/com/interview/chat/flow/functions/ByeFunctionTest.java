package com.interview.chat.flow.functions;

import com.interview.chat.cache.ClientCache;
import com.interview.chat.data.FlowContext;
import org.junit.Test;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

/**
 * bye function test
 */

public class ByeFunctionTest {

    @Test
    public void testByeFunction(){
        ByeFunction byeFunction=new ByeFunction();
        final FlowContext build = FlowContext.builder()
                .clientName("testClient")
                .clientId("clientId")
                .inputMsg("testMsg")
                .dateTime(System.currentTimeMillis()-3000L)
                .build();
        ClientCache.getInstance().put("clientId",build);
        assertEquals(byeFunction.apply(build.getInputMsg(),"clientId").isTerminate(),true);
        assertTrue(byeFunction.apply(build.getInputMsg(),"clientId").getResponse().contains("testClient"));
        assertTrue(byeFunction.apply(build.getInputMsg(),"clientId").getResponse().contains("BYE testClient"));
        // test null case
        build.setDateTime(0);
        assertTrue(byeFunction.apply(build.getInputMsg(),"clientId").getResponse().contains("testClient"));



    }

}