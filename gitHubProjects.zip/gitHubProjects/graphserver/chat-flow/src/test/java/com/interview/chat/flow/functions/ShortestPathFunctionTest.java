package com.interview.chat.flow.functions;

import com.interview.chat.enums.Defaults;
import com.interview.chat.graph.GraphService;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.when;

/**
 * shortest path
 */
@RunWith(MockitoJUnitRunner.class)
public class ShortestPathFunctionTest {
    @Mock
    private GraphService<String,Integer> graphService;

    @InjectMocks
    ShortestPathFunction shortestPathFunction;

    @Before
    public void setUp() throws Exception {
        when(graphService.getShortestPath(anyString(), anyString())).thenReturn(20);
        when(graphService.isNodeExist(anyString())).thenReturn(true);
    }

    @Test
    public void testShortestPathCases(){
        // test empty string

        assertEquals(shortestPathFunction.apply("","client").getResponse(), Defaults.I_DO_NOT_KNOW.getMsg());

        // test success case

        assertTrue(shortestPathFunction.apply("shortest path node1 node2","client").getResponse().equalsIgnoreCase("20\r\n"));
        // test failed case
        when(graphService.getShortestPath(anyString(), anyString())).thenReturn(0);

        assertEquals(shortestPathFunction.apply("shortest path node1 node2","client").getResponse(), Defaults.SHORTEST_PATH_FAILED.getMsg());
        // test node not exist

        when(graphService.isNodeExist(anyString())).thenReturn(false);
        assertEquals(shortestPathFunction.apply("shortest path node1 node2","client").getResponse(), Defaults.SHORTEST_PATH_FAILED.getMsg());

    }

}