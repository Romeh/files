package com.interview.chat.flow.core;


import java.io.Serializable;

/**
 * Command interface
 */

public interface Command extends Serializable {


}
