package com.interview.chat.flow.functions;

import com.interview.chat.flow.commands.*;
import com.interview.chat.flow.core.Command;
import com.interview.chat.flow.core.MsgToCommand;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * MsgToCmdFunction action logic unit
 */
public class MsgToCmdFunction implements MsgToCommand {

    private final Map<String, Class<? extends Command>> msgToCommandLookup = new HashMap<>();

    public MsgToCmdFunction() {
        msgToCommandLookup.put("hi, i'm", WelcomeCmd.class);
        msgToCommandLookup.put("bye mate!", ByeCmd.class);
        msgToCommandLookup.put("add node", AddNodeCmd.class);
        msgToCommandLookup.put("add edge", AddEdgeCmd.class);
        msgToCommandLookup.put("remove node", RemoveNodeCmd.class);
        msgToCommandLookup.put("remove edge", RemoveEdgeCmd.class);
        msgToCommandLookup.put("shortest path", ShortestPathCmd.class);
        msgToCommandLookup.put("closer than", CloserThanCmd.class);

    }

    /**
     * parse the input message and try to found if there is a matching command for
     * that input
     * @param msg the input message
     * @return the found command class for that input
     */
    @Override
    public Optional<Class<? extends Command>> msgToCommand(String msg) {
        if (Objects.nonNull(msg)) {
            return msgToCommandLookup.entrySet()
                    .stream()
                    .filter(stringClassEntry -> msg.toLowerCase().startsWith(stringClassEntry.getKey()))
                    .findFirst().map(stringClassEntry -> stringClassEntry.getValue());
        } else {
            return Optional.empty();
        }

    }
}
