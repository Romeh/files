package com.interview.chat.flow.core;

import com.interview.chat.data.Response;
import lombok.*;

import java.util.function.BiFunction;

/**
 * Command step definition class which
 * has a command class and function
 * that will be executed for that type of command
 */
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class CommandStep {
    private Class<? extends Command> when;
    private BiFunction<String,String, Response> doAction;
}
