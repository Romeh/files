package com.interview.chat.flow.commands;

import com.interview.chat.flow.core.Command;

/**
 * remove node command
 */
public class RemoveNodeCmd implements Command {
}
