package com.interview.chat.flow.core;


import com.interview.chat.data.Response;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

import java.util.HashMap;
import java.util.Map;
import java.util.function.BiFunction;

/**
 * FLow definition DSL map lookup
 */
@Getter
@ToString
@EqualsAndHashCode
public class FlowDefinition {
    private Map<Class<? extends Command>, BiFunction<String,String, Response>> commandHandlers = new HashMap<>();
}
