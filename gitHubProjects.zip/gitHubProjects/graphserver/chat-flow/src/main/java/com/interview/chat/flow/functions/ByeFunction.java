package com.interview.chat.flow.functions;

import com.interview.chat.cache.ClientCache;
import com.interview.chat.data.FlowContext;
import com.interview.chat.data.Response;
import com.interview.chat.flow.annotations.ByeCall;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.BiFunction;

/**
 * bye action logic unit
 */
@ByeCall
public class ByeFunction implements BiFunction<String,String, Response> {
    private static final Logger LOGGER = LoggerFactory.getLogger(ByeFunction.class);
    @Override
    public Response apply(String inputMsg,String clientId) {
        final FlowContext flowContext=ClientCache.getInstance().get(clientId)
                //otherwise use a dummy chat context as it means something is not correct
                .orElseGet(() -> {
                    LOGGER.error("Failed to find the flow context and using dummy one for the timeout action for client address{}",clientId);
                    return FlowContext.builder().dateTime(System.currentTimeMillis()-30000L).clientName("UNKNOWN").build();
                });

        LOGGER.info("ByeFunction is triggered for client {} {}",clientId,flowContext.getDateTime());
        Response response=Response.builder().terminate(true).response(String.format("BYE %s, WE SPOKE FOR %d\n"
                , !isNullOrEmpty(flowContext.getClientName())?flowContext.getClientName() : "UNKNOWN"
                , flowContext.getDateTime()!=0?System.currentTimeMillis()-flowContext.getDateTime():0)).build();
        LOGGER.info("final Bye function response {}",response.getResponse());
        return response;


    }

    private boolean isNullOrEmpty(String s) {
        return s == null || s.isEmpty();
    }
}
