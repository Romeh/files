package com.interview.chat.flow.functions;

import com.interview.chat.data.Response;
import com.interview.chat.enums.Defaults;

import java.util.function.BiFunction;

/**
 * DefaultFunction action logic unit
 */
public class DefaultFunction implements BiFunction<String,String, Response> {
    @Override
    public Response apply(String inputMsg,String clientId) {
        return Response.builder().terminate(false)
                .response(Defaults.I_DO_NOT_KNOW.getMsg()).build();
    }
}
