package com.interview.chat.flow.functions;

import com.interview.chat.data.Response;
import com.interview.chat.enums.Defaults;
import com.interview.chat.graph.GraphService;
import com.interview.chat.graph.JgraphtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.BiFunction;

/**
 * RemoveEdgeFunction action logic unit
 */
public class RemoveEdgeFunction implements BiFunction<String,String, Response> {
    private static final String removeEdgeCmdPattern = "remove\\sedge\\s[\\w-]+\\s[\\w-]+";
    private static final Logger LOGGER = LoggerFactory.getLogger(AddEdgeFunction.class);
    private  GraphService<String, Integer> graphService= new JgraphtService();
    @Override
    public Response apply(String inputMsg,String clientId) {
        return inputMsg.matches(removeEdgeCmdPattern) ?
                handleCommand(inputMsg) :
                Response.builder().terminate(false).response(Defaults.I_DO_NOT_KNOW.getMsg()).build();
    }

    private Response handleCommand(String inputMsg) {
        final String[] split = inputMsg.split(" ");
        LOGGER.debug("Client want to remove edge between nodes  {} {} ", split[2], split[3]);
        // send back the response
        return graphService.removeEdge(split[2], split[3]) ?
                Response.builder().terminate(false).response(Defaults.EDGE_REMOVED.getMsg()).build() :
                Response.builder().terminate(false).response(Defaults.EDGE_REMOVED_FAILED.getMsg()).build();

    }
}