package com.interview.chat.flow.commands;

import com.interview.chat.flow.core.Command;

/**
 * shortest path command
 */
public class ShortestPathCmd implements Command {
}
