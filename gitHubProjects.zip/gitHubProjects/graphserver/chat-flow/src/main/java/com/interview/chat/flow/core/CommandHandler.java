package com.interview.chat.flow.core;

import com.interview.chat.data.Response;

/**
 * Command handler interface
 */
public interface CommandHandler {
    void flow();

    Response onCommand(Class<? extends Command> command, String input,String clientId);

    Response onMsg(String msg,String clientId);
}
