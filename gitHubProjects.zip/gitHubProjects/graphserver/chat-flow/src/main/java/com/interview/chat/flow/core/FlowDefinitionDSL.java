package com.interview.chat.flow.core;

import java.util.function.Consumer;


/**
 * FLOW definition DSL to make it more human readable
 */
public class FlowDefinitionDSL {
    private final FlowDefinition flowDefinition = new FlowDefinition();

    public static FlowDefinition Flow(Consumer<FlowDefinitionDSL> FlowDefinitionConsumer) {
        FlowDefinitionDSL flowDSLBuilder = new FlowDefinitionDSL();
        FlowDefinitionConsumer.accept(flowDSLBuilder);
        return flowDSLBuilder.flowDefinition;

    }

    public FlowDefinitionDSL onCommand(final Consumer<CommandStep.CommandStepBuilder> commandStep) {
        CommandStep.CommandStepBuilder step = CommandStep.builder();
        commandStep.accept(step);
        CommandStep definedStep = step.build();
        this.flowDefinition.getCommandHandlers().put(definedStep.getWhen(), definedStep.getDoAction());
        return this;
    }


}
