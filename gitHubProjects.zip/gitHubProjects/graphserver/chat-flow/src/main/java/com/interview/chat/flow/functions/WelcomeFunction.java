package com.interview.chat.flow.functions;

import com.interview.chat.cache.ClientCache;
import com.interview.chat.data.FlowContext;
import com.interview.chat.data.Response;
import com.interview.chat.enums.Defaults;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.BiFunction;

/**
 * WelcomeFunction action logic unit
 */
public class WelcomeFunction implements BiFunction<String,String, Response> {

    private static final String helloCommandPattern = "hi,\\si'm\\s[\\w-]+";
    private static final Logger LOGGER = LoggerFactory.getLogger(WelcomeFunction.class);

    @Override
    public Response apply(String inputMsg,String clientId) {
        return inputMsg.matches(helloCommandPattern) ?
                handleCommand(inputMsg,clientId) :
                Response.builder().terminate(false).response(Defaults.I_DO_NOT_KNOW.getMsg()).build();
    }

    private Response handleCommand(String inputMsg,String clientId) {
        final FlowContext flowContext = ClientCache.getInstance().get(clientId).
                orElseThrow(() ->  new IllegalStateException("cache for client is "+clientId+"is not found"));
        // substring to get last part of the message which is the name
        final String name = inputMsg.substring(inputMsg.lastIndexOf(" ") + 1);
        LOGGER.debug("Client name in Hi function is {}", name);
        //store the client name for next messages into the cache
        flowContext.setClientName(name);
        ClientCache.getInstance().put(flowContext.getClientId(), flowContext);
        // send back the response
        return Response.builder().terminate(false).response(String.format("HI %s", name)+System.lineSeparator()).build();
    }
}
