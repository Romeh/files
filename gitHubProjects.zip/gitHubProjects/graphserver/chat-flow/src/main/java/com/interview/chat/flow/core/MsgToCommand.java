package com.interview.chat.flow.core;

import java.util.Optional;

/**
 * input message to command matcher
 */
@FunctionalInterface
public interface MsgToCommand {

    Optional<Class<? extends Command>> msgToCommand(String msg);
}
