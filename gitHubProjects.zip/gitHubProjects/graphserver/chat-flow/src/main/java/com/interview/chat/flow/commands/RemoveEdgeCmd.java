package com.interview.chat.flow.commands;

import com.interview.chat.flow.core.Command;

/**
 * remove edge command
 */
public class RemoveEdgeCmd implements Command {
}
