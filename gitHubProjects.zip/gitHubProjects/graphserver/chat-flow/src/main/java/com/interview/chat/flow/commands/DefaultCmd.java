package com.interview.chat.flow.commands;

import com.interview.chat.flow.core.Command;

/**
 * default command
 */
public class DefaultCmd implements Command {
}
