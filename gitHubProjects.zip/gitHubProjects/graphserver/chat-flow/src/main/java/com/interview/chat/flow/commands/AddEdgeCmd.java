package com.interview.chat.flow.commands;

import com.interview.chat.flow.core.Command;

/**
 * add edge command
 */
public class AddEdgeCmd implements Command {
}
