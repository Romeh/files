package com.interview.chat.flow.commands;

import com.interview.chat.flow.core.Command;

/**
 * Bye command
 */

public class ByeCmd implements Command {
}
