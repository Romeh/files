package com.interview.chat.flow.functions;

import com.interview.chat.data.Response;
import com.interview.chat.enums.Defaults;
import com.interview.chat.graph.GraphService;
import com.interview.chat.graph.JgraphtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.BiFunction;

/**
 * add node action logic unit
 */

public class AddNodeFunction implements BiFunction<String,String, Response> {

    private static final String addNodeCmdPattern = "add\\snode\\s[\\w-]+";
    private static final Logger LOGGER = LoggerFactory.getLogger(AddNodeFunction.class);
    private  GraphService<String, Integer> graphService= new JgraphtService();
    @Override
    public Response apply(String inputMsg,String clientId) {
        return inputMsg.matches(addNodeCmdPattern) ? handleCommand(inputMsg,clientId) :
                Response.builder().terminate(false).response(Defaults.I_DO_NOT_KNOW.getMsg()).build();
    }

    private Response handleCommand(String inputMsg,String clientId) {
        // get the node name
        final String nodeName = inputMsg.substring(inputMsg.lastIndexOf(" ") + 1);
        LOGGER.debug("Client want to add node in AddNodeF function is {}", nodeName);
        // send back tha answer
        return graphService.addNode(nodeName) ?
                Response.builder().terminate(false).response(Defaults.NODE_ADDED.getMsg()).build() :
                Response.builder().terminate(false).response(Defaults.NODE_ADDED_FAILED.getMsg()).build();

    }
}
