package com.interview.chat.flow.functions;

import com.interview.chat.data.Response;
import com.interview.chat.enums.Defaults;
import com.interview.chat.graph.GraphService;
import com.interview.chat.graph.JgraphtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.BiFunction;

/**
 * ShortestPathFunction action logic unit
 */
public class ShortestPathFunction implements BiFunction<String,String, Response> {
    private static final String shortestPath = "shortest\\spath\\s[\\w-]+\\s[\\w-]+";
    private static final Logger LOGGER = LoggerFactory.getLogger(AddEdgeFunction.class);
    private  GraphService<String, Integer> graphService= new JgraphtService();

    @Override
    public Response apply(String inputMsg,String clientId) {
        return inputMsg.matches(shortestPath) ?
                handleCommand(inputMsg) :
                Response.builder().terminate(false).response(Defaults.I_DO_NOT_KNOW.getMsg()).build();
    }

    private Response handleCommand(String inputMsg) {
        final String[] split = inputMsg.split(" ");
        // node names are located into location 3 and 4 in the divided string tokens which map  to 2-3 in array index
        LOGGER.debug("Client want to get shortestPath between nodes : {} {}", split[2], split[3]);
        // check if the nodes exist first
        if(!graphService.isNodeExist(split[2])||!graphService.isNodeExist(split[3])){
            return Response.builder().terminate(false)
                    .response(Defaults.SHORTEST_PATH_FAILED.getMsg()).build();
        }

        final int shortestPath = graphService.getShortestPath(split[2], split[3]);
        if(shortestPath>0){
            // send back the response
            return Response.builder().terminate(false)
                    .response(new StringBuilder().append(shortestPath).append("\r\n").toString()).build();
        }else{
            // send back the response
            return Response.builder().terminate(false)
                    .response(Defaults.SHORTEST_PATH_FAILED.getMsg()).build();
        }
    }
}