package com.interview.chat.flow.functions;

import com.interview.chat.data.Response;
import com.interview.chat.enums.Defaults;
import com.interview.chat.graph.GraphService;
import com.interview.chat.graph.JgraphtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Set;
import java.util.function.BiFunction;
import java.util.stream.Collectors;

/**
 * CloserThanFunction action logic unit
 */
public class CloserThanFunction implements BiFunction<String,String, Response> {

    private static final String closerThan = "closer\\sthan\\s\\d+\\s[\\w-]+";
    private static final Logger LOGGER = LoggerFactory.getLogger(CloserThanFunction.class);
    private GraphService<String, Integer> graphService= new JgraphtService();

    @Override
    public Response apply(String inputMsg,String clientId) {
        return inputMsg.matches(closerThan) ?
                handleCommand(inputMsg,clientId) :
                Response.builder().terminate(false).response(Defaults.I_DO_NOT_KNOW.getMsg()).build();
    }

    private Response handleCommand(String inputMsg,String clientId) {
            final String[] split = inputMsg.split(" ");
            // weight and node name is located into location 3 and 4
            LOGGER.debug("Client want to get closer than for node with weight : {} {}", split[3],split[2]);
            int weight =Integer.parseInt(split[2]);
            if(weight<=0){
                return  Response.builder().terminate(false).response(Defaults.I_DO_NOT_KNOW.getMsg()).build();
            }
            // check if the nodes exist first
            if(!graphService.isNodeExist(split[3])){
                return Response.builder().terminate(false)
                        .response(Defaults.CLOSER_THAN_FAILED.getMsg()).build();
            }

            final Set<String> winnerNodes = graphService.getAllNodesLessThanWeight(split[3],weight);
            if(!winnerNodes.isEmpty()){
                // send back the response
                return Response.builder().terminate(false)
                        .response(new StringBuilder()
                                .append(String.join(",",winnerNodes.stream().collect(Collectors.toList())))
                                .append("\r\n").toString()).build();
            }else{
                // send back the response
                return Response.builder().terminate(false)
                        .response("").build();
            }
        }

    }

