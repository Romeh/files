package com.interview.chat.flow.functions;

import com.interview.chat.data.Response;
import com.interview.chat.enums.Defaults;
import com.interview.chat.graph.GraphService;
import com.interview.chat.graph.JgraphtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.BiFunction;

/**
 * RemoveNodeFunction action logic unit
 */
public class RemoveNodeFunction implements BiFunction<String,String, Response> {
    private static final String removeNodeCmdPattern = "remove\\snode\\s[\\w-]+";
    private static final Logger LOGGER = LoggerFactory.getLogger(RemoveNodeFunction.class);
    private  GraphService<String, Integer> graphService= new JgraphtService();

    @Override
    public Response apply(String inputMsg,String clientId) {
        return inputMsg.matches(removeNodeCmdPattern) ?
                handleCommand(inputMsg) :
                Response.builder().terminate(false).response(Defaults.I_DO_NOT_KNOW.getMsg()).build();
    }

    private Response handleCommand(String inputMsg) {
        final String nodeName = inputMsg.substring(inputMsg.lastIndexOf(" ") + 1);
        LOGGER.debug("Client want to remove node {}", nodeName);
        return graphService.removeNode(nodeName) ?
                Response.builder().terminate(false).response(Defaults.NODE_REMOVED.getMsg()).build() :
                Response.builder().terminate(false).response(Defaults.NODE_REMOVED_FAILED.getMsg()).build();

    }
}
