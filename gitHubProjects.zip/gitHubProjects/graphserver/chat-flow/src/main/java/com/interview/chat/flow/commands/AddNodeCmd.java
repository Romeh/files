package com.interview.chat.flow.commands;

import com.interview.chat.flow.core.Command;

/**
 * add Node command
 */
public class AddNodeCmd implements Command {
}
