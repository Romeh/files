package com.interview.chat.flow.functions;

import com.interview.chat.data.Response;
import com.interview.chat.enums.Defaults;
import com.interview.chat.graph.GraphService;
import com.interview.chat.graph.JgraphtService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.BiFunction;

/**
 * add edge action logic unit
 */
public class AddEdgeFunction implements BiFunction<String,String, Response> {

    private static final String addEdgeCmdPattern = "add\\sedge\\s[\\w-]+\\s[\\w-]+\\s\\d+";
    private static final Logger LOGGER = LoggerFactory.getLogger(AddEdgeFunction.class);
    private  GraphService<String, Integer> graphService= new JgraphtService();

    @Override
    public Response apply(String inputMsg,String clientId) {
        return inputMsg.matches(addEdgeCmdPattern) ?
                handleCommand(inputMsg,clientId) :
                Response.builder().terminate(false).response(Defaults.I_DO_NOT_KNOW.getMsg()).build();
    }

    private Response handleCommand(String inputMsg,String clientId) {

        // split by space
        final String[] split = inputMsg.split(" ");
        // get the last token which is the width
        final int weight = Integer.parseInt(split[4]);
        if(weight<=0){
            return  Response.builder().terminate(false).response(Defaults.I_DO_NOT_KNOW.getMsg()).build();
        }
        LOGGER.debug("Client want to add edge between nodes with weight {} {} {}", split[2], split[3], split[4]);
       return graphService.addEdge(split[2], split[3], weight) ?
                    Response.builder().terminate(false).response(Defaults.EDGE_ADDED.getMsg()).build() :
                    Response.builder().terminate(false).response(Defaults.EDGE_ADDED_FAILED.getMsg()).build();


    }




}
