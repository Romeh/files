package com.interview.chat.flow.commands;

import com.interview.chat.flow.core.Command;

/**
 * closer than command
 */
public class CloserThanCmd implements Command {
}
