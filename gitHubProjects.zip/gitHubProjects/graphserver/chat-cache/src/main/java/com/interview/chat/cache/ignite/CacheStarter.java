package com.interview.chat.cache.ignite;

/**
 * the grid cache starter interface
 */
public interface CacheStarter {

    void start();
}
