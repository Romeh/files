package com.interview.chat.cache.ignite;

public enum CacheNames {

    GRAPH_STORE;

}
