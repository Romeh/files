package com.interview.chat.cache;

import com.google.common.cache.CacheBuilder;

import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * @param <K> the class of the keys.
 * @param <V> the class of the values (is Optional-ized).
 */
//@TODO to be replaced by the memory grid cache
public class BaseCache<K, V> implements LocalCache<K, V> {

    private final com.google.common.cache.Cache<K, V> cache;

    public BaseCache(EXPIRE_POLICY expirePolicy, long ttl) {
        CacheBuilder builder = CacheBuilder.newBuilder();
        if (ttl > 0 && expirePolicy == EXPIRE_POLICY.AFTER_WRITE) {
            builder.expireAfterWrite(ttl, TimeUnit.MINUTES);
        } else if (ttl > 0 && expirePolicy == EXPIRE_POLICY.AFTER_READ) {
            builder.expireAfterAccess(ttl, TimeUnit.MINUTES);
        }
        cache = builder.build();
    }

    @Override
    public V get(K key) {
        return cache.getIfPresent(key);
    }

    @Override
    public void put(K key, V value) {
        cache.put(key, value);
    }

    @Override
    public void invalidate(K key) {
        cache.invalidate(key);
    }

    @Override
    public void invalidateAll() {
        cache.invalidateAll();
    }

    @Override
    public Map<K, V> asMap() {
        return cache.asMap();
    }

}