package com.interview.chat.cache;

import java.util.Map;
//@TODO to be replaced by the memory grid cache
public interface LocalCache<K, V> {

    V get(K key);

    void put(K key, V value);

    void invalidate(K key);

    void invalidateAll();

    Map<K, V> asMap();

    enum EXPIRE_POLICY {NEVER, AFTER_WRITE, AFTER_READ}

}
