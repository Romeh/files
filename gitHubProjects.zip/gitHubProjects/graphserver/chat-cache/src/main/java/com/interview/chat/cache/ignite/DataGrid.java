package com.interview.chat.cache.ignite;

/**
 * Data Grid Facade interface
 */
public interface DataGrid<T> {
    T getDataGrid();
}


