package com.interview.chat.cache;

import com.interview.chat.data.FlowContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.Optional;

//@TODO to be replaced by the memory grid cache
public final class ClientCache {


    private final static ClientCache instance = new ClientCache();
    private static final Logger LOGGER = LoggerFactory.getLogger(ClientCache.class);
    // to be defined per functional requirements
    private BaseCache<String, FlowContext> cache
            = new BaseCache<>(LocalCache.EXPIRE_POLICY.AFTER_WRITE, 60);

    private ClientCache() {
    }

    public static ClientCache getInstance() {
        return instance;
    }

    public void put(String key, FlowContext context) {
        LOGGER.debug("FlowContext, put {} - {}", key, context);
        cache.put(key, context);
    }

    public Optional<FlowContext> get(String key) {
        LOGGER.debug("FlowContext, get {}", key);
        return Optional.ofNullable(cache.get(key));
    }

    public void invalidate(String key) {
        LOGGER.debug("FlowContext, invalidate {}", key);
        cache.invalidate(key);
    }

    public void invalidateAll() {
        LOGGER.debug("FlowContext, invalidate all");
        cache.invalidateAll();
    }

    @Override
    public String toString() {
        return Arrays.toString(cache.asMap().keySet().toArray());
    }


}

