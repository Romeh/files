package com.interview.chat.cache.ignite;

import org.apache.ignite.Ignition;

/**
 * the Ignite grid starter
 */
public class IgniteStarter implements CacheStarter{

    public void start(){
        Ignition.start("ignite.xml");
    }
}
