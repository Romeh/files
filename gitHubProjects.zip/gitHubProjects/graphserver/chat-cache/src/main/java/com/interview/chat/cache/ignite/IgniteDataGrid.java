package com.interview.chat.cache.ignite;

import org.apache.ignite.Ignite;
import org.apache.ignite.Ignition;

/**
 * the data grid facade
 */
public class IgniteDataGrid implements DataGrid<Ignite>{
    private Ignite ignite;
    public Ignite getDataGrid(){
        return getIgnite();

    }

    private Ignite getIgnite(){
        if(ignite!=null){
            return ignite;
        }else{
            ignite= Ignition.ignite();
            return ignite;
        }

    }
}
