package com.interview.chat.data;

import lombok.*;

import java.io.Serializable;

/**
 * FlowContext class that hold the flow context data per action
 */

@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class FlowContext implements Serializable {

    private String clientId;
    private long dateTime;
    private String clientName;
    private String inputMsg;

}
