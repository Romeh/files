package com.interview.chat.data;

import lombok.*;

import java.io.Serializable;

/**
 * the server response object
 */
@Builder
@Getter
@Setter
@EqualsAndHashCode
@ToString
public class Response implements Serializable {
    String response;
    boolean terminate;
}
