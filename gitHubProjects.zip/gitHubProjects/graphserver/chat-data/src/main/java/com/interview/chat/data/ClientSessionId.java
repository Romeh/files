package com.interview.chat.data;

import lombok.Getter;
import lombok.Setter;

/**
 *client session id holder
 */
public class ClientSessionId {
    @Setter
    @Getter
    String sessionId;
}
