package com.interview.chat.enums;

import lombok.Getter;

/**
 * default response messages
 */
public enum Defaults {
    I_DO_NOT_KNOW("SORRY, I DIDN’T UNDERSTAND THAT\r\n"),
    NODE_ADDED("NODE ADDED\r\n"),
    NODE_ADDED_FAILED("ERROR: NODE ALREADY EXISTS\r\n"),
    EDGE_ADDED("EDGE ADDED\r\n"),
    EDGE_ADDED_FAILED("ERROR: NODE NOT FOUND\r\n"),
    NODE_REMOVED("NODE REMOVED\r\n"),
    NODE_REMOVED_FAILED("ERROR: NODE NOT FOUND\r\n"),
    EDGE_REMOVED("EDGE REMOVED\r\n"),
    EDGE_REMOVED_FAILED("ERROR: NODE NOT FOUND\r\n"),
    CLOSER_THAN_FAILED("ERROR: NODE NOT FOUND\r\n"),
    SHORTEST_PATH_FAILED("ERROR: NODE NOT FOUND\r\n"),
    GRAPH_KEY("GRAPH");

    @Getter
    private String msg;

    Defaults(String msg) {
        this.msg = msg;
    }

}
