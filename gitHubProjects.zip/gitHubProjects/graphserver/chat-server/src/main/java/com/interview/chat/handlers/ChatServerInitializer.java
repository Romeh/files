package com.interview.chat.handlers;

import com.google.inject.Inject;
import com.netflix.config.DynamicLongProperty;
import com.netflix.config.DynamicPropertyFactory;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.codec.DelimiterBasedFrameDecoder;
import io.netty.handler.codec.Delimiters;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;
import io.netty.handler.ipfilter.AbstractRemoteAddressFilter;
import io.netty.handler.timeout.IdleStateHandler;

import java.net.InetSocketAddress;
import java.nio.charset.StandardCharsets;
import java.util.concurrent.TimeUnit;

/**
 * Creates a newly configured {@link ChannelPipeline} for
 * any connected new channel.
 */
public class ChatServerInitializer extends ChannelInitializer<SocketChannel> {
    // chat message decoder/encoder
    private static final StringDecoder DECODER = new StringDecoder(StandardCharsets.UTF_8);
    private static final StringEncoder ENCODER = new StringEncoder(StandardCharsets.UTF_8);
    private final AbstractRemoteAddressFilter<InetSocketAddress>  oneClientHandler;
    private final SimpleChannelInboundHandler<String> serverHandler;


    @Inject
    public ChatServerInitializer(AbstractRemoteAddressFilter<InetSocketAddress> oneClientHandler, SimpleChannelInboundHandler<String> serverHandler) {
        this.oneClientHandler = oneClientHandler;
        this.serverHandler = serverHandler;
    }

    @Override
    public void initChannel(SocketChannel ch) throws Exception {
        // read the idle timeout from the classpath properties file
        DynamicLongProperty timout =
                DynamicPropertyFactory.getInstance()
                        .getLongProperty("server.timeout", 30);
        ChannelPipeline pipeline = ch.pipeline();
        // the handler that handle active session at a time
         pipeline.addLast(oneClientHandler);
        // add the read timeout config idle handler
        pipeline.addLast(new IdleStateHandler(timout.get(), 0, 0L, TimeUnit.SECONDS));
        // Add the text line codec combination first,
        pipeline.addLast(new DelimiterBasedFrameDecoder(8192, Delimiters.lineDelimiter()));
        // the encoder and decoder are static as these are sharable
        pipeline.addLast(DECODER);
        pipeline.addLast(ENCODER);
        // and then business logic.
        pipeline.addLast(serverHandler);
    }
}
