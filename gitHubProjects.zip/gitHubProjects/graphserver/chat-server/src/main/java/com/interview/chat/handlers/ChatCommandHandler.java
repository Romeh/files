package com.interview.chat.handlers;

import com.google.inject.Inject;
import com.interview.chat.data.Response;
import com.interview.chat.flow.commands.*;
import com.interview.chat.flow.core.Command;
import com.interview.chat.flow.core.CommandHandler;
import com.interview.chat.flow.core.FlowDefinition;
import com.interview.chat.flow.functions.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import static com.interview.chat.flow.core.FlowDefinitionDSL.Flow;

/**
 * the main business logic command handler for the chat communication protocol
 */

public class ChatCommandHandler implements CommandHandler {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChatCommandHandler.class);
    private FlowDefinition chatFlow;
    @Inject
    private MsgToCmdFunction msgToCmd ;

    public ChatCommandHandler() {
        flow();
    }

    @Override
    public void flow() {
        // the chat flow DSL
        chatFlow = Flow(chatFlow -> chatFlow
                .onCommand(welcomeCommand -> welcomeCommand.when(WelcomeCmd.class).doAction(new WelcomeFunction()))
                .onCommand(byeCommand -> byeCommand.when(ByeCmd.class).doAction(new ByeFunction()))
                .onCommand(addNode -> addNode.when(AddNodeCmd.class).doAction(new AddNodeFunction()))
                .onCommand(removeNode -> removeNode.when(RemoveNodeCmd.class).doAction(new RemoveNodeFunction()))
                .onCommand(addEdge -> addEdge.when(AddEdgeCmd.class).doAction(new AddEdgeFunction()))
                .onCommand(removeEdge -> removeEdge.when(RemoveEdgeCmd.class).doAction(new RemoveEdgeFunction()))
                .onCommand(shortestPath -> shortestPath.when(ShortestPathCmd.class).doAction(new ShortestPathFunction()))
                .onCommand(closerThan -> closerThan.when(CloserThanCmd.class).doAction(new CloserThanFunction()))
                .onCommand(defaultCommand -> defaultCommand.when(DefaultCmd.class).doAction(new DefaultFunction()))
        );
    }

    @Override
    public Response onCommand(Class<? extends Command> command, String msg,String clientId) {
        // invoke the command handler
        return chatFlow.getCommandHandlers().get(command).apply(msg,clientId);
    }

    @Override
    public Response onMsg(String msg,String clientId) {
        // parse the incoming msg to get the related the command - in reality will be replaced with natural language processing and smart AI bot
        Class<? extends Command> cmdClass = msgToCmd.msgToCommand(msg).orElse(DefaultCmd.class);
        LOGGER.debug("Found matched command for msg {} is {}", msg, cmdClass.getSimpleName());
        return this.onCommand(cmdClass,msg.toLowerCase(),clientId);
    }

}
