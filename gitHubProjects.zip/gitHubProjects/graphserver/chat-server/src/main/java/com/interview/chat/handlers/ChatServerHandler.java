package com.interview.chat.handlers;

import com.google.inject.Inject;
import com.interview.chat.cache.ClientCache;
import com.interview.chat.data.FlowContext;
import com.interview.chat.data.Response;
import com.interview.chat.enums.Defaults;
import com.interview.chat.flow.annotations.ByeCall;
import com.interview.chat.flow.core.CommandHandler;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelFutureListener;
import io.netty.channel.ChannelHandler.Sharable;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.handler.timeout.IdleState;
import io.netty.handler.timeout.IdleStateEvent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.function.BiFunction;

/**
 * Handles a server-side channel when the input is received after going through the server pipeline
 */
@Sharable
public class ChatServerHandler extends SimpleChannelInboundHandler<String> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ChatServerHandler.class);

    @Inject
    private CommandHandler commandHandler;
    @Inject
    @ByeCall
    private BiFunction<String,String, Response> byeFunction;

    /**
    * Once the channel is active , the first action the server will do is to say Hi with unique generated ID
    * @param ctx the current active channel context
    * */
    @Override
    public void channelActive(ChannelHandlerContext ctx) throws Exception {
        // Send greeting for a new connection.
        StringBuilder helloMessage = new StringBuilder();
        final FlowContext chatContext = FlowContext.builder()
                .clientId( ctx.channel().attr(ClientSessionIdHandler.MY_KEY).get())
                .dateTime(System.currentTimeMillis()).build();
        // cache it for further commands invocation
        ClientCache.getInstance().put(chatContext.getClientId(), chatContext);
        helloMessage.append("HI, I'M ").append(chatContext.getClientId()).append(System.lineSeparator());
        ctx.channel().write(helloMessage.toString());
        ctx.channel().flush();
    }
    /**
    * when the client send a message it will received by the server via this method
    * @param ctx the current active channel context
    * @param request the current received input message
     */
    @Override
    public void channelRead0(ChannelHandlerContext ctx, String request) throws Exception {
        // Generate and write a response.
        Response response;

        if (request!=null&&request.isEmpty()) {
            response = Response.builder().terminate(false).response(Defaults.I_DO_NOT_KNOW.getMsg()).build();
        } else {
            // handle the incoming message via the command handler to dispatch baaed into the command type
            // @TODO NOTE : To add ASYNC circuit breaker wrapper with working queue so we can queue the modification orders rather doing transactions
            LOGGER.debug("INPUT message {}",request);
            response = commandHandler.onMsg(request,ctx.channel().attr(ClientSessionIdHandler.MY_KEY).get());
        }
        // We do not need to write a ChannelBuffer here.
        // We know the encoder inserted at TelnetPipelineFactory will do the conversion.
        ChannelFuture future = ctx.write(response.getResponse());

        // Close the connection after sending the good by message!
        // if the client has sent 'bye'.
        if (response.isTerminate()) {
            future.addListener(ChannelFutureListener.CLOSE);
        }
    }

    /**
     * when the channel stream reading is finished just flush
     * @param ctx the current active channel context
     */
    @Override
    public void channelReadComplete(ChannelHandlerContext ctx) {
        ctx.flush();
    }

    /**
     * will be invoked in case of exception is thrown in that step of the pipeline
     * @param ctx the current active channel context
     * @param cause
     */
    @Override
    public void exceptionCaught(ChannelHandlerContext ctx, Throwable cause) {
        // exception thrown, log the error and close the connection
        LOGGER.error("exception has been thrown in the server handler {}", cause.getMessage());
        ctx.close();
    }

    /**
     * handle idle state from the client by closing the connection and sending bye bye to him
     * @param ctx the current active channel context
     * @param evt the triggered event by the server
     * @throws Exception
     */
    @Override
    public void userEventTriggered(ChannelHandlerContext ctx, Object evt) throws Exception {
        if (evt instanceof IdleStateEvent) {
            IdleStateEvent e = (IdleStateEvent) evt;
            // read time out from the client , so time to say good bye !
            LOGGER.info("TIMEOUT is triggered {}",ctx.channel().attr(ClientSessionIdHandler.MY_KEY).get());
            if (e.state() == IdleState.READER_IDLE) {
                final ChannelFuture channelFuture = ctx.writeAndFlush(byeFunction.
                        apply("",ctx.channel().attr(ClientSessionIdHandler.MY_KEY).get()).getResponse());
                // add close action once the write is done , to close the connection with the client
                channelFuture.addListener(ChannelFutureListener.CLOSE);
            }
        } else {
            // keep standard netty actions
            ctx.fireUserEventTriggered(evt);
        }
    }
}
