package com.interview.chat.server;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.interview.chat.cache.ignite.CacheNames;
import com.interview.chat.cache.ignite.CacheStarter;
import com.interview.chat.cache.ignite.DataGrid;
import com.interview.chat.enums.Defaults;
import com.interview.chat.exceptions.ServerFailedToStart;
import com.interview.chat.graph.GraphDefaultWeightedEdge;
import com.interview.chat.injection.ServerPort;
import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.logging.LogLevel;
import io.netty.handler.logging.LoggingHandler;
import org.apache.ignite.Ignite;
import org.jgrapht.graph.DirectedMultigraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Server booting class
 */
public class Server {
    private static final Logger LOGGER = LoggerFactory.getLogger(ChatMain.class);
    private final Provider<ChannelInitializer<SocketChannel>> channelInitializer;
    private final EventLoopGroup bossGroup;
    private final EventLoopGroup workerGroup;
    private final int port;
    private final CacheStarter cacheStarter;
    @Inject
    private DataGrid<Ignite> dataGrid;

    @Inject
    public Server(Provider<ChannelInitializer<SocketChannel>> channelInitializer,
                  EventLoopGroup bossgroup, EventLoopGroup workergroup,
                  @ServerPort int port, CacheStarter cacheStarter) throws Exception {
        this.channelInitializer = channelInitializer;
        this.bossGroup = bossgroup;
        this.workerGroup = workergroup;
        this.port = port;
        this.cacheStarter = cacheStarter;
    }

    public void start() throws ServerFailedToStart {
        LOGGER.debug("Starting the chat server , let us have fun !");
        // starting cache store grid
        cacheStarter.start();
        // create empty graph in the cache store if not present
        DirectedMultigraph<String, GraphDefaultWeightedEdge> directedGraph =
                new DirectedMultigraph<>(GraphDefaultWeightedEdge.class);
        if( dataGrid.getDataGrid().cache(CacheNames.GRAPH_STORE.name()).get(Defaults.GRAPH_KEY.getMsg())==null){
            dataGrid.getDataGrid().cache(CacheNames.GRAPH_STORE.name()).put(Defaults.GRAPH_KEY.getMsg(),directedGraph);
        }
        // starting netty server
        try {
            ServerBootstrap b = new ServerBootstrap();
            b.group(bossGroup, workerGroup)
                    .channel(NioServerSocketChannel.class)
                    .handler(new LoggingHandler(LogLevel.INFO))
                    .childHandler(channelInitializer.get());
            // start the TCP NIO server on the target port
            try {
                b.bind(port).sync().channel().closeFuture().sync();
            } catch (InterruptedException e) {
                LOGGER.error("Error during the socket binding with exception {}",e);
                throw new ServerFailedToStart(e.getMessage());
            }
        } finally {
            LOGGER.debug("shutting down the chat server , the fun is over !");
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
        }

        // add shutdown hook in case of non graceful exit
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            LOGGER.debug("shutting down the chat server , the fun is over !");
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
        }));

    }
}
