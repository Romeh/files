package com.interview.chat.injection;

import com.google.inject.AbstractModule;
import com.google.inject.Provides;
import com.google.inject.TypeLiteral;
import com.interview.chat.cache.ignite.CacheStarter;
import com.interview.chat.cache.ignite.DataGrid;
import com.interview.chat.cache.ignite.IgniteDataGrid;
import com.interview.chat.cache.ignite.IgniteStarter;
import com.interview.chat.data.Response;
import com.interview.chat.flow.annotations.ByeCall;
import com.interview.chat.flow.core.CommandHandler;
import com.interview.chat.flow.core.MsgToCommand;
import com.interview.chat.flow.functions.ByeFunction;
import com.interview.chat.flow.functions.MsgToCmdFunction;
import com.interview.chat.graph.GraphService;
import com.interview.chat.graph.JgraphtService;
import com.interview.chat.handlers.ChatCommandHandler;
import com.interview.chat.handlers.ChatServerHandler;
import com.interview.chat.handlers.ClientSessionIdHandler;
import com.netflix.config.DynamicPropertyFactory;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.ipfilter.AbstractRemoteAddressFilter;
import org.apache.ignite.Ignite;

import java.net.InetSocketAddress;
import java.util.function.BiFunction;

// Injection module for the server
public class BootstrapNettyModule  extends AbstractModule {

    @Override
    protected void configure() {
        bind(BootstrapNettyModule.class);
        bind(CommandHandler.class).to(ChatCommandHandler.class);
        bind(new TypeLiteral< GraphService<String, Integer>>() {}).to(JgraphtService.class);
        bind(MsgToCommand.class).to(MsgToCmdFunction.class);
        bind(CacheStarter.class).to(IgniteStarter.class);
        bind(new TypeLiteral<DataGrid<Ignite>>() {}).to(IgniteDataGrid.class);
        bind(new TypeLiteral<BiFunction<String,String, Response>>() {}).annotatedWith(ByeCall.class).to(ByeFunction.class);
        bind(new TypeLiteral<SimpleChannelInboundHandler<String>>() {}).to(ChatServerHandler.class);
        bind(new TypeLiteral<AbstractRemoteAddressFilter<InetSocketAddress>>() {}).to(ClientSessionIdHandler.class);
        bind(new TypeLiteral<ChannelInitializer<SocketChannel>>() {}).toProvider(ChannelInitProvider.class);
        bindConstant().annotatedWith(ServerPort.class).to(DynamicPropertyFactory.getInstance()
                .getIntProperty("server.port", 50000).get());


    }


    @Provides
    public EventLoopGroup providesEventLoopGroup() {
        return new NioEventLoopGroup();
    }


}
