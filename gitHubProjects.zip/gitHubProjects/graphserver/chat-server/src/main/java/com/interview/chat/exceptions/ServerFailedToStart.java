package com.interview.chat.exceptions;

/**
 * server failed to start exception.
 */
public class ServerFailedToStart extends Exception {
    public ServerFailedToStart(String message) {
        super(message);
    }
}
