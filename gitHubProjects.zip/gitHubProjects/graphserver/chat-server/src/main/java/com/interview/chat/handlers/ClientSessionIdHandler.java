package com.interview.chat.handlers;

import io.netty.channel.ChannelHandler;
import io.netty.channel.ChannelHandlerContext;
import io.netty.handler.ipfilter.AbstractRemoteAddressFilter;
import io.netty.util.AttributeKey;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.net.InetSocketAddress;
import java.util.UUID;

/**
 * responsible to make sure only one active client session at a time
 */
@ChannelHandler.Sharable
public class ClientSessionIdHandler extends AbstractRemoteAddressFilter<InetSocketAddress> {

    private static final Logger LOGGER = LoggerFactory.getLogger(ClientSessionIdHandler.class);
    public final static AttributeKey<String> MY_KEY = AttributeKey.newInstance("MY_KEY");
    public ClientSessionIdHandler() {
    }

    protected boolean accept(ChannelHandlerContext ctx, InetSocketAddress remoteAddress) throws Exception {

        ctx.channel().attr(MY_KEY).set(UUID.randomUUID().toString());

        return true;
    }
}
