package com.interview.chat.server;

import com.google.inject.Guice;
import com.google.inject.Injector;
import com.interview.chat.injection.BootstrapNettyModule;

/**
 * Simplistic telnet server for the chat server via Netty NIO APIs
 */
public final class ChatMain {

    public static void main(String[] args) throws Exception {
        Injector injector = Guice.createInjector(new BootstrapNettyModule());
        Server server=injector.getInstance(Server.class);
        server.start();
    }
}
