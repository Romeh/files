package com.interview.chat.injection;

import com.google.inject.Inject;
import com.google.inject.Provider;
import com.interview.chat.handlers.ChatServerInitializer;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.SimpleChannelInboundHandler;
import io.netty.channel.socket.SocketChannel;
import io.netty.handler.ipfilter.AbstractRemoteAddressFilter;

import java.net.InetSocketAddress;

/**
 * Netty pipeline initializer
 */
public class ChannelInitProvider implements Provider<ChannelInitializer<SocketChannel>> {


    private final AbstractRemoteAddressFilter<InetSocketAddress> oneClientHandler;
    private final SimpleChannelInboundHandler<String> serverHandler;


    @Inject
    public ChannelInitProvider(AbstractRemoteAddressFilter<InetSocketAddress> oneClientHandler, SimpleChannelInboundHandler<String> serverHandler) {
        this.oneClientHandler = oneClientHandler;
        this.serverHandler = serverHandler;
    }


    @Override
    public ChannelInitializer<SocketChannel> get() {
        return new ChatServerInitializer(oneClientHandler, serverHandler);
    }
}
