# Chat server manual

chat server that handle TCP commands from clients in a basic chat bot model for modifying directed wieghted graphs.

  - graph data structure implementation is based into JgraphT open source library
  - directed graphs do not allow loops but it can be enabled 
  - we can change the implemenation to Acyclic directed graph if needed easily by change the directed graph type
  - allow multiple edges between the same 2 nodes 
  - wieghts are only positive integers
  - shortest path is based into Dijkstra algorithm

### To be done
  - closer than given wieght function , there is a draft implemntation but need to be tested and tuned 
  - allow and tune the concurrent modification of the graph model and make it thread safe
  - tune the performacne and the thorough put



### Installation

onec you have the the maven project imported into your IDEA, in the root folder of the imported project do the following 

```sh
$ cd to the root folder where root pom.xml exist
$ mvn clean install
```

once all build successfully , go to chat-server maven module folder , to the target folder and you will see the main jar file chat-server-1.0-SNAPSHOT.jar and a lib folder for the external dependencies 
then you can start the the chat server by :

```sh
$ java -jar chat-server-1.0-SNAPSHOT.ja
```
once it is started you should see the the following in your console before starting the client connection :
```
// server started
20:30:06.359 [nioEventLoopGroup-2-1] INFO  i.n.handler.logging.LoggingHandler - [id: 0x7f14e841] REGISTERED
20:30:06.362 [nioEventLoopGroup-2-1] INFO  i.n.handler.logging.LoggingHandler - [id: 0x7f14e841] BIND: 0.0.0.0/0.0.0.0:50000
20:30:06.366 [nioEventLoopGroup-2-1] INFO  i.n.handler.logging.LoggingHandler - [id: 0x7f14e841, L:/0:0:0:0:0:0:0:0:50000] ACTIVE
```