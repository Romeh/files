package com.interview.chat.graph;

import java.util.Set;

/**
 * graoh service interface
 */
public interface GraphService<NodeType, WeightType> {

    boolean addNode(NodeType nodeName);

    boolean addEdge(NodeType source, NodeType destination, WeightType weight);

    boolean removeNode(NodeType nodeName);

    boolean removeEdge(NodeType source, NodeType destination);

    boolean isNodeExist(NodeType node);

    int getShortestPath(NodeType source, NodeType destination);

    Set<String> getAllNodesLessThanWeight(NodeType source , int maxWeight);


}
