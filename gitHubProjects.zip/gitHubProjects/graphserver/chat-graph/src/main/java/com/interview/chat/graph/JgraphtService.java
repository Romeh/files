package com.interview.chat.graph;

import com.interview.chat.cache.ignite.CacheNames;
import com.interview.chat.cache.ignite.DataGrid;
import com.interview.chat.cache.ignite.IgniteDataGrid;
import com.interview.chat.enums.Defaults;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteException;
import org.apache.ignite.transactions.Transaction;
import org.jgrapht.GraphPath;
import org.jgrapht.alg.shortestpath.DijkstraShortestPath;
import org.jgrapht.graph.DirectedMultigraph;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Collections;
import java.util.Set;

import static org.apache.ignite.transactions.TransactionConcurrency.OPTIMISTIC;
import static org.apache.ignite.transactions.TransactionIsolation.SERIALIZABLE;

/**
 * the graph service for direct connected graph based into Jgrapht library
 */
public class JgraphtService implements GraphService<String, Integer> {
    private static final Logger LOGGER = LoggerFactory.getLogger(JgraphtService.class);
    private DataGrid<Ignite> dataGrid = new IgniteDataGrid();

    /**
     * @param nodeName the node name
     * @return true or false of the node is added properly or not
     */
    @Override
    public boolean addNode(String nodeName) {
        final Ignite grid = dataGrid.getDataGrid();
        boolean isDone = false;
        try {
            try (Transaction tx = grid.transactions().txStart(OPTIMISTIC, SERIALIZABLE)) {
                final IgniteCache<String, DirectedMultigraph<String, GraphDefaultWeightedEdge>> store =
                        grid.cache(CacheNames.GRAPH_STORE.name());
                final DirectedMultigraph<String, GraphDefaultWeightedEdge> graph = store.get(Defaults.GRAPH_KEY.getMsg());
                isDone = graph.addVertex(nodeName);
                if (isDone) {
                    store.put(Defaults.GRAPH_KEY.getMsg(), graph);
                }
                tx.commit();
            }
        } catch (IgniteException e) {
            LOGGER.error("addNode failed for node name {} {}", nodeName, e.getMessage());
        }

        return isDone;

    }

    /**
     * @param source      source node
     * @param destination destination node
     * @param weight      the weight on that edge
     * @return true or false of the edge is added properly or not
     */
    @Override
    public boolean addEdge(String source, String destination, Integer weight) {
        final Ignite grid = dataGrid.getDataGrid();
        boolean isDone;
        try {
            try (Transaction tx = grid.transactions().txStart(OPTIMISTIC, SERIALIZABLE)) {
                final IgniteCache<String, DirectedMultigraph<String, GraphDefaultWeightedEdge>> store =
                        grid.cache(CacheNames.GRAPH_STORE.name());
                final DirectedMultigraph<String, GraphDefaultWeightedEdge> graph = store.get(Defaults.GRAPH_KEY.getMsg());
                try {
                    if (!graph.containsVertex(source) || !graph.containsVertex(destination)) {
                        LOGGER.debug("Nodes are not found  {} {} {} {}", source, destination, graph.containsVertex(source), graph.containsVertex(destination));
                        tx.commit();
                        return false;
                    }
                    if (source.equalsIgnoreCase(destination)) {
                        LOGGER.error("loops are not allowed as it is not a cyclic graph for nodes {} {}", source, destination);
                        tx.commit();
                        return false;
                    }
                    final GraphDefaultWeightedEdge defaultWeightedEdge = graph.addEdge(source, destination);
                    if (defaultWeightedEdge != null) {
                        graph.setEdgeWeight(defaultWeightedEdge, weight);
                        store.put(Defaults.GRAPH_KEY.getMsg(), graph);
                        isDone = true;
                    } else {
                        isDone = false;
                    }
                } catch (IllegalStateException | IllegalArgumentException | IgniteException e) {
                    LOGGER.error("add edge error {} ", e);
                    isDone = false;
                }
                tx.commit();

            }
        } catch (IgniteException e) {
            LOGGER.error("addEdge failed for node source and destination {} {} {}", source, destination, e.getMessage());
            isDone = false;
        }

        return isDone;


    }

    /**
     * @param nodeName the node name
     * @return true or false of the node is removed properly or not
     */
    @Override
    public boolean removeNode(String nodeName) {

        final Ignite grid = dataGrid.getDataGrid();
        boolean isDone = false;
        try {
            try (Transaction tx = grid.transactions().txStart(OPTIMISTIC, SERIALIZABLE)) {
                final IgniteCache<String, DirectedMultigraph<String, GraphDefaultWeightedEdge>> store =
                        grid.cache(CacheNames.GRAPH_STORE.name());
                final DirectedMultigraph<String, GraphDefaultWeightedEdge> graph = store.get(Defaults.GRAPH_KEY.getMsg());
                isDone = graph.removeVertex(nodeName);
                if (isDone) {
                    store.put(Defaults.GRAPH_KEY.getMsg(), graph);
                }
                tx.commit();
            }
        } catch (IgniteException e) {
            LOGGER.error("addNode failed for node name {} {}", nodeName, e.getMessage());
        }

        return isDone;
    }

    /**
     * @param source      source node
     * @param destination destination node
     * @return true or false of the edge is removed properly or not , in that case we return true whatever the case
     */
    @Override
    public boolean removeEdge(String source, String destination) {
        final Ignite grid = dataGrid.getDataGrid();

        try {
            try (Transaction tx = grid.transactions().txStart(OPTIMISTIC, SERIALIZABLE)) {
                final IgniteCache<String, DirectedMultigraph<String, GraphDefaultWeightedEdge>> store =
                        grid.cache(CacheNames.GRAPH_STORE.name());
                final DirectedMultigraph<String, GraphDefaultWeightedEdge> graph = store.get(Defaults.GRAPH_KEY.getMsg());
                // check if nodes exist
                if (!graph.containsVertex(source) || !graph.containsVertex(destination)) {
                    LOGGER.error("source or destination is not found before adding edge {} {}", source, destination);
                    tx.commit();
                    return false;
                }
                final GraphDefaultWeightedEdge edge = graph.removeEdge(source, destination);
                if (edge != null) {
                    store.put(Defaults.GRAPH_KEY.getMsg(), graph);
                    tx.commit();
                }
            }
        } catch (IgniteException e) {
            LOGGER.error("removeEdge failed for nodes {} {}", source, destination, e.getMessage());
        }
        return true;
    }

    /**
     * @param node node name
     * @return true or false if the node exist in the graph
     */
    @Override
    public boolean isNodeExist(String node) {
        return getGraph().containsVertex(node);
    }

    /**
     * @param source      source node
     * @param destination destination node
     * @return the value of the shortest path or MAX Integer value if not connection between 2 nodes
     */
    @Override
    public int getShortestPath(String source, String destination) {

        final Ignite grid = dataGrid.getDataGrid();
        DirectedMultigraph<String, GraphDefaultWeightedEdge> graph = null;
        try {
           // try (Transaction tx = grid.transactions().txStart(OPTIMISTIC, SERIALIZABLE)) {
                final IgniteCache<String, DirectedMultigraph<String, GraphDefaultWeightedEdge>> store =
                        grid.cache(CacheNames.GRAPH_STORE.name());
                graph = store.get(Defaults.GRAPH_KEY.getMsg());
             //   tx.commit();
           // }
            if (source.equalsIgnoreCase(destination)) {
                return 0;
            }
            if (!graph.containsVertex(source) || !graph.containsVertex(destination)) {
                LOGGER.error("source or destination is not found before getShortestPath {} {}", source, destination);

                return Integer.MAX_VALUE;
            }
            DijkstraShortestPath<String, GraphDefaultWeightedEdge> dijkstraAlg =
                    new DijkstraShortestPath<>(graph);
            final GraphPath<String, GraphDefaultWeightedEdge> path = dijkstraAlg.getPath(source, destination);

            if (path != null) {
                LOGGER.info("Shortest path for source to destination is {}", path.getWeight());
                return Double.valueOf(path.getWeight()).intValue();
            }
            return Integer.MAX_VALUE;

        } catch (IgniteException e) {
            LOGGER.error("get Shortest Path failed for nodes {} {}", source, e.getMessage());
            return Integer.MAX_VALUE;
        }
    }

    /**
     * @param source    starting node
     * @param maxWeight the max weight to get all nodes less than that weight
     * @return a set of found nodes or empty set if none found
     */
    @Override
    public Set<String> getAllNodesLessThanWeight(String source, int maxWeight) {
        final Ignite grid = dataGrid.getDataGrid();
        DirectedMultigraph<String, GraphDefaultWeightedEdge> graph = null;
        try {
           // try (Transaction tx = grid.transactions().txStart(OPTIMISTIC, SERIALIZABLE)) {
                final IgniteCache<String, DirectedMultigraph<String, GraphDefaultWeightedEdge>> store =
                        grid.cache(CacheNames.GRAPH_STORE.name());
                graph = store.get(Defaults.GRAPH_KEY.getMsg());
              //  tx.commit();
           // }
            if (!graph.containsVertex(source)) {
                LOGGER.error("source  is not found before getAllNodesLessThanWeight {} {}", source);

                return Collections.emptySet();
            }
            final BreadthFirstShorterThanX breadthFirstIterator = new BreadthFirstShorterThanX(graph, source, maxWeight);
            // execute the traversing
            while (breadthFirstIterator.hasNext()) {
                LOGGER.debug("Next examined node from source {} is {}", source, breadthFirstIterator.next());
            }

            if (!breadthFirstIterator.getFoundNodes().isEmpty()) {
                LOGGER.debug("Found nodes for {} {} {}", source, maxWeight, breadthFirstIterator.getFoundNodes());
                return breadthFirstIterator.getFoundNodes();
            } else {
                return Collections.emptySet();
            }
        } catch (IgniteException e) {
            LOGGER.error("getAllNodesLessThanWeight failed for nodes {} {}", source, e.getMessage());
            return Collections.emptySet();
        }

    }

    private DirectedMultigraph<String, GraphDefaultWeightedEdge> getGraph() {
        final Ignite grid = dataGrid.getDataGrid();
        final IgniteCache<String, DirectedMultigraph<String, GraphDefaultWeightedEdge>> store =
                grid.cache(CacheNames.GRAPH_STORE.name());
        return store.get(Defaults.GRAPH_KEY.getMsg());

    }
}
