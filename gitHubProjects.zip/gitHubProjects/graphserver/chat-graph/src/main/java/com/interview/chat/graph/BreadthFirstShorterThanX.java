package com.interview.chat.graph;

import lombok.Getter;
import org.jgrapht.Graph;
import org.jgrapht.traverse.CrossComponentIterator;

import java.util.ArrayDeque;
import java.util.Deque;
import java.util.Set;
import java.util.TreeSet;

/**
 * WARNING : it is under development and review
 * the custom search function based into Breadth first algorithm to get all nodes less than specific weight from a source
 */
public class BreadthFirstShorterThanX extends CrossComponentIterator<String, GraphDefaultWeightedEdge, GraphDefaultWeightedEdge> {
    private Deque<String> queue;
    private int max;
    private String root;
    @Getter
    private final Set<String> foundNodes = new TreeSet<>();

    /**
     * @param g the graph object
     * @param startVertex the source node
     * @param maxWeight the max weight
     */
    public BreadthFirstShorterThanX(Graph<String, GraphDefaultWeightedEdge> g, String startVertex,int maxWeight) {
        super(g, startVertex);
        this.queue = new ArrayDeque();
        this.root = startVertex;
        this.max=maxWeight;
    }

    /**
     * @return boolean if the queue is empty
     */
    protected boolean isConnectedComponentExhausted() {
        return this.queue.isEmpty();
    }

    /**
     * the method will be called for each new visited node during the search execution, the custom logic needed to be done per node can be added here
     * @param vertex
     * @param edge
     */
    protected void encounterVertex(String vertex, GraphDefaultWeightedEdge edge) {

        putSeenData(vertex, edge);
        // if it is the starting source node , do nothing and skip to its children
        if (vertex.equals(root)) {
            this.queue.add(vertex);
        }
        if (edge != null) {
            if (getWeightToRoot(vertex, edge) < max) {
                foundNodes.add(vertex);
                // just consider adding the node for its children traverse if its weight less than the max otherwise it is no sense to continue with its children
                this.queue.add(vertex);
            }
        }
    }

    /** method will be called if the same node got visited twice
     * @param vertex
     * @param edge
     */
    protected void encounterVertexAgain(String vertex, GraphDefaultWeightedEdge edge) {
        // empty by design no need to do anything with the same vertex has has been visited before
    }

    /** get the weight up to the destination from the current node
     * @param vertex
     * @param edge
     * @return the calculated weight
     */
    private int getWeightToRoot(String vertex, GraphDefaultWeightedEdge edge) {
        // System.out.println("htr!");
        int weight = 0;
        String passedNode = vertex;
        String parent = edge.getSource();
        while (!vertex.equals(root) ) {
            if (!passedNode.equals(vertex)) {
                final GraphDefaultWeightedEdge seenData = this.getSeenData(vertex);
                weight += seenData.getWeight();
                vertex = seenData.getSource();
            } else {
                weight += edge.getWeight();
                vertex = parent;
            }
        }
        return weight;
    }

    /**
     * @return get the next node to scan
     */
    protected String provideNextVertex() {
        return this.queue.removeFirst();
    }
}
