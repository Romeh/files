package com.interview.chat.graph;

import org.jgrapht.graph.DefaultWeightedEdge;

/**
 * the edge object between 2 nodes
 */
public class GraphDefaultWeightedEdge extends DefaultWeightedEdge {
    protected double getWeight() {
        return super.getWeight();
    }
    protected String getSource(){return (String)super.getSource();}
}
