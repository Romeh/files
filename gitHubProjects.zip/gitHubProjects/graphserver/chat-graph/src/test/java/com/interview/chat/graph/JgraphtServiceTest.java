package com.interview.chat.graph;


import com.interview.chat.cache.ignite.DataGrid;
import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.IgniteTransactions;
import org.apache.ignite.transactions.Transaction;
import org.jgrapht.graph.DirectedMultigraph;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.MockitoJUnitRunner;

import static org.apache.ignite.transactions.TransactionConcurrency.OPTIMISTIC;
import static org.apache.ignite.transactions.TransactionIsolation.SERIALIZABLE;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.anyString;
import static org.mockito.Mockito.doNothing;
import static org.mockito.Mockito.when;

/**
 * graph service test
 */
@RunWith(MockitoJUnitRunner.class)
public class JgraphtServiceTest {
    @Mock
    Transaction transaction;
    @Mock
    IgniteTransactions igniteTransactions;
    @Mock
    Ignite ignite;
    @Mock
    DataGrid<Ignite> dataGrid;
    @Mock
    IgniteCache igniteCache;
    DirectedMultigraph<String, GraphDefaultWeightedEdge> directedGraph = new DirectedMultigraph<>(GraphDefaultWeightedEdge.class);
    @InjectMocks
    private GraphService<String, Integer> graphService=new JgraphtService();
    @Before
    public void setUp(){
        when(dataGrid.getDataGrid()).thenReturn(ignite);
        when(ignite.cache(anyString())).thenReturn(igniteCache);
        when(igniteCache.get(anyString())).thenReturn(directedGraph);
        when(ignite.transactions()).thenReturn(igniteTransactions);
        when(igniteTransactions.txStart(OPTIMISTIC, SERIALIZABLE)).thenReturn(transaction);
        doNothing().when(transaction).commit();

    }
    @Test
    public void addNode() throws Exception {
        // add node
        assertTrue( graphService.addNode("Node1"));
        // add duplicate node
        assertTrue( !graphService.addNode("Node1"));
    }

    @Test
    public void addEdge() throws Exception {
        graphService.addNode("Node3");
        graphService.addNode("Node4");

        // add edge between 2 exiting nodes
        assertTrue(graphService.addEdge("Node3","Node4",50));
        // duplicate edge between 2 exiting nodes
        assertTrue(graphService.addEdge("Node3","Node4",50));
        // add edge between 2 non existing nodes
        graphService.removeNode("Node3");
        assertTrue(!graphService.addEdge("Node3","Node4",50));
    }

    @Test
    public void removeNode() throws Exception {
        // remove node
        assertTrue( graphService.addNode("Node5"));
        assertTrue( graphService.removeNode("Node5"));
        // remove duplicate node
        assertTrue( !graphService.removeNode("Node5"));

    }

    @Test
    public void removeEdge() throws Exception {
        graphService.addNode("Node6");
        graphService.addNode("Node7");
        graphService.addEdge("Node6","Node7",50);
        // remove edge between 2 exiting nodes
        assertTrue(graphService.removeEdge("Node6","Node7"));
        // duplicate remove edge between 2 exiting nodes
        assertTrue(graphService.removeEdge("Node6","Node7"));
        // remove edge between 2 non existing nodes
        graphService.removeNode("Node7");
        assertTrue(!graphService.addEdge("Node6","Node7",50));

    }

    @Test
    public void isNodeExist() throws Exception {
        // check positive existing node
        graphService.addNode("Node8");
        assertTrue( graphService.isNodeExist("Node8"));
        // check negative existing node
        graphService.removeNode("Node8");
        assertTrue(! graphService.isNodeExist("Node8"));
    }

    @Test
    public void getShortestPath() throws Exception {
        // get shortest path for 2 connected exciting nodes

        // get shortest path for 2 NOT connected exciting nodes

        // get shortest path for 2 NOT connected NOT exciting nodes

    }

}