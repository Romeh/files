package com.interview.chat.graph;

import org.jgrapht.graph.SimpleDirectedWeightedGraph;

import static org.junit.Assert.assertTrue;

/**
 * shorter than give weight test
 */
public class BreadthFirstShorterThanXTest {
    @org.junit.Test
    public void testGetAllNodesLessThanWeight(){
        SimpleDirectedWeightedGraph<String, GraphDefaultWeightedEdge> graph =
                new SimpleDirectedWeightedGraph<String, GraphDefaultWeightedEdge>(GraphDefaultWeightedEdge.class);
        graph.addVertex("1");
        graph.addVertex("2");
        graph.addVertex("3");
        graph.addVertex("4");
        graph.addVertex("5");

        GraphDefaultWeightedEdge e1 = graph.addEdge("1", "2");
        graph.setEdgeWeight(e1, 5);
        GraphDefaultWeightedEdge e2 = graph.addEdge("2", "3");
        graph.setEdgeWeight(e2, 10);
        GraphDefaultWeightedEdge e3 = graph.addEdge("2", "4");
        graph.setEdgeWeight(e3, 2);
        GraphDefaultWeightedEdge e4 = graph.addEdge("4", "5");
        graph.setEdgeWeight(e4, 2);
        GraphDefaultWeightedEdge e5 = graph.addEdge("5", "3");
        graph.setEdgeWeight(e5, 2);
        final BreadthFirstShorterThanX breadthFirstIterator = new BreadthFirstShorterThanX(graph, "1",15);
        //breadthFirstIterator.setMax(15);

        while(breadthFirstIterator.hasNext()){
            final String next = breadthFirstIterator.next();

        }
        assertTrue(breadthFirstIterator.getFoundNodes().size()==3);
        breadthFirstIterator.getFoundNodes().stream().forEach(s -> System.out.println(s));

    }

}