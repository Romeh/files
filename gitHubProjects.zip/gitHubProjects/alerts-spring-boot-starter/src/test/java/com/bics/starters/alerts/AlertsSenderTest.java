package com.bics.starters.alerts;

import com.bics.starters.alerts.domain.AlertResponse;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.test.context.junit4.SpringRunner;

import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.*;

/**
 * Created by id961900 on 08/09/2017.
 */
@SpringBootTest
@RunWith(SpringRunner.class)
public class AlertsSenderTest {
    @Autowired
    AlertsSender alertsSender;


    @Test
    public void testContextLoads() throws Exception {
        assertNotNull(alertsSender);
    }

    @Test
    public void testPostAlert() throws Exception {
        Map<String,String> map=new HashMap<>();
        map.put("errorOne","error description");

        final AlertResponse alertResponse = alertsSender.postAlert("TEST_1000", "10001", map, "CRTITCAL");
         assertNotNull(alertResponse);
    }



    @Configuration
    @EnableAutoConfiguration
    static class TestConfig {

        @Bean
        public AlertSenderProperties alertSenderProperties() {
            AlertSenderProperties alertSenderProperties=new AlertSenderProperties();
            //  alert manager ITT
            alertSenderProperties.setApiUrl("http://el4964:8080");
            alertSenderProperties.setConnectTimeout(5000);
            alertSenderProperties.setReadTimeout(5000);
            return alertSenderProperties;
        }


    }

}