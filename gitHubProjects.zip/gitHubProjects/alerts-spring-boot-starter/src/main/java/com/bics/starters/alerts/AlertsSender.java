package com.bics.starters.alerts;

import com.bics.alerts.data.Alert;
import com.bics.starters.alerts.domain.AlertResponse;
import com.bics.starters.alerts.enums.AlertsConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.util.Map;

/**
 * Created by id961900 on 08/09/2017.
 */
public class AlertsSender {

    @Autowired
    private RestTemplate restTemplate;

    private AlertsConfig alertsConfig;

    public AlertsSender(AlertsConfig alertsConfig) {
        this.alertsConfig = alertsConfig;

    }

    public AlertResponse postAlert(String serviceCode, String errorCode, Map<String, String> alertContent, String severity) {
        if (serviceCode != null && errorCode != null && alertContent != null) {

            Alert alert = Alert.builder().alertContent(alertContent)
                    .errorCode(errorCode).serviceCode(serviceCode)
                    .severity(severity).build();
            final ResponseEntity<String> stringResponseEntity = restTemplate
                    .postForEntity(alertsConfig.getProperty(AlertsConstants.REST_API_URL.getValue()) + "/alerts",
                            alert, String.class);
            if (stringResponseEntity != null && stringResponseEntity.getStatusCode().is2xxSuccessful()) {
                return AlertResponse.builder().done(true)
                        .build();
            } else if (stringResponseEntity != null && !stringResponseEntity.getStatusCode().is2xxSuccessful()) {
                if (stringResponseEntity.hasBody()) {
                    return AlertResponse.builder().done(false)
                            .errorMessage("Alert create failed with http status code and message: "
                                    + stringResponseEntity.getStatusCode() + " / " + stringResponseEntity.getBody())
                            .build();
                } else {
                    return AlertResponse.builder().done(false)
                            .errorMessage("Alert create failed with http status code : " + stringResponseEntity.getStatusCode())
                            .build();
                }
            } else {
                return AlertResponse.builder().done(false)
                        .errorMessage("No response received from the alert service , please if it is reachable")
                        .build();
            }

        } else {
            return AlertResponse.builder().done(false)
                    .errorMessage("serviceCode,errorCode,alertContent post alert method call are required , no null parameters are allowed for them").build();

        }


    }
}
