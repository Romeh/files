package com.bics.starters.alerts.enums;

/**
 * Created by id961900 on 08/09/2017.
 */
public enum AlertsConstants {

    REST_API_URL("api.url");

    private String value;


    AlertsConstants(String value) {
        this.value = value;
    }

    public String getValue() {
        return this.value;
    }
}
