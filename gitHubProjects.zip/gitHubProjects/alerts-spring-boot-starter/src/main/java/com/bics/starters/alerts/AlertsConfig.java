package com.bics.starters.alerts;

import java.util.Properties;

/**
 * Created by id961900 on 08/09/2017.
 */
public class AlertsConfig extends Properties {
}
