package com.bics.starters.alerts.autoconfigure;

import com.bics.starters.alerts.AlertSenderProperties;
import com.bics.starters.alerts.AlertsConfig;
import com.bics.starters.alerts.AlertsSender;
import com.bics.starters.alerts.enums.AlertsConstants;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;


/**
 * Created by id961900 on 08/09/2017.
 */
@Configuration
@ConditionalOnClass(AlertsSender.class)
@EnableConfigurationProperties(AlertSenderProperties.class)
public class AlertsAutoConfiguration {
    @Autowired
    private AlertSenderProperties alertSenderProperties;


    @Bean
    @ConditionalOnMissingBean
    public AlertsConfig alertsConfig() {

        String rest_api = alertSenderProperties.getApiUrl() != null && !alertSenderProperties.getApiUrl().isEmpty() ?
                alertSenderProperties.getApiUrl() : "http://el4964:8080";

        AlertsConfig alertsConfig = new AlertsConfig();
        alertsConfig.setProperty(AlertsConstants.REST_API_URL.getValue(), rest_api);
        return alertsConfig;
    }

    @Bean
    @ConditionalOnMissingBean
    public AlertsSender alertsSender(AlertsConfig alertsConfig) {
        return new AlertsSender(alertsConfig);
    }


    @Bean
    @ConditionalOnMissingBean
    public RestTemplate restTemplate() {
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        if (alertSenderProperties.getConnectTimeout() != 0) {
            requestFactory.setConnectTimeout(alertSenderProperties.getConnectTimeout());
        } else {
            requestFactory.setConnectTimeout(4000);
        }
        if (alertSenderProperties.getReadTimeout() != 0) {
            requestFactory.setReadTimeout(alertSenderProperties.getConnectTimeout());
        } else {
            requestFactory.setReadTimeout(4000);
        }
        RestTemplate restTemplate = new RestTemplate(requestFactory);
        return restTemplate;

    }


}


