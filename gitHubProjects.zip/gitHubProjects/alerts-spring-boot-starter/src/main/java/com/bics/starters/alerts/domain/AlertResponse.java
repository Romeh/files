package com.bics.starters.alerts.domain;

import lombok.Builder;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.ToString;

/**
 * Created by id961900 on 08/09/2017.
 */

@Getter
@Builder
@ToString
@EqualsAndHashCode
public class AlertResponse {

    boolean done;
    String errorMessage;


}
