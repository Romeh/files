package com.bics.starters.alerts;

import lombok.Getter;
import lombok.Setter;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * Created by id961900 on 08/09/2017.
 */
@ConfigurationProperties(prefix = "bics.alerts")
@Setter
@Getter
public class AlertSenderProperties {

    private String apiUrl;
    private int connectTimeout;
    private int readTimeout;

}
