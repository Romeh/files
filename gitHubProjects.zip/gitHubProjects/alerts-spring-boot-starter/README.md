# BICS Alert sender client spring boot starter

## About

spring boot starter for alert manager client if you want to send an alert from your 
spring boot application 

## Technical Stack

- Java 1.8+
- Maven 3.3+
- Spring boot 1.5.6
- Lombok abstraction


## run and compile locally 

- check out the code locally 
-  then do mvn clean install and it should be fine 


## how to use in your project

- add the following maven dependency :
```
        <dependency>
            <groupId>com.bics.starters</groupId>
            <artifactId>alerts-spring-boot-starter</artifactId>
            <version>RELEASE</version>
        </dependency>
```
- add per environment the following : 

```
 # api-url will be abased into target alert manager environment :
 # UAT : http://el5019:8080
 # ITT : http://el4964:8080
bics:
  alerts:
    api-url: http://localhost:8080
    connect-timeout: 5000
    read-timeout: 5000
```

- inject alert sender in your target class bean 

```
@Service
public class ApplicationService {
    private static final Logger log = LoggerFactory.getLogger(ApplicationService.class);
  
    @Autowired
    AlertsSender alertsSender;
    
    @Transactional
    public void createApplicationItem(ApplicationItem applicationItem) {
         
        Map<String,String> map=new HashMap<>();
        map.put("testErrorCode","testErrorDescription");
        alertsSender.postAlert("TEST_1000","1000",map,"NORMAL");
    
     }
    }
```

- start happily sending alerts using the target service code , error code
- do not forget to configure your alert types in alert manager per application


