Alert Manager 
=========================================


Summary
-------
The project is the BICS Alert Manager application

that cover BICS Java REST API standards
- Java 1.8+
- Maven 3.3+
- Spring boot 1.5.6
- Lombok abstraction
- JPA with H2 file persistence DB
- Swagger 2 API documentation
- Spring retry and circuit breaker for external service call
- REST API model validation 
- Spring cloud config for external configuration on GIT REPO
- Jenkins Pipeline for multi branch project
- BICS continuous delivery and integration standards with Sonar check and release management
- Support retry in sanity checks  


Installation
------------

To run locally:

```sh
$ git clone git@bicsgit.bc:psd-java/alerts-manager.git
$ cd bics-spring-boot-quickstart
$ mvn clean install
```

check on the browser via SWAGGER
-------------------

```sh
http://localhost:8080/swagger-ui.html
```
 
check on the browser via SWAGGER ITT
-------------------

```sh
http://el4964:8080/swagger-ui.html
```
