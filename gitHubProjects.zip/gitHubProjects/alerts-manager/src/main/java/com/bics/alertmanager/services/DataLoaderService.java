package com.bics.alertmanager.services;

import com.bics.alertmanager.entities.AlertConfigEntry;
import com.bics.alertmanager.entities.AlertsConfiguration;
import com.bics.alertmanager.repositories.AlertsConfigRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.PostConstruct;


/**
 * Created by id961900 on 11/08/2017.
 */
@Service
public class DataLoaderService {

    @Autowired
    private AlertsConfigRepository alertsConfigRepository;
    @Autowired
    private AlertsConfiguration alertsConfig;

    @PostConstruct
    public void init() {
        // clean first old config
        alertsConfigRepository.deleteAll();
        // then insert the new fresh config
        this.alertsConfig.getAlertConfigurations().forEach(alertConfigEntity -> {
            final AlertConfigEntry found = alertsConfigRepository.findAlertConfigEntryByServiceCodeAndErrorCode(alertConfigEntity.getServiceCode(), alertConfigEntity.getErrorCode());
            if (found != null) {
                found.setEmails(alertConfigEntity.getEmails());
                found.setErrorCode(alertConfigEntity.getErrorCode());
                found.setServiceCode(alertConfigEntity.getServiceCode());
                found.setMailTemplate(alertConfigEntity.getMailTemplate());
                found.setMaxCount(alertConfigEntity.getMaxCount());
                alertsConfigRepository.save(found);
            } else {
                alertsConfigRepository.save(alertConfigEntity);
            }


        });

    }


}
