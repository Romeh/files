package com.bics.alertmanager.entities;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.List;

/**
 * Created by id961900 on 08/08/2017.
 */
@Entity
@Table(name = "AlertsConfig")
@Builder
@EqualsAndHashCode
@Getter
@Setter
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class AlertConfigEntry implements Serializable {
    @Column(name = "serviceCode", nullable = false)
    @ApiModelProperty(notes = "alert service code required to be entered by user into REST API ", required = true)
    String serviceCode;
    @Column(name = "errorCode", nullable = false)
    @ApiModelProperty(notes = "alert error code required to be entered by user into REST API ", required = true)
    String errorCode;
    @Column(name = "emails", nullable = false)
    @ElementCollection(targetClass = String.class)
    @ApiModelProperty(notes = "notification mails list required to be entered by user into REST API ", required = true)
    List<String> emails;
    @Column(name = "maxCount", nullable = false)
    @ApiModelProperty(notes = "max occurrence count before sending mail, required to be entered by user into REST API ")
    int maxCount;
    @Column(name = "mailTemplate", nullable = false)
    @ApiModelProperty(notes = "mail template name , do not forget to add that mail template to alert manager resources ")
    String mailTemplate;
    @Id
    @GeneratedValue
    @ApiModelProperty(notes = "the auto internal generated id by alert manager DB , not required to be entered by user into REST API ")
    private Long id;

}
