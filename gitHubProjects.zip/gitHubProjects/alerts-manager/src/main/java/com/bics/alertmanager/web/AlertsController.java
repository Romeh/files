package com.bics.alertmanager.web;

import com.bics.alertmanager.entities.AlertConfigEntry;
import com.bics.alertmanager.entities.AlertEntry;
import com.bics.alertmanager.services.AlertsService;
import com.bics.alerts.data.Alert;
import com.bics.alerts.data.AlertConfig;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Created by id961900 on 08/08/2017.
 */
@RestController
@RequestMapping("/alerts")
@Api(value = "Alert manager")
public class AlertsController {

    private static final Logger log = LoggerFactory.getLogger(AlertsController.class);

    @Autowired
    private ModelMapper modelMapper;

    @Autowired
    private AlertsService alertsService;

    @RequestMapping(value = "/{serviceId}", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    @ApiOperation(value = "view the list of current active created stored alerts for service ID", response = AlertEntry.class, tags = "Alerts API")
    public List<Alert> getServiceAlerts(@PathVariable final String serviceId) {
        log.debug("Trying to retrieve alerts by ID: {}", serviceId);
        return alertsService.getAlertForServiceId(serviceId).stream()
                .map(alertEntry -> modelMapper.map(alertEntry, Alert.class)).collect(Collectors.toList());
    }


    @RequestMapping(method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    @ApiOperation(value = "view the list of ALL current active created stored alerts", response = AlertEntry.class, tags = "Alerts API")
    public List<Alert> getAllAlerts() {
        log.debug("Trying to retrieve all alerts");
        return alertsService.getAllAlerts().stream()
                .map(alertEntry -> modelMapper.map(alertEntry, Alert.class)).collect(Collectors.toList());

    }


    @RequestMapping(method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @ResponseStatus(HttpStatus.CREATED)
    @ApiOperation(value = "Create an alert entry into the alert manager", tags = "Alerts API")
    public void createAlert(@Valid @RequestBody Alert request) {
        log.debug("Trying to create an alert: {}", request.toString());
        alertsService.createAlertEntry(modelMapper.map(request, AlertEntry.class));
    }


    @RequestMapping(value = "/{alertId}", method = RequestMethod.PUT, produces = "application/json")
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "Update an alert entry into the alert manager", tags = "Alerts API")
    public void updateAlert(@PathVariable final long alertId,
                            @Valid @RequestBody Alert request) {
        log.debug("Trying to update an alert: {}", request.toString());
        alertsService.updateAlertEntry(alertId, modelMapper.map(request, AlertEntry.class));
        log.debug("End Of updateCall: {}", request.toString());

    }


    @RequestMapping(value = "/{serviceCode}/{errorCode}", method = RequestMethod.DELETE, produces = "application/json")
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "delete an alert entry into the alert manager", tags = "Alerts API")
    public void deleteAlert(@PathVariable final String serviceCode, @PathVariable final String errorCode) {
        log.debug("Trying to delete an alert: {},{}", serviceCode, errorCode);
        alertsService.deleteAlertEntry(serviceCode, errorCode);
    }

    @RequestMapping(value = "/config/{configId}", method = RequestMethod.PUT, produces = "application/json")
    @ResponseBody
    @ResponseStatus(HttpStatus.OK)
    @ApiOperation(value = "delete an alert config config into the alert manager to be used for that alert type", tags = "Alerts Config API")
    public void updateAlertConfig(@PathVariable final long configId, @Valid @RequestBody AlertConfig request) {
        log.debug("Trying to update an alert config: {}", configId);
        alertsService.updateAlertConfig(configId, modelMapper.map(request, AlertConfigEntry.class));
    }

    @RequestMapping(value = "/config/", method = RequestMethod.POST, produces = "application/json")
    @ResponseBody
    @ResponseStatus(HttpStatus.CREATED)
    @ApiOperation(value = "create an alert config config into the alert manager to be used for that alert type", tags = "Alerts Config API")
    public void createAlertConfig(@Valid @RequestBody AlertConfig request) {
        log.debug("Trying to create an alert config: {}", request.toString());
        alertsService.createAlertConfig(modelMapper.map(request, AlertConfigEntry.class));
    }

    @RequestMapping(value = "/config/", method = RequestMethod.GET, produces = "application/json")
    @ResponseBody
    @ApiOperation(value = "Get All alert config entries into the alert manager for view purposes", tags = "Alerts Config API")
    public List<AlertConfig> getAllAlertsConfig() {
        log.debug("Trying to get all alerts config");
        return alertsService.getAllAlertsConfig().stream()
                .map(alertConfigEntry -> modelMapper.map(alertConfigEntry, AlertConfig.class))
                .collect(Collectors.toList());
    }


}
