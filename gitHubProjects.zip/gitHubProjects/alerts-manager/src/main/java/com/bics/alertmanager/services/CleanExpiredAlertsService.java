package com.bics.alertmanager.services;

import com.bics.alertmanager.repositories.AlertsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

/**
 * Created by id961900 on 22/08/2017.
 */
@Service
public class CleanExpiredAlertsService {
    private static final Logger log = LoggerFactory.getLogger(CleanExpiredAlertsService.class);

    @Autowired
    private AlertsRepository alertsRepository;

    @Scheduled(initialDelayString = "${initialDelay}", fixedDelayString = "${fixedDelay}")
    @Transactional
    public void cleanExpiredRecords() {
        log.debug("Starting the clean up job to clear the expired records");
        long towMinutesRange = System.currentTimeMillis() - 900000;
        int count = alertsRepository.deleteAlertEntriesByTimestampIsLessThanEqual(towMinutesRange);
        log.debug("Finished cleaning out {} records", count);
    }

    @Transactional
    public void deleteCommunicatedAlert(String serviceId, String errorCode) {
        alertsRepository.deleteAlertEntriesByServiceCodeAndErrorCode(serviceId, errorCode);
    }


}
