package com.bics.alertmanager.services;

import com.bics.alertmanager.entities.AlertConfigEntry;
import com.bics.alertmanager.entities.AlertEntry;
import com.bics.alertmanager.exception.NotAllowedOperationException;
import com.bics.alertmanager.exception.ResourceNotFoundException;
import com.bics.alertmanager.repositories.AlertsConfigRepository;
import com.bics.alertmanager.repositories.AlertsRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.CompletableFuture;

/**
 * Created by id961900 on 09/08/2017.
 */
@Service
public class AlertsService {
    private static final Logger log = LoggerFactory.getLogger(AlertsService.class);
    @Autowired
    private AlertsRepository alertsRepository;

    @Autowired
    private AlertsConfigRepository alertsConfigRepository;

    @Autowired
    private CleanExpiredAlertsService cleanExpiredAlertsService;

    @Autowired
    private MailService mailService;

    @Value("${defaultReceiver}")
    private String defaultReceiver;

    @Transactional
    public void createAlertEntry(AlertEntry alertEntry) {
        log.debug("createAlertEntry service call with {}", alertEntry.toString());
        int maxCount = 1;
        String mailTemplate = "ticket";
        List<String> receivers = Arrays.asList(defaultReceiver);
        final AlertConfigEntry config = getConfigForServiceIdCodeId(alertEntry.getServiceCode(), alertEntry.getErrorCode());
        if (config != null) {
            log.debug("createAlertEntry config entry found  {}", config.toString());
            maxCount = config.getMaxCount() != 0 ? config.getMaxCount() : 1;
            mailTemplate = config.getMailTemplate() != null && !config.getMailTemplate().isEmpty() ?
                    config.getMailTemplate() : "ticket";
            if (config.getEmails() != null && !config.getEmails().isEmpty()) {
                receivers = config.getEmails();
            }
        }
        alertEntry.setTimestamp(System.currentTimeMillis());
        final AlertEntry save = alertsRepository.save(alertEntry);
        if (save != null) {
            int count = alertsRepository.countAlertEntriesByServiceCodeAndErrorCode(alertEntry.getServiceCode(), alertEntry.getErrorCode());
            if (count >= maxCount) {
                log.debug("createAlertEntry max count reached  {}", alertEntry.toString());
                sendMail(alertEntry, receivers, mailTemplate);
            }
        }

    }

    public List<AlertEntry> getAlertForServiceId(String serviceId) {
        log.debug("GetAlertForServiceId service call with {}", serviceId);
        return alertsRepository.findAlertEntriesByServiceCode(serviceId);
    }

    @Transactional
    public void updateAlertEntry(long alertId, AlertEntry alertEntry) {
        log.debug("updateAlertEntry service call with {}", alertEntry.toString());
        final AlertEntry update = alertsRepository.findOne(alertId);
        if (update != null) {
            log.debug("updateAlertEntry found match {}", alertEntry.toString());
            update.setAlertContent(alertEntry.getAlertContent());
            update.setErrorCode(alertEntry.getErrorCode());
            update.setServiceCode(alertEntry.getServiceCode());
            update.setSeverity(alertEntry.getSeverity());
            update.setTimestamp(System.currentTimeMillis());
            alertsRepository.save(update);
        } else {
            throw new ResourceNotFoundException("Alert not found in the DB");
        }

    }


    public List<AlertEntry> getAllAlerts() {
        log.debug("getAllAlerts service call");
        return alertsRepository.findAll();
    }

    public List<AlertConfigEntry> getAllAlertsConfig() {
        log.debug("get all alerts config call");
        return alertsConfigRepository.findAll();
    }

    @Transactional
    public void deleteAlertEntry(String serviceCode, String errorCode) {
        log.debug("deleteAlertEntry service call: {}, {}", serviceCode, errorCode);
        alertsRepository.deleteAlertEntriesByServiceCodeAndErrorCode(serviceCode, errorCode);
    }


    public AlertConfigEntry getConfigForServiceIdCodeId(String serviceId, String codeId) {
        log.debug("getConfigForServiceIdCodeId service call: {},{}", serviceId, codeId);
        return alertsConfigRepository.findAlertConfigEntryByServiceCodeAndErrorCode(serviceId, codeId);
    }

    @Transactional
    public void updateAlertConfig(long alertConfigId, AlertConfigEntry alertConfigEntry) {
        log.debug("updateAlertConfig service call: {}, {}", alertConfigId, alertConfigEntry.toString());
        final AlertConfigEntry one = alertsConfigRepository.findOne(alertConfigId);
        if (one != null) {
            log.debug("updateAlertConfig found match {}", alertConfigEntry.toString());
            one.setEmails(alertConfigEntry.getEmails());
            one.setErrorCode(alertConfigEntry.getErrorCode());
            one.setServiceCode(alertConfigEntry.getServiceCode());
            one.setMailTemplate(alertConfigEntry.getMailTemplate());
            one.setMaxCount(alertConfigEntry.getMaxCount());
            alertsConfigRepository.save(one);
        } else {
            throw new ResourceNotFoundException("Alert config not found in the DB");
        }

    }


    @Transactional
    public void createAlertConfig(AlertConfigEntry alertConfigEntry) {
        log.debug("Create Alert Config entry service call: {}", alertConfigEntry.toString());
        final AlertConfigEntry found = alertsConfigRepository
                .findAlertConfigEntryByServiceCodeAndErrorCode(alertConfigEntry.getServiceCode(),
                        alertConfigEntry.getErrorCode());
        if (found != null && found.getServiceCode().equals(alertConfigEntry.getServiceCode())) {
            throw new NotAllowedOperationException("Can not create config for an already existing configuration of the requested service code and error code , use Update API instead");
        } else {
            alertsConfigRepository.save(alertConfigEntry);

        }
    }

    protected void sendMail(AlertEntry alertEntry, List<String> emails, String mailTemplate) {
        // send the mail then delete the entry
        CompletableFuture.supplyAsync(() -> mailService.sendAlert(alertEntry, emails, mailTemplate))
                .whenComplete((aBoolean, throwable) -> {
                    if (throwable != null) {
                        log.error("Sending mail has been failed for {}", alertEntry.toString());
                    } else {
                        if (aBoolean) {
                            log.debug("sending mail is done for  {}", alertEntry.toString());
                            cleanExpiredAlertsService.deleteCommunicatedAlert(alertEntry.getServiceCode(), alertEntry.getErrorCode());
                        }
                    }

                });
    }


}
