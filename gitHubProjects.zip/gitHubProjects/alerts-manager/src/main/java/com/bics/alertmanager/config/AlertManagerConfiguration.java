package com.bics.alertmanager.config;

import com.bics.mailproxy.client.MailProxyServiceClient;
import com.bics.mailproxy.client.ProxyMailer;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Created by id961900 on 16/08/2017.
 */
@Configuration
public class AlertManagerConfiguration {

    @Value("${mail.service.baseUrl}")
    private String baseUrl;
    @Value("${mail.service.user}")
    private String user;
    @Value("${mail.service.password}")
    private String password;

    @Bean
    MailProxyServiceClient mailProxyServiceClient() {
        return MailProxyServiceClient.forUrl(baseUrl, user, password);
    }

    @Bean
    ProxyMailer proxyMailer(MailProxyServiceClient mailProxyServiceClient) {
        return new ProxyMailer(mailProxyServiceClient);
    }

    @Bean
    ModelMapper modelMapper() {
        return new ModelMapper();
    }

}
