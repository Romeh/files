package com.bics.alertmanager.services;

import com.bics.alertmanager.entities.AlertEntry;
import com.bics.common.mail.MailException;
import com.bics.mailproxy.client.ProxyMailer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.annotation.CircuitBreaker;
import org.springframework.retry.annotation.Recover;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import java.util.Arrays;
import java.util.List;
import java.util.Locale;

/**
 * Created by id961900 on 17/08/2017.
 */
@Service
public class MailService {
    private static final Logger log = LoggerFactory.getLogger(MailService.class);

    @Value("${mail.service.undeliverable}")
    private String undeliverable;

    @Value("${mail.from.bpo.mailbox}")
    private String mailFromBpo;

    @Value("${mail.default.receiver}")
    private String defaultReceiver;

    @Autowired
    private TemplateEngine templateEngine;

    @Autowired
    private ProxyMailer mailer;

    /*
    * the mail send service to the target mail proxy
    * */
    public boolean sendAlert(AlertEntry alertEntry, List<String> emails, String mailTemplate) {
        log.debug("Sending alert  e-mail to '{}'", emails.toString());
        Locale locale = Locale.getDefault();
        Context context = new Context(locale);
        context.setVariable("alert", alertEntry);
        String content = templateEngine.process(mailTemplate, context);
        return sendEmail(mailFromBpo, emails, "New Application ticket has been created", content);
    }

    @CircuitBreaker(maxAttempts = 2, openTimeout = 5000l, resetTimeout = 10000l, exclude = MailException.class)
    public boolean sendEmail(String from, List<String> to, String subject, String content) {
        log.debug("Sending to {}", to.toString());
        try {
            mailer.send(toInternetAddresses(to), toInternetAddress(from), subject, content);
            log.debug("Sent to {}", to.toString());
            return true;
        } catch (MailException mailException) {
            log.warn("Error sending email", mailException);
            log.warn("From: " + from);
            log.warn("To: " + to);
            log.warn("Subject: " + subject);
            log.warn("Content: " + content);
            return false;
        }
    }


    private InternetAddress[] toInternetAddresses(List<String> addresses) {
        List<String> localAddresses = addresses;
        if (localAddresses == null) {
            localAddresses = Arrays.asList(defaultReceiver);
        }
        InternetAddress[] internetAddresses = new InternetAddress[localAddresses.size()];
        for (int i = 0; i < localAddresses.size(); i++) {
            internetAddresses[i] = toInternetAddress(localAddresses.get(i));
        }
        return internetAddresses;
    }

    private InternetAddress toInternetAddress(String address) {
        String localAddress = address;
        if (localAddress == null) {
            localAddress = defaultReceiver;
        }
        InternetAddress internetAddress = null;
        try {
            internetAddress = new InternetAddress(localAddress);
        } catch (AddressException ex) {
            log.error("Cannot convert to InternetAddress", ex);
            try {
                internetAddress = new InternetAddress(undeliverable);
            } catch (AddressException exx) {
                log.error("Cannot convert to InternetAddress", exx);
            }
        }
        return internetAddress;
    }

    /**
     * The recover method needs to have same return type and parameters.
     *
     * @return
     */
    @Recover
    private boolean fallbackForCall() {
        log.error("Fallback for mail service call invoked, mail service is NOT reachable");
        return false;
    }
}
