package com.bics.alertmanager.repositories;


import com.bics.alertmanager.entities.AlertConfigEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by id961900 on 23/08/2017.
 */
@Repository
public interface AlertsConfigRepository extends JpaRepository<AlertConfigEntry, Long> {

    AlertConfigEntry findAlertConfigEntryByServiceCodeAndErrorCode(String serviceCode, String errorCode);


}
