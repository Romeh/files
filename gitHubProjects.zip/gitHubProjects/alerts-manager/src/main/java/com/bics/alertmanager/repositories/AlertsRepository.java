package com.bics.alertmanager.repositories;

import com.bics.alertmanager.entities.AlertEntry;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * Created by id961900 on 23/08/2017.
 */
@Repository
public interface AlertsRepository extends JpaRepository<AlertEntry, Long> {

    List<AlertEntry> findAlertEntriesByServiceCode(String serviceId);

    int countAlertEntriesByServiceCodeAndErrorCode(String serviceId, String errorCode);

    int deleteAlertEntriesByServiceCodeAndErrorCode(String serviceId, String errorCode);

    int deleteAlertEntriesByTimestampIsLessThanEqual(long timeStamp);


}
