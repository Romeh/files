package com.bics.alertmanager.entities;

import io.swagger.annotations.ApiModelProperty;
import lombok.*;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Map;

/**
 * Created by id961900 on 19/07/2017.
 */
@Entity
@Table(name = "Alerts")
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
@AllArgsConstructor
@NoArgsConstructor
public class AlertEntry implements Serializable {
    @Column(name = "alertContent", nullable = false)
    @ElementCollection(targetClass = String.class)
    @ApiModelProperty(notes = "the key value alert content for error description required to be entered by user into REST API ", required = true)
    private Map<String, String> alertContent;
    @ApiModelProperty(notes = "alert error code required to be entered by user into REST API ", required = true)
    @Column(name = "errorCode", nullable = false)
    private String errorCode;
    @ApiModelProperty(notes = "alert service code required to be entered by user into REST API ", required = true)
    @Column(name = "serviceCode", nullable = false)
    private String serviceCode;
    @ApiModelProperty(notes = "alert severity required to be entered by user into REST API ", required = true)
    @Column(name = "severity", nullable = false)
    private String severity;
    @Column(name = "timestamp", nullable = false)
    @ApiModelProperty(notes = "the auto internal generated timestamp by alert manager  , not required to be entered by user into REST API ")
    private Long timestamp;
    @Id
    @GeneratedValue
    @ApiModelProperty(notes = "the auto internal generated id by alert manager DB , not required to be entered by user into REST API ")
    private Long id;
}
