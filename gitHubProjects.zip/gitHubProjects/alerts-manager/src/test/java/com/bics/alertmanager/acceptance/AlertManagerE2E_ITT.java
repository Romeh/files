package com.bics.alertmanager.acceptance;

import com.bics.alerts.data.Alert;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.RestTemplate;

import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertTrue;


public class AlertManagerE2E_ITT {

    private int port = 8080;
    private RestTemplate template;
    private URL base;
    private Alert alertEntry;

    @Before
    public void setUp() throws Exception {
        this.base = new URL("http://el5019:" + port + "/");
        // disable proxy if you wanna run locally
        //  SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        // Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("userproxy.glb.ebc.local", 8080));
        // requestFactory.setProxy(proxy);
        template = new RestTemplate();
        Map<String, String> content = new HashMap<>();
        content.put("error", "errorContent");
        alertEntry = Alert.builder().errorCode("1001_TEST").serviceCode("IOT_TEST").severity("CRITICAL").alertContent(content).build();


    }

    @Test
    public void test_1_contextLoads() {
        assertTrue(template.getForEntity(base + "/health", String.class).getStatusCode().is2xxSuccessful());

    }

    @Test
    public void test_2_testCreateAlertConfigAndAlert() throws JSONException {
        // create an alert entry
        assertTrue(template.postForEntity(base + "/alerts/", alertEntry, Alert.class).getStatusCode().is2xxSuccessful());
        // get the response entry and check the content
        final ResponseEntity<Alert[]> exchange = template.getForEntity(base + "/alerts", Alert[].class);
        final Alert[] body = exchange.getBody();
        assertTrue(body.length == 1);
        assertTrue(body[0].getServiceCode().equalsIgnoreCase("IOT_TEST"));
        assertTrue(body[0].getErrorCode().equalsIgnoreCase("1001_TEST"));
        // test mail send action
        // create an alert entry
        assertTrue(template.postForEntity(base + "/alerts/", alertEntry, Alert.class).getStatusCode().is2xxSuccessful());
        try {
            Thread.sleep(2000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        // get the response entry and check the content
        final ResponseEntity<Alert[]> exchange2 = template.getForEntity(base + "/alerts", Alert[].class);
        final Alert[] body2 = exchange2.getBody();
        assertTrue(body2.length == 0);

    }


}
