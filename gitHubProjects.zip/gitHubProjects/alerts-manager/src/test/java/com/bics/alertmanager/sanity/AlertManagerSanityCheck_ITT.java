package com.bics.alertmanager.sanity;

import com.bics.alertmanager.retry.Retry;
import com.bics.alertmanager.retry.RetryRule;
import com.bics.alerts.data.Alert;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;

import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertTrue;


public class AlertManagerSanityCheck_ITT {
    @Rule
    public final RetryRule retry = new RetryRule();
    private int port = 8080;
    private RestTemplate template;
    private URL base;
    private Alert alertEntry;

    @Before
    public void setUp() throws Exception {
        this.base = new URL("http://el4964:" + port + "/");
        // disable proxy if you wanna run locally
        SimpleClientHttpRequestFactory requestFactory = new SimpleClientHttpRequestFactory();
        Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("userproxy.glb.ebc.local", 8080));
        requestFactory.setProxy(proxy);
        template = new RestTemplate();
        Map<String, String> content = new HashMap<>();
        content.put("error", "errorContent");
        alertEntry = Alert.builder().errorCode("1001_TEST").serviceCode("IOT_TEST").severity("CRITICAL").alertContent(content).build();


    }

    @Test
    @Retry(times = 3, timeout = 20000)
    public void test_is_server_up() {
        assertTrue(template.getForEntity(base + "/health", String.class).getStatusCode().is2xxSuccessful());

    }


}
