package com.bics.alertmanager.web;

import com.bics.alertmanager.entities.AlertEntry;
import com.bics.alertmanager.exception.ResourceNotFoundException;
import com.bics.alertmanager.services.AlertsService;
import com.bics.alerts.data.Alert;
import com.bics.alerts.data.AlertConfig;
import com.google.gson.Gson;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;
import org.modelmapper.ModelMapper;
import org.springframework.http.MediaType;
import org.springframework.test.util.ReflectionTestUtils;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.setup.MockMvcBuilders;
import org.springframework.web.util.NestedServletException;

import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

/**
 * Created by id961900 on 11/08/2017.
 */
public class AlertsControllerTest {
    private static final MediaType APPLICATION_JSON_UTF8 = new MediaType(MediaType.APPLICATION_JSON.getType(), MediaType.APPLICATION_JSON.getSubtype(),
            Charset.forName("utf8"));

    private MockMvc mockMvc;

    private AlertsService alertsService;

    private Alert alertEntry;

    private AlertConfig alertConfigEntry;

    @Before
    public void setUp() throws Exception {
        AlertsController alertsController = new AlertsController();
        Map<String, String> content = new HashMap<>();
        content.put("error", "errorContent");
        alertEntry = Alert.builder().errorCode("errorCode").serviceCode("serviceCode").severity("CRITICAL").alertContent(content).build();
        alertConfigEntry = AlertConfig.builder().errorCode("1111").serviceCode("11111").maxCount(3).mailTemplate("mailtemplate").emails(Arrays.asList("test")).build();
        ErrorHandler errorHandler = new ErrorHandler();
        ModelMapper modelMapper = new ModelMapper();
        this.alertsService = Mockito.mock(AlertsService.class);
        ReflectionTestUtils.setField(alertsController, "alertsService", this.alertsService);
        ReflectionTestUtils.setField(alertsController, "modelMapper", modelMapper);
        this.mockMvc = MockMvcBuilders.standaloneSetup(alertsController, errorHandler).build();

    }

    @Test
    public void getAllAlerts() throws Exception {
        Mockito.when(this.alertsService.getAllAlerts()).thenReturn(new ArrayList<>());
        this.mockMvc.perform(get("/alerts")).andExpect(status().isOk());
    }

    @Test
    public void getAllAlertsConfig() throws Exception {
        Mockito.when(this.alertsService.getAllAlertsConfig()).thenReturn(new ArrayList<>());
        this.mockMvc.perform(get("/alerts")).andExpect(status().isOk());
    }


    @Test
    public void createAlert() throws Exception {
        Mockito.doNothing().when(this.alertsService).createAlertEntry(Mockito.any());
        this.mockMvc.perform(post("/alerts").contentType(APPLICATION_JSON_UTF8).content(new Gson().toJson(alertEntry))).andExpect(status().isCreated());
    }

    @Test
    public void createAlertConfig() throws Exception {
        Mockito.doNothing().when(this.alertsService).createAlertConfig(Mockito.any());
        this.mockMvc.perform(post("/alerts/config/").contentType(APPLICATION_JSON_UTF8).content(new Gson().toJson(alertConfigEntry))).andExpect(status().isCreated());
    }

    @Test
    public void UpdateAlert() throws Exception {

        Mockito.doNothing().when(this.alertsService).updateAlertEntry(Mockito.anyLong(), Mockito.any());
        this.mockMvc.perform(put("/alerts/" + 1).contentType(APPLICATION_JSON_UTF8).content(new Gson().toJson(alertEntry))).andExpect(status().isOk());
    }

    @Test
    public void UpdateAlertConfig() throws Exception {

        Mockito.doNothing().when(this.alertsService).updateAlertConfig(Mockito.anyLong(), Mockito.any());
        this.mockMvc.perform(put("/alerts/config/" + 1).contentType(APPLICATION_JSON_UTF8).content(new Gson().toJson(alertConfigEntry))).andExpect(status().isOk());
    }

    @Test(expected = NestedServletException.class)
    public void UpdateAlertNotFound() throws Exception {
        Mockito.doThrow(ResourceNotFoundException.class).when(alertsService).updateAlertEntry(Mockito.anyLong(), Mockito.any());
        this.mockMvc.perform(put("/alerts/" + 1).contentType(APPLICATION_JSON_UTF8).content(new Gson().toJson(alertEntry))).andExpect(status().isNotFound());
    }


    @Test
    public void deleteAlter() throws Exception {

        Mockito.doNothing().when(this.alertsService).deleteAlertEntry(Mockito.anyString(), Mockito.anyString());
        this.mockMvc.perform(delete("/alerts/serviceCode/errorCode")).andExpect(status().isOk());
    }


    @Test
    public void getServiceAlert() throws Exception {
        Mockito.when(this.alertsService.getAlertForServiceId(Mockito.anyString()))
                .thenReturn(Arrays.asList(AlertEntry.builder().errorCode("errorCode").serviceCode("serviceCode").severity("CRITICAL").build()));
        this.mockMvc.perform(get("/alerts/serviceCode")).andExpect(status().isOk()).andExpect(content()
                .string("[{\"alertContent\":null,\"errorCode\":\"errorCode\",\"serviceCode\":\"serviceCode\",\"severity\":\"CRITICAL\"}]"));
    }


}