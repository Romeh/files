package com.bics.alertmanager.services;

import com.bics.alertmanager.entities.AlertConfigEntry;
import com.bics.alertmanager.entities.AlertsConfiguration;
import com.bics.alertmanager.repositories.AlertsConfigRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/**
 * Created by id961900 on 12/09/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class DataLoaderServiceTest {

    @Mock
    AlertsConfigRepository alertsConfigRepository;
    @InjectMocks
    DataLoaderService dataLoaderService;
    AlertConfigEntry alertConfigEntry;
    @Mock
    private AlertsConfiguration alertsConfig;

    @Before
    public void setUp() throws Exception {
        alertConfigEntry = AlertConfigEntry.builder().serviceCode("errorCode").errorCode("serviceCode")
                .emails(Arrays.asList("test@bics.com")).maxCount(2).build();
        doNothing().when(alertsConfigRepository).deleteAll();
        when(alertsConfigRepository.save(any(AlertConfigEntry.class))).thenReturn(alertConfigEntry);
        when(alertsConfig.getAlertConfigurations()).thenReturn(Arrays.asList(alertConfigEntry));

    }

    @Test
    public void test_not_found_config() {
        when(alertsConfigRepository.findAlertConfigEntryByServiceCodeAndErrorCode(anyString(), anyString())).thenReturn(null);
        dataLoaderService.init();
        Mockito.verify(alertsConfigRepository, times(1)).save(any(AlertConfigEntry.class));
    }

    @Test
    public void test_found_config() {
        when(alertsConfigRepository.findAlertConfigEntryByServiceCodeAndErrorCode(anyString(), anyString())).thenReturn(alertConfigEntry);
        dataLoaderService.init();
        Mockito.verify(alertsConfigRepository, times(1)).save(any(AlertConfigEntry.class));
    }

}