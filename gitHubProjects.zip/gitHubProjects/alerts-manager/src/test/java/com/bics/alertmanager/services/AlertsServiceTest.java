package com.bics.alertmanager.services;

import com.bics.alertmanager.entities.AlertConfigEntry;
import com.bics.alertmanager.entities.AlertEntry;
import com.bics.alertmanager.exception.NotAllowedOperationException;
import com.bics.alertmanager.exception.ResourceNotFoundException;
import com.bics.alertmanager.repositories.AlertsConfigRepository;
import com.bics.alertmanager.repositories.AlertsRepository;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.Arrays;
import java.util.concurrent.CompletableFuture;

import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.anyString;
import static org.mockito.Mockito.when;

/**
 * Created by id961900 on 23/08/2017.
 */
@RunWith(MockitoJUnitRunner.class)
public class AlertsServiceTest {

    @Mock
    AlertsRepository alertsRepository;

    @Mock
    AlertsConfigRepository alertsConfigRepository;

    @Mock
    CompletableFuture completableFuture;

    @Mock
    MailService mailService;

    @InjectMocks
    AlertsService alertsService;

    AlertEntry alertEntry;

    AlertConfigEntry alertConfigEntry;

    @Before
    public void setUp() throws Exception {
        alertEntry = AlertEntry.builder().errorCode("errorCode").serviceCode("serviceCode")
                .timestamp(System.currentTimeMillis()).build();
        alertConfigEntry = AlertConfigEntry.builder().serviceCode("errorCode").errorCode("serviceCode")
                .emails(Arrays.asList("test@bics.com")).maxCount(2).build();
        when(mailService.sendAlert(any(), any(), anyString())).thenReturn(true);


    }

    @Test
    public void testCreateEntry() {
        Mockito.when(alertsRepository.save(any(AlertEntry.class))).thenReturn(alertEntry);
        when(alertsConfigRepository.findAlertConfigEntryByServiceCodeAndErrorCode(anyString(), anyString())).thenReturn(alertConfigEntry);
        when(alertsRepository.countAlertEntriesByServiceCodeAndErrorCode(anyString(), anyString())).thenReturn(2);
        alertsService.createAlertEntry(alertEntry);


    }


    @Test
    public void testCreateEntryNoConfigFound() {
        Mockito.when(alertsRepository.save(any(AlertEntry.class))).thenReturn(alertEntry);
        when(alertsConfigRepository.findAlertConfigEntryByServiceCodeAndErrorCode(anyString(), anyString())).thenReturn(null);
        when(alertsRepository.countAlertEntriesByServiceCodeAndErrorCode(anyString(), anyString())).thenReturn(0);
        alertsService.createAlertEntry(alertEntry);
        Mockito.verify(alertsRepository).save(any(AlertEntry.class));

    }

    @Test
    public void testCreateEntryNoConfigFoundAndCountMatch() {
        Mockito.when(alertsRepository.save(any(AlertEntry.class))).thenReturn(alertEntry);
        when(alertsConfigRepository.findAlertConfigEntryByServiceCodeAndErrorCode(anyString(), anyString())).thenReturn(null);
        when(alertsRepository.countAlertEntriesByServiceCodeAndErrorCode(anyString(), anyString())).thenReturn(1);
        alertsService.createAlertEntry(alertEntry);
        Mockito.verify(alertsRepository).save(any(AlertEntry.class));
    }

    @Test
    public void testUpdateEntryFound() {
        Mockito.when(alertsRepository.findOne(Mockito.anyLong())).thenReturn(alertEntry);
        Mockito.when(alertsRepository.save(any(AlertEntry.class))).thenReturn(alertEntry);
        alertsService.updateAlertEntry(1, alertEntry);
        Mockito.verify(alertsRepository).save(any(AlertEntry.class));
        Mockito.verify(alertsRepository).findOne(Mockito.anyLong());
    }

    @Test(expected = ResourceNotFoundException.class)
    public void testUpdateEntryNotFound() {
        Mockito.when(alertsRepository.findOne(Mockito.anyLong())).thenReturn(null);
        alertsService.updateAlertEntry(1, alertEntry);
        Mockito.verify(alertsRepository).findOne(Mockito.anyLong());
        Mockito.verify(alertsRepository, Mockito.never()).save(any(AlertEntry.class));
    }

    @Test
    public void testDeleteEntry() {
        alertsService.deleteAlertEntry("test", "error");
        Mockito.verify(alertsRepository).deleteAlertEntriesByServiceCodeAndErrorCode(Mockito.anyString(), Mockito.anyString());

    }

    @Test
    public void testGetAllAlertEntry() {
        when(alertsRepository.findAll()).thenReturn(Arrays.asList(alertEntry));
        alertsService.getAllAlerts();
        Mockito.verify(alertsRepository).findAll();
    }

    @Test
    public void testCreateAlertConfig() {
        when(alertsConfigRepository.save(any(AlertConfigEntry.class))).thenReturn(alertConfigEntry);
        alertsService.createAlertConfig(alertConfigEntry);
        Mockito.verify(alertsConfigRepository).save(any(AlertConfigEntry.class));

    }

    @Test(expected = NotAllowedOperationException.class)
    public void testCreateAlertConfigFound() {
        when(alertsConfigRepository.findAlertConfigEntryByServiceCodeAndErrorCode(anyString(), anyString())).thenReturn(alertConfigEntry);
        alertsService.createAlertConfig(alertConfigEntry);
    }

    @Test
    public void getAlertForServiceIdTest() {
        when(alertsRepository.findAlertEntriesByServiceCode(anyString())).thenReturn(Arrays.asList(alertEntry));
        assertTrue(alertsService.getAlertForServiceId("serviceCode").get(0).equals(alertEntry));
    }

    @Test
    public void testGetAllAlertConfigEntry() {
        when(alertsConfigRepository.findAll()).thenReturn(Arrays.asList(alertConfigEntry));
        alertsService.getAllAlertsConfig();
        Mockito.verify(alertsConfigRepository).findAll();

    }

    @Test
    public void testUpdateAlertConfigEntry() {
        Mockito.when(alertsConfigRepository.findOne(Mockito.anyLong())).thenReturn(alertConfigEntry);
        Mockito.when(alertsConfigRepository.save(any(AlertConfigEntry.class))).thenReturn(alertConfigEntry);
        alertsService.updateAlertConfig(1, alertConfigEntry);
        Mockito.verify(alertsConfigRepository).findOne(Mockito.anyLong());
        Mockito.verify(alertsConfigRepository).save(any(AlertConfigEntry.class));

    }

    @Test(expected = ResourceNotFoundException.class)
    public void testUpdateAlertConfigEntryNotFound() {
        Mockito.when(alertsConfigRepository.findOne(Mockito.anyLong())).thenReturn(null);
        alertsService.updateAlertConfig(1, alertConfigEntry);
        Mockito.verify(alertsConfigRepository, Mockito.never()).save(any(AlertConfigEntry.class));


    }

}