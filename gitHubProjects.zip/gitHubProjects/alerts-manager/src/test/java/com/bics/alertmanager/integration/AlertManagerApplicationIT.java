package com.bics.alertmanager.integration;

import com.bics.alertmanager.AlertManagerApplication;
import com.bics.alertmanager.entities.AlertEntry;
import com.bics.alerts.data.Alert;
import com.bics.alerts.data.AlertConfig;
import com.bics.mailproxy.client.MailProxyServiceClient;
import com.bics.mailproxy.client.ProxyMailer;
import org.json.JSONException;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.net.URL;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import static org.junit.Assert.assertTrue;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = AlertManagerApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@ActiveProfiles("INTEGRATION_TEST")
public class AlertManagerApplicationIT {
    @MockBean
    ProxyMailer proxyMailer;
    @MockBean
    MailProxyServiceClient proxyServiceClient;
    @LocalServerPort
    private int port;
    @Autowired
    private TestRestTemplate template;
    private URL base;
    private Alert alertEntry;
    private AlertConfig alertConfigEntry;

    @Before
    public void setUp() throws Exception {
        this.base = new URL("http://localhost:" + port + "/");
        Map<String, String> content = new HashMap<>();
        content.put("error", "errorContent");
        alertEntry = Alert.builder().errorCode("1001_TEST").serviceCode("IOT_TEST").severity("CRITICAL").alertContent(content).build();
        alertConfigEntry = AlertConfig.builder().errorCode("1001_TEST_IT").serviceCode("IOT_TEST_IT").maxCount(2).mailTemplate("ticket").emails(Arrays.asList("mahmoud.romih@bics.com")).build();

    }

    @Test
    public void test_1_contextLoads() {
        assertTrue(template.getForEntity(base + "/health", String.class).getStatusCode().is2xxSuccessful());

    }

    @Test
    public void test_2_testCreateGetDeleteAlert() throws JSONException {
        // create custom alert configuration then get it and make sure the count is 3
        assertTrue(template.postForEntity(base + "/alerts/config/", alertConfigEntry, AlertConfig.class).getStatusCode().is2xxSuccessful());
        final ResponseEntity<AlertConfig[]> configurations = template.getForEntity(base + "/alerts/config/", AlertConfig[].class);
        assertTrue(configurations.getBody().length == 3);
        // create an alert entry
        assertTrue(template.postForEntity(base + "/alerts/", alertEntry, AlertEntry.class).getStatusCode().is2xxSuccessful());
        // get the response entry and check the content
        final ResponseEntity<Alert[]> exchange = template.getForEntity(base + "/alerts", Alert[].class);
        final Alert[] body = exchange.getBody();
        assertTrue(body.length == 1);
        assertTrue(body[0].getServiceCode().equalsIgnoreCase("IOT_TEST"));
        assertTrue(body[0].getErrorCode().equalsIgnoreCase("1001_TEST"));
        // test delete

        template.delete(base + "/alerts/IOT_TEST/1001_TEST");
        final ResponseEntity<Alert[]> exchange2 = template.getForEntity(base + "/alerts", Alert[].class);
        final Alert[] body2 = exchange2.getBody();
        assertTrue(body2.length == 0);


    }


}
