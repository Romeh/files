# ehcache3-disk-persistence-demo
Example spring boot project with a ehcache3, xml configured, persistent cache
