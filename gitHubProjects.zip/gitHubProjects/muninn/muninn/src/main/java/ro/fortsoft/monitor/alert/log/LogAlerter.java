package ro.fortsoft.monitor.alert.log;

import com.typesafe.config.Config;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import ro.fortsoft.monitor.alert.BaseAlerter;
import ro.fortsoft.monitor.config.ConfigInjector;
import ro.fortsoft.monitor.rule.base.BaseRule;


/**
 * Created by id961900 on 08/08/2017.
 */
public class LogAlerter extends BaseAlerter {
   private static final Logger logger=LoggerFactory.getLogger(LogAlerter.class);

    public LogAlerter(Config config) {
        super(config);
    }

    @Override
    public String getName() {
        return "Log-alerter";
    }

    @Override
    public void alert(BaseRule baseRule, String content) throws Exception {
        logger.debug("Alert entry {}",content);
    }
}
