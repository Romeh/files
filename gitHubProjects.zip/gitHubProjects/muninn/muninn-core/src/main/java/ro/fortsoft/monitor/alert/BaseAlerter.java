package ro.fortsoft.monitor.alert;

import com.typesafe.config.Config;

/**
 * @author sbalamaci
 */
public abstract class BaseAlerter implements Alerter {

    public BaseAlerter(Config config) {
    }

}
