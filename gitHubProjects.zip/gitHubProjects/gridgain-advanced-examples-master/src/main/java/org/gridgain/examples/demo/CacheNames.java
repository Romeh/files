package org.gridgain.examples.demo;

public enum CacheNames {

    ICEP_JOBS,
    ICEP_REQUEST_DATA,
    ICEP_NODES

}
