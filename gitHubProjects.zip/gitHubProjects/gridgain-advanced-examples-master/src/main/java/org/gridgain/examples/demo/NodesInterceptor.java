package org.gridgain.examples.demo;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.CacheInterceptorAdapter;
import org.apache.ignite.cache.query.SqlQuery;
import org.apache.ignite.cluster.ClusterNode;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.jetbrains.annotations.Nullable;

import javax.cache.Cache;

import static org.gridgain.examples.demo.CacheNames.ICEP_JOBS;

/**
 * Created by D-UX07QF on 14/03/2017.
 */
public class NodesInterceptor extends CacheInterceptorAdapter<String, String> {

    @IgniteInstanceResource
    Ignite ignite;
    private transient IgniteCache<String, Job> jobs;
    private final String sql = "nodeId = ?";
    private final transient QueryTask task = new QueryTask();
    private transient SqlQuery<String, Job> affinityKeyRequestSqlQuery;


    @Nullable@Override
    public void onAfterPut(Cache.Entry<String, String> entry) {
        jobs = ignite.cache(ICEP_JOBS.name());
        ClusterNode clusterNode = ignite.cluster().localNode();
        System.out.println("intercepting for Node failure and retry from node id : "+ clusterNode.id().toString()+" to node id : "+entry.getValue());

        // Create query to get pending jobs for that node id and submit them again
        affinityKeyRequestSqlQuery= new SqlQuery<>(Job.class, sql);
        affinityKeyRequestSqlQuery.setArgs(entry.getValue());
        jobs.query(affinityKeyRequestSqlQuery).forEach(affinityKeyJobEntry -> {
            System.out.println("found a pending jobs for node id: "+entry.getValue() +" and job id: "+affinityKeyJobEntry.getKey());
            ignite.compute().withAsync().withTimeout(300)
                    .affinityRun(ICEP_JOBS.name(),affinityKeyJobEntry.getKey(),
                            ()->task.execute(affinityKeyJobEntry.getValue().request));

        });

    }



}
