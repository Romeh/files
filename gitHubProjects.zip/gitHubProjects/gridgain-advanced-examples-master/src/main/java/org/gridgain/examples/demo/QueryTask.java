package org.gridgain.examples.demo;

import org.apache.ignite.Ignite;
import org.apache.ignite.Ignition;
import org.apache.ignite.resources.IgniteInstanceResource;

import java.io.Serializable;

/**
 * Created by D-UX07QF on 13/03/2017.
 */
// Query post action sample

public class QueryTask implements Serializable{


    public void execute(Request request){

        System.out.println("Executing the expiry post action for the request" +request.getRequestID());
       /* // simulate processing time
        try {
            Thread.sleep(200);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }*/
        // once it is done , remove from the jobs state cache
        Ignition.ignite().cache(CacheNames.ICEP_JOBS.name()).remove(request.getRequestID());
    }
}
