package org.gridgain.examples.demo;

import org.apache.ignite.*;
import org.apache.ignite.cache.affinity.AffinityKey;
import org.apache.ignite.events.DiscoveryEvent;
import org.apache.ignite.events.EventType;

import java.time.LocalDateTime;

/**
 * Created by D-UX07QF on 13/03/2017.
 */
public class NodeApp {

    public static void main(String[] args) throws Exception {

            Ignite ignite = Ignition.start("config/igniteExpiry.xml");
            try  {

                IgniteServices svcs = ignite.services();
                svcs.deployClusterSingleton("myClusterSingletonExpiryQuery", new QueryService());

                IgniteCache<String, Request> cache = ignite.cache(CacheNames.ICEP_REQUEST_DATA.name());

                for(int i=0;i<=25;i++){
                    String key=i+"Key";
                    cache.put(key
                            ,Request.builder().requestID(key).modifiedTimestamp(System.currentTimeMillis()).build() );
                }

                //svcs.deployClusterSingleton("myClusterSingletonJobPending", new ComputeService());

                ignite.events().localListen(event -> {
                    DiscoveryEvent discoveryEvent=(DiscoveryEvent) event;
                    System.out.println("Received Node event [evt=" + discoveryEvent.name() +
                            ", nodeID=" + discoveryEvent.eventNode() + ']');

                    ignite.compute().withAsync().run(() -> {
                        IgniteCache<String, String> nodes = ignite.cache(CacheNames.ICEP_NODES.name());
                        String failedNodeId=discoveryEvent.eventNode().id().toString();
                        nodes.putIfAbsent(failedNodeId,failedNodeId);
                    });

                    return true;

                }, EventType.EVT_NODE_LEFT, EventType.EVT_NODE_FAILED);

                // Wait for some time and do another insertions
             /*  Thread.sleep(5000);
                for(int i=26;i<=50;i++){
                    String key=i+"Key";
                    cache.put(key,Request.builder().requestID(key).modifiedTimestamp(System.currentTimeMillis()).build() );
                }

                for(int i=26;i<=50;i++){
                    String key=i+"Key";
                    System.out.println(cache.get( key).toString());
                }
*/

            }catch (Exception e){
            e.printStackTrace();
        }
    }
}
