package org.gridgain.examples.demo;

import lombok.*;
import org.apache.ignite.cache.query.annotations.QuerySqlField;

import java.util.function.Consumer;

/**
 * Created by D-UX07QF on 13/03/2017.
 */
//Sample job model
@Builder
@Getter
@Setter
@ToString
@EqualsAndHashCode
public class Job {

    @QuerySqlField
    String nodeId;
    Request request;
}
