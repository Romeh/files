package org.gridgain.examples.demo;

import org.apache.ignite.Ignite;
import org.apache.ignite.IgniteCache;
import org.apache.ignite.cache.affinity.AffinityKey;
import org.apache.ignite.cache.query.SqlFieldsQuery;
import org.apache.ignite.cache.query.SqlQuery;
import org.apache.ignite.resources.IgniteInstanceResource;
import org.apache.ignite.services.Service;
import org.apache.ignite.services.ServiceContext;

import java.time.LocalDateTime;
import java.util.Timer;
import java.util.TimerTask;

import static org.gridgain.examples.demo.CacheNames.ICEP_JOBS;
import static org.gridgain.examples.demo.CacheNames.ICEP_REQUEST_DATA;

/**
 * Created by D-UX07QF on 13/03/2017.
 */
public class QueryService implements Service{
    @IgniteInstanceResource
    private transient Ignite ignite;
    private final String sql = "modifiedTimestamp <= ?";
    private transient IgniteCache<String, Request> cache =null;
    private transient  SqlQuery<String, Request> affinityKeyRequestSqlQuery;
    private transient IgniteCache<String, Job> jobs=null;


    @Override
    public void cancel(ServiceContext serviceContext) {
        // empty
    }

    // do the same in case of redeployment when a node crash
    @Override
    public void init(ServiceContext serviceContext) throws Exception {
        cache = ignite.cache(ICEP_REQUEST_DATA.name());
        jobs = ignite.cache(ICEP_JOBS.name());
        // load cache data during startup ignite.cluster().nodes().size()
        // start querying
        handleExpiredRecords("Service init");
        // just do the same in a scheduled way
        Timer timer=new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {
                handleExpiredRecords("Scheduler");
            }
        }, 5000, 5000);
        // TODO check ignite scheduler
        //ignite.scheduler().scheduleLocal(() -> handleExpiredRecords("Scheduler"),"0 0 * * *");

    }

    @Override
    public void execute(ServiceContext serviceContext) throws Exception {
        // empty
    }

    //querying logic to submit post actions if any for the expired records
    private void handleExpiredRecords(String context){
        // Create query to get outdated fields
        // get current timeStamp
        affinityKeyRequestSqlQuery= new SqlQuery<>(Request.class, sql);
        long timeStamp=System.currentTimeMillis();
        System.out.println("next query timestamp check : "+timeStamp);
        // set the new current timestamp
        affinityKeyRequestSqlQuery.setArgs(timeStamp);
        // execute the query
        cache.query(affinityKeyRequestSqlQuery).forEach(affinityKeyRequestEntry -> {
            System.out.println("query result : "+affinityKeyRequestEntry.getKey()+" from context: "+context);
            // remove the expired entry
            cache.remove(affinityKeyRequestEntry.getKey());
            // store post expiry job needed to be done as a result of that expiry into jobs cache
            jobs.put(affinityKeyRequestEntry.getKey(),
                    Job.builder().request(affinityKeyRequestEntry.getValue()).build());


        });
    }

}
