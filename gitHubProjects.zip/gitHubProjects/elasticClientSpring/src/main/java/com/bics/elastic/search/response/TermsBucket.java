package com.bics.elastic.search.response;

/**
 * Terms specific bucket.
 */
public class TermsBucket extends BaseBucket {
}
