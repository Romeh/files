package com.bics.elastic;

import com.bics.elastic.search.response.Aggregation;
import com.bics.elastic.search.response.AggregationDeserializer;
import com.fasterxml.jackson.core.Version;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.module.SimpleModule;
import com.bics.elastic.search.AggregationConfig;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

import java.util.Optional;

/**
 * Configuration class
 */
@Configuration
@ComponentScan("com.bics.elastic")
public class RestClientConfig {

    @Autowired
    public void configObjectMapper(ObjectMapper objectMapper, Optional<AggregationConfig> aggregationConfig) {
        AggregationDeserializer deserializer = new AggregationDeserializer();

        aggregationConfig.ifPresent(config -> {
            config.getAggregationMap().forEach(deserializer::register);
        });

        SimpleModule module = new SimpleModule("AggregationDeserializer",
                new Version(1, 0, 0, null, "com.bics.elastic", "aggregation-elastic"));
        module.addDeserializer(Aggregation.class, deserializer);

        objectMapper.registerModule(module);
    }
}
