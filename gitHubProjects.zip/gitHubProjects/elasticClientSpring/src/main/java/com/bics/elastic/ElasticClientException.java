package com.bics.elastic;

/**
 * Parent exception for all custom com.bics.elastic based exceptions while using the client.
 */
public class ElasticClientException extends RuntimeException {
    public ElasticClientException(String message) {
        super(message);
    }

    public ElasticClientException(String message, Throwable cause) {
        super(message, cause);
    }
}
