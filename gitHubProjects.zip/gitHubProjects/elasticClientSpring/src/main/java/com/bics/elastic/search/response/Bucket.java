package com.bics.elastic.search.response;

public abstract class Bucket {
}
