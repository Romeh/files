package com.bics.elastic.search.response;

/**
 * Histogram specific Bucket
 */
public class HistogramBucket extends BaseBucket {
}
