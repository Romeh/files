package com.bics.elastic;

import com.bics.elastic.search.response.DateHistogramAggregation;
import com.bics.elastic.search.response.TermsAggregation;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.bics.elastic.search.AggregationConfig;
import com.bics.elastic.search.response.HistogramAggregation;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

@Configuration
@PropertySource("classpath:test.properties")
public class TestConfig {

    @Bean
    public AggregationConfig aggregationConfig() {
        AggregationConfig config = new AggregationConfig();
        config.addConfig("byTags", TermsAggregation.class);
        config.addConfig("byHistogram", HistogramAggregation.class);
        config.addConfig("byDateHistogram", DateHistogramAggregation.class);

        return config;
    }

    @Bean
    public ObjectMapper objectMapper() {
        return new ObjectMapper();
    }

    @Bean
    public IndexDocumentHelper indexDocumentHelper() {
        return new IndexDocumentHelper();
    }
}
