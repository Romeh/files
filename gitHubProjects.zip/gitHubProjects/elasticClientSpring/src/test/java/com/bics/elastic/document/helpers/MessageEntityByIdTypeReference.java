package com.bics.elastic.document.helpers;

import com.bics.elastic.document.response.GetByIdResponse;
import com.fasterxml.jackson.core.type.TypeReference;

/**
 * Created by Romih on 13/02/2017.
 */
public class MessageEntityByIdTypeReference extends TypeReference<GetByIdResponse<MessageEntity>>{
}
