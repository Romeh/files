package com.bics.elastic.document.helpers;

import com.bics.elastic.search.response.QueryResponse;
import com.fasterxml.jackson.core.type.TypeReference;

/**
 * Created by Romih on 13/02/2017.
 */
public class MessageEntityTypeReference extends TypeReference<QueryResponse<MessageEntity>> {
}
